CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vigilante_registration_review`
--

DROP TABLE IF EXISTS `vigilante_registration_review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vigilante_registration_review` (
  `registration_id` int NOT NULL AUTO_INCREMENT COMMENT '义警注册单号',
  `name` varchar(50) DEFAULT NULL COMMENT '姓名',
  `id_card_number` char(18) DEFAULT NULL COMMENT '身份证号',
  `gender` enum('男','女','其他') DEFAULT NULL COMMENT '性别',
  `political_status` varchar(50) DEFAULT NULL COMMENT '政治面貌',
  `workplace` varchar(100) DEFAULT NULL COMMENT '工作单位',
  `occupation` varchar(50) DEFAULT NULL COMMENT '职业',
  `education` varchar(50) DEFAULT NULL COMMENT '学历',
  `expertise` text COMMENT '本人专长',
  `reviewer_name` char(10) DEFAULT NULL COMMENT '审核人姓名',
  `review_status` enum('待审核','审核通过','审核不通过') NOT NULL DEFAULT '待审核' COMMENT '审核状态',
  `rejection_reason` text COMMENT '驳回意见（通过的话那就是无）',
  `commitment_letter_path` varchar(255) DEFAULT NULL COMMENT '承诺书存储路径',
  `id_card_front_path` varchar(255) DEFAULT NULL COMMENT '身份证正照存储路径',
  `id_card_back_path` varchar(255) DEFAULT NULL COMMENT '身份证反照存储路径',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `request_time` date DEFAULT NULL COMMENT '申请时间',
  `review_time` date DEFAULT NULL COMMENT '审核时间',
  `visitor_id` char(10) DEFAULT NULL COMMENT '游客编号',
  `reviewer_id` char(10) DEFAULT NULL,
  `phone_number` char(11) DEFAULT NULL,
  PRIMARY KEY (`registration_id`),
  KEY `FK_义警注册审核2` (`reviewer_name`),
  KEY `vigilante_registration_review_visitor_visitor_id_fk` (`visitor_id`),
  KEY `vigilante_registration_review_admin_admin_id_fk` (`reviewer_id`),
  CONSTRAINT `vigilante_registration_review_admin_admin_id_fk` FOREIGN KEY (`reviewer_id`) REFERENCES `admin` (`admin_id`),
  CONSTRAINT `vigilante_registration_review_visitor_visitor_id_fk` FOREIGN KEY (`visitor_id`) REFERENCES `visitor` (`visitor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante_registration_review`
--

LOCK TABLES `vigilante_registration_review` WRITE;
/*!40000 ALTER TABLE `vigilante_registration_review` DISABLE KEYS */;
INSERT INTO `vigilante_registration_review` VALUES (1,'王明','431023200604170886','男','共青团员','荒阪科技','科研人员','硕士研究生','<null>','张三','审核通过','','',NULL,NULL,'2024-11-05 08:24:11','2024-11-19 15:51:39','2024-11-11','2024-11-14','0000000001',NULL,NULL),(2,'张三','431023200604170887','男','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 12:43:43','2024-11-12','2024-11-14','0000000002',NULL,NULL),(3,'李四','431023200604170888','男','共青团员','一二三','职工','本科',NULL,'张三','审核不通过','年龄不符合规范',NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 12:44:07','2024-11-13','2024-11-14','0000000003',NULL,NULL),(4,'王五','431023200604170889','男','共青团员','一二三','职工','本科',NULL,'张三','审核通过','',NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 13:32:27','2024-11-14','2024-11-14','0000000004',NULL,NULL),(5,'今汐','431023200604170890','女','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 13:37:01','2024-11-15','2024-11-14','0000000005',NULL,NULL),(6,'刻晴','431023200604170891','女','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 13:37:50','2024-11-16','2024-11-14','0000000006',NULL,NULL),(7,'椿','431023200604170892','女','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 13:37:57','2024-11-17','2024-11-14','0000000007',NULL,NULL),(8,'海芙','431023200604170893','女','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-19 16:09:38','2024-11-18','2024-11-14','0000000008','1','19173556093'),(9,'泡芙','431023200604170894','女','共青团员','一二三','职工','本科',NULL,'张三','审核不通过','',NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-14 23:58:11','2024-11-19','2024-11-14','0000000009',NULL,NULL),(10,'派大星','431023200604170895','男','共青团员','一二三','职工','本科',NULL,'张三','审核不通过','',NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-15 00:12:28','2024-12-10','2024-11-15','0000000010',NULL,NULL),(11,'金克斯','431023200604170896','女','共青团员','一二三','职工','本科',NULL,'张三','审核不通过','1232',NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-15 00:21:19','2024-12-11','2024-11-15','0000000011',NULL,NULL),(12,'杨过','431023200604170897','男','共青团员','一二三','职工','本科',NULL,'','待审核',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-29 14:16:13','2024-12-12',NULL,'0000000012',NULL,'19173556098'),(13,'逻辑','431023200604170898','男','共青团员','一二三','职工','本科',NULL,'张三','审核不通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-19 16:08:33','2024-12-13','2024-11-19','0000000013','1','19173556098'),(14,'武大郎','431023200604170899','男','共青团员','一二三','职工','本科',NULL,'张三','审核通过',NULL,NULL,NULL,NULL,'2024-11-13 17:25:59','2024-11-27 16:43:42','2024-12-14','2024-11-27','0000000014','1','19173556086'),(17,'faker','431023200505190837','男','群众',NULL,'自由职业',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/1b558ba2-cde6-43b1-9872-140b481ad0bd.jpg','https://vigilante.oss-cn-shenzhen.aliyuncs.com/aa8302cb-e3ce-42b0-abad-6d07aac5eaa3.jpeg','https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024-11-29 10:11:12','2024-11-29 10:16:30','2024-11-29','2024-11-29','0000000016','1','19173557086'),(18,'李四','445281222211112222','男','党员','','公职人员',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/e1bb814d-3974-4d95-abd1-829433fff160.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/91cb6c10-43f7-45a6-bcff-5750fd8281c6.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/8778b8ea-dcef-4111-a5e5-6a99cdfe0dae.png','2024-11-29 14:28:58','2024-11-29 14:29:44','2024-11-29','2024-11-29','0000000017','1','18911112222'),(19,'李四1','445281222233334444','男','党员',NULL,'公职人员',NULL,NULL,'张三','审核不通过','11111111111','https://vigilante.oss-cn-shenzhen.aliyuncs.com/ca98410c-8f61-47da-8841-672c6bc7ab52.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/e66bba2f-9ed0-4260-b145-fd626b38ac0d.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/41a51a94-92e2-4801-814b-c903f8e5c37a.png','2024-11-29 14:47:11','2024-11-29 14:48:32','2024-11-29','2024-11-29','0000000018','1','18911112222'),(20,'李四1','445281999988887777','男','党员',NULL,'公职人员',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/04875255-5362-4ea6-a0ca-3c231e667a80.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/5f934b39-82dd-4e79-a2d5-1c9c49195a14.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/2bbae79d-ad0f-4fe8-9b23-5ade0793b1f2.png','2024-11-29 14:49:21','2024-11-29 14:49:37','2024-11-29','2024-11-29','0000000018','1','18911221122'),(21,'今汐','431023200607180837','男','党员',NULL,'公职人员',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/3b53568d-bea8-4dae-9202-edfab23f9e22.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/d92a79d7-7146-4b1e-8d7f-96981167c5a3.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/c450ba97-d938-4c90-b778-3530d943625b.png','2024-11-29 15:01:57','2024-11-29 15:02:15','2024-11-29','2024-11-29','0000000019','1','19173666086'),(22,'李四1','445281222233331111','男','党员',NULL,'公职人员',NULL,NULL,'张三','审核不通过','1111','https://vigilante.oss-cn-shenzhen.aliyuncs.com/4f077ee1-23f5-4e4a-80b5-b8e3ec6dbfb9.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/a0440e7b-1e7a-473e-b9ed-db45132a0515.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/1bd0ecda-69c6-4991-a4b5-4e662050a987.png','2024-11-29 16:45:53','2024-11-29 16:46:48','2024-11-29','2024-11-29','0000000020','1','18911112222'),(23,'李四1','445281200100001111','女','党员',NULL,'公职人员',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/9d9e0977-d352-4cb2-a962-952e4baf33fb.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/60ba1aef-ce9f-42f7-841d-624941167fc9.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/a3e4daa7-d6e1-4ef3-85b0-56ddd45c5f69.png','2024-11-29 16:47:48','2024-11-29 16:48:05','2024-11-29','2024-11-29','0000000020','1','18912122222'),(24,'小明','445281200410101010','女','预备党员',NULL,'安保人员',NULL,NULL,'张三','审核通过',NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/b48371df-df52-4915-9cad-945e5503fbe2.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/58c72905-bc07-4a0e-8290-d9363089ac33.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/787ec693-6cc9-4501-a031-026d8c367e2e.png','2024-11-29 17:10:47','2024-11-29 17:11:17','2024-11-29','2024-11-29','0000000021','1','18988112211');
/*!40000 ALTER TABLE `vigilante_registration_review` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:41
