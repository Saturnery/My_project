CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `visitor`
--

DROP TABLE IF EXISTS `visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `visitor` (
  `nickname` varchar(50) DEFAULT NULL COMMENT '昵称',
  `avatar_path` varchar(255) DEFAULT NULL COMMENT '头像存储路径',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `visitor_id` char(10) NOT NULL,
  `openid` char(50) NOT NULL,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor`
--

LOCK TABLES `visitor` WRITE;
/*!40000 ALTER TABLE `visitor` DISABLE KEYS */;
INSERT INTO `visitor` VALUES ('无敌暴龙战士','wwwww','2024-11-13 17:15:14','2024-11-27 10:45:40','0000000001',''),('kkk',NULL,'2024-11-13 17:16:54','2024-11-13 17:16:56','0000000002',''),('lll',NULL,'2024-11-13 17:17:15','2024-11-13 17:17:16','0000000003',''),('ggg',NULL,'2024-11-13 17:17:43','2024-11-13 17:17:44','0000000004',''),('fff',NULL,'2024-11-13 17:18:11','2024-11-13 17:18:12','0000000005',''),('ttt',NULL,'2024-11-14 12:40:50','2024-11-14 12:40:59','0000000006',''),('ddd',NULL,'2024-11-14 12:40:53','2024-11-14 12:40:59','0000000007',''),('qqq',NULL,'2024-11-14 12:40:54','2024-11-14 12:41:00','0000000008',''),('www',NULL,'2024-11-14 12:40:55','2024-11-14 12:41:01','0000000009',''),('eee',NULL,'2024-11-14 12:40:55','2024-11-14 12:41:01','0000000010',''),('rrr',NULL,'2024-11-14 12:40:56','2024-11-14 12:41:02','0000000011',''),('yyy',NULL,'2024-11-14 12:40:57','2024-11-14 12:41:02','0000000012',''),('uuu',NULL,'2024-11-14 12:40:57','2024-11-14 12:41:03','0000000013',''),('ppp',NULL,'2024-11-14 12:40:58','2024-11-14 12:41:04','0000000014',''),('xxx',NULL,'2024-11-14 22:51:43','2024-11-14 22:51:46','0000000015',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024-11-29 01:13:51','2024-11-29 14:26:59','0000000016',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/500e4bd3-243d-4a0f-9257-00a393b0edfe.jpeg','2024-11-29 14:27:08','2024-11-29 14:43:23','0000000017',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/3252c117-c1a1-47df-914f-074904ca4505.jpeg','2024-11-29 14:44:09','2024-11-29 14:59:47','0000000018',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/a48cc7f0-5a51-471b-a698-036b4d8b89d0.jpeg','2024-11-29 15:00:32','2024-11-29 16:14:16','0000000019',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/3407fb86-9538-462c-a7a8-0348fb1ad13a.jpeg','2024-11-29 16:43:26','2024-11-29 17:01:10','0000000020',''),('vvv','https://vigilante.oss-cn-shenzhen.aliyuncs.com/ab584544-c581-4980-856a-d8016e2d7d90.jpeg','2024-11-29 17:08:03','2024-11-29 17:08:17','0000000021','okSqf7XX0Dd6c0ISmxGF2RiceSQg');
/*!40000 ALTER TABLE `visitor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:42
