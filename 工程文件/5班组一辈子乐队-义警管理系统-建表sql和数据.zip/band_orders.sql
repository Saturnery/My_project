CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `orders` (
  `order_id` int NOT NULL AUTO_INCREMENT COMMENT '订单编号',
  `vigilante_id` char(10) DEFAULT NULL COMMENT '义警编号（外键）',
  `product_id` int DEFAULT NULL COMMENT '商品编号（外键）',
  `required_points` int NOT NULL COMMENT '所需积分',
  `phone_number` char(11) DEFAULT NULL COMMENT '手机号码',
  `delivery_address` varchar(255) DEFAULT NULL COMMENT '收货地址',
  `recipient_name` varchar(50) DEFAULT NULL COMMENT '收件人称呼',
  `notes` text COMMENT '备注',
  `status` enum('已发货','未发货','已签收') NOT NULL DEFAULT '未发货' COMMENT '状态',
  `signed_time` datetime DEFAULT NULL COMMENT '签收时间',
  `post_time` datetime DEFAULT NULL COMMENT '发货时间',
  `purchase_quantity` int NOT NULL COMMENT '购买数量',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `order_time` datetime COMMENT '下单时间',
  PRIMARY KEY (`order_id`),
  KEY `FK_订单1` (`vigilante_id`),
  KEY `FK_订单2` (`product_id`),
  CONSTRAINT `FK_订单1` FOREIGN KEY (`vigilante_id`) REFERENCES `vigilante` (`vigilante_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_订单2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (59,'2024000021',69,40,'19173556086','湖南大学天马学生公寓','vvv','急','已签收','2024-11-29 13:46:40','2024-11-29 13:43:43',1,'2024-11-29 13:42:39','2024-11-29 13:46:40','2024-11-29 13:42:39'),(60,'2024000021',59,120,'19173556086','湖南大学','v','急','已签收','2024-11-29 13:46:53','2024-11-29 13:46:14',1,'2024-11-29 13:45:51','2024-11-29 13:46:53','2024-11-29 13:45:51'),(61,'2024000024',59,120,'19173556086','湖南大学天马学生公寓','vvv','急急急急急急急急急','已发货','2024-11-29 15:31:52','2024-11-29 16:51:33',1,'2024-11-29 15:31:04','2024-11-29 16:51:33','2024-11-29 15:31:04'),(62,'2024000025',55,150,'19173556086','湖南大学','vvv','急急急','已签收','2024-11-29 16:52:36','2024-11-29 16:52:18',1,'2024-11-29 16:49:23','2024-11-29 16:52:36','2024-11-29 16:49:23'),(63,'2024000026',55,150,'18988741111','湖南大学','旅行社','111','已签收','2024-11-29 17:15:22','2024-11-29 17:14:34',1,'2024-11-29 17:13:56','2024-11-29 17:15:22','2024-11-29 17:13:56');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:39
