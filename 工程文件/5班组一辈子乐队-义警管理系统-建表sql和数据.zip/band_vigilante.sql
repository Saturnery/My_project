CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vigilante`
--

DROP TABLE IF EXISTS `vigilante`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vigilante` (
  `vigilante_id` char(10) NOT NULL COMMENT '义警编号，格式为年份+序号',
  `real_name` varchar(50) NOT NULL COMMENT '真实姓名',
  `nickname` varchar(50) DEFAULT '微信昵称' COMMENT '昵称',
  `id_number` char(18) NOT NULL COMMENT '身份证号',
  `phone_number` char(11) NOT NULL COMMENT '手机号',
  `gender` enum('男','女','其他') NOT NULL COMMENT '性别',
  `workplace` varchar(100) DEFAULT NULL COMMENT '工作单位',
  `occupation` varchar(50) DEFAULT NULL COMMENT '职业',
  `political_status` varchar(50) DEFAULT NULL COMMENT '政治面貌',
  `education` varchar(50) DEFAULT NULL COMMENT '学历',
  `expertise` varchar(50) DEFAULT '无' COMMENT '本人专长',
  `commitment_path` varchar(255) DEFAULT NULL COMMENT '承诺书存储路径',
  `id_front_path` varchar(255) DEFAULT NULL COMMENT '身份证正照存储路径',
  `id_back_path` varchar(255) DEFAULT NULL COMMENT '身份证反照存储路径',
  `avatar_path` varchar(255) DEFAULT NULL COMMENT '头像存储路径',
  `team_id` char(10) DEFAULT NULL COMMENT '队伍编号（外键）',
  `available_points` int DEFAULT '0' COMMENT '可用爱心积分',
  `default_address` varchar(100) DEFAULT NULL COMMENT '默认收货地址',
  `daily_circle_points` int DEFAULT '0' COMMENT '当日发圈获得积分次数（最多3次）',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `registration_time` date DEFAULT (curdate()) COMMENT '注册时间',
  `openid` char(50) DEFAULT NULL,
  PRIMARY KEY (`vigilante_id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  KEY `FK_义警信息` (`team_id`),
  CONSTRAINT `FK_义警信息` FOREIGN KEY (`team_id`) REFERENCES `team` (`team_id`) ON DELETE RESTRICT,
  CONSTRAINT `vigilante_chk_1` CHECK ((`daily_circle_points` <= 3))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante`
--

LOCK TABLES `vigilante` WRITE;
/*!40000 ALTER TABLE `vigilante` DISABLE KEYS */;
INSERT INTO `vigilante` VALUES ('2024000001','海芙','微信昵称','431023200604170893','19173556093','女',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,999999437,NULL,0,'2024-11-14 19:46:33','2024-11-29 15:38:45','2024-11-14',NULL),('2024000002','逻辑','微信昵称','431023200604170898','19173556098','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000001',0,NULL,0,'2024-11-19 15:59:51','2024-11-29 12:16:51','2024-11-19',NULL),('2024000003','武大郎','微信昵称','431023200604170899','19173556086','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000002',0,NULL,0,'2024-11-27 16:43:42','2024-11-29 12:16:51','2024-11-27',''),('2024000004','雷伊','微信昵称','431023200604170900','19173556099','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000002',0,NULL,0,'2024-11-27 22:38:35','2024-11-29 10:44:20','2024-11-27',NULL),('2024000005','王明','微信昵称','431023200604170901','19173556100','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000003',0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000006','喜羊羊','微信昵称','431023200604170902','19173556101','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000004',0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000007','美羊羊','微信昵称','431023200604170903','19173556102','女',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000005',0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000008','懒洋洋','微信昵称','431023200604170904','19173556103','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000006',0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000009','慢羊羊','微信昵称','431023200604170905','19173556104','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000010','暖羊羊','微信昵称','431023200604170906','19173556105','女',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000011','猪猪侠','微信昵称','431023200604170907','19173556106','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000012','超人强','微信昵称','431023200604170908','19173556107','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000013','大大怪','微信昵称','431023200604170909','19173556108','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000014','小小怪','微信昵称','431023200604170910','19173556109','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000015','开心超人','微信昵称','431023200604170911','19173556110','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000016','花心超人','微信昵称','431023200604170912','19173556111','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000017','爱心超人','微信昵称','431023200604170913','19173556112','女',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000018','崔斯特','微信昵称','431023200604170914','19173556113','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000019','艾克','微信昵称','431023200604170915','19173556114','男',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000020','金克斯','微信昵称','431023200604170916','19173556115','女',NULL,NULL,'共青团员','本科','无',NULL,NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg',NULL,0,NULL,0,'2024-11-29 00:26:27','2024-11-29 10:44:20','2024-11-29',NULL),('2024000021','faker','微信昵称','431023200505190837','19173557086','男',NULL,'自由职业','群众','本科','无','https://vigilante.oss-cn-shenzhen.aliyuncs.com/1b558ba2-cde6-43b1-9872-140b481ad0bd.jpg','https://vigilante.oss-cn-shenzhen.aliyuncs.com/aa8302cb-e3ce-42b0-abad-6d07aac5eaa3.jpeg','https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','https://vigilante.oss-cn-shenzhen.aliyuncs.com/f0207442-1505-4f6e-b0bd-ef9cb93fb485.jpeg','2024000001',999740,NULL,0,'2024-11-29 10:16:30','2024-11-29 14:25:32','2024-11-29',NULL),('2024000022','李四','微信昵称','445281222211112222','18911112222','男','','公职人员','党员',NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/e1bb814d-3974-4d95-abd1-829433fff160.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/91cb6c10-43f7-45a6-bcff-5750fd8281c6.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/8778b8ea-dcef-4111-a5e5-6a99cdfe0dae.png',NULL,NULL,0,NULL,0,'2024-11-29 14:29:44','2024-11-29 14:43:42','2024-11-29',NULL),('2024000023','李四1',NULL,'445281999988887777','18911221122','男',NULL,'公职人员','党员',NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/04875255-5362-4ea6-a0ca-3c231e667a80.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/5f934b39-82dd-4e79-a2d5-1c9c49195a14.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/2bbae79d-ad0f-4fe8-9b23-5ade0793b1f2.png',NULL,NULL,0,NULL,0,'2024-11-29 14:49:37','2024-11-29 15:00:02','2024-11-29',''),('2024000024','今汐','vvv','431023200607180837','19173666086','男',NULL,'公职人员','党员',NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/3b53568d-bea8-4dae-9202-edfab23f9e22.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/d92a79d7-7146-4b1e-8d7f-96981167c5a3.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/c450ba97-d938-4c90-b778-3530d943625b.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/a48cc7f0-5a51-471b-a698-036b4d8b89d0.jpeg','2024000001',99880,NULL,0,'2024-11-29 15:02:15','2024-11-29 16:14:02','2024-11-29',NULL),('2024000025','李四1','vvv','445281200100001111','18912122222','女',NULL,'公职人员','党员',NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/9d9e0977-d352-4cb2-a962-952e4baf33fb.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/60ba1aef-ce9f-42f7-841d-624941167fc9.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/a3e4daa7-d6e1-4ef3-85b0-56ddd45c5f69.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/3407fb86-9538-462c-a7a8-0348fb1ad13a.jpeg','2024000001',99850,NULL,0,'2024-11-29 16:48:05','2024-11-29 17:01:00','2024-11-29',NULL),('2024000026','小明','vvv','445281200410101010','18988112211','女',NULL,'安保人员','预备党员',NULL,NULL,'https://vigilante.oss-cn-shenzhen.aliyuncs.com/b48371df-df52-4915-9cad-945e5503fbe2.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/58c72905-bc07-4a0e-8290-d9363089ac33.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/787ec693-6cc9-4501-a031-026d8c367e2e.png','https://vigilante.oss-cn-shenzhen.aliyuncs.com/ab584544-c581-4980-856a-d8016e2d7d90.jpeg','2024000001',9850,NULL,0,'2024-11-29 17:11:17','2024-11-29 17:16:27','2024-11-29','okSqf7XX0Dd6c0ISmxGF2RiceSQg');
/*!40000 ALTER TABLE `vigilante` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:39
