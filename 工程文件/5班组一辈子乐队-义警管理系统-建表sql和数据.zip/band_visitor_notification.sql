CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `visitor_notification`
--

DROP TABLE IF EXISTS `visitor_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `visitor_notification` (
  `notification_id` int NOT NULL AUTO_INCREMENT COMMENT '消息通知编号',
  `visitor_id` char(10) DEFAULT NULL COMMENT '游客编号',
  `notification_type` enum('义警注册审核提醒','消息上报反馈提醒','其它') DEFAULT NULL COMMENT '消息通知类型',
  `content` text COMMENT '消息通知内容',
  `send_time` datetime NOT NULL COMMENT '发送时间',
  `read_status` enum('已读','未读') DEFAULT '未读' COMMENT '消息阅读状态',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`notification_id`),
  KEY `visitor_notification_visitor_visitor_id_fk` (`visitor_id`),
  CONSTRAINT `visitor_notification_visitor_visitor_id_fk` FOREIGN KEY (`visitor_id`) REFERENCES `visitor` (`visitor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_notification`
--

LOCK TABLES `visitor_notification` WRITE;
/*!40000 ALTER TABLE `visitor_notification` DISABLE KEYS */;
INSERT INTO `visitor_notification` VALUES (11,'0000000014','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-27 16:43:42','未读','2024-11-27 16:43:42','2024-11-27 16:43:42'),(12,'0000000016','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 10:16:30','未读','2024-11-29 10:16:30','2024-11-29 10:16:30'),(13,'0000000017','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 14:29:44','未读','2024-11-29 14:29:44','2024-11-29 14:29:44'),(14,'0000000018','义警注册审核提醒','11111111111','2024-11-29 14:48:32','未读','2024-11-29 14:48:32','2024-11-29 14:48:32'),(15,'0000000018','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 14:49:37','未读','2024-11-29 14:49:37','2024-11-29 14:49:37'),(16,'0000000019','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 15:02:15','未读','2024-11-29 15:02:15','2024-11-29 15:02:15'),(17,'0000000020','义警注册审核提醒','1111','2024-11-29 16:46:48','未读','2024-11-29 16:46:48','2024-11-29 16:46:48'),(18,'0000000020','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 16:48:05','未读','2024-11-29 16:48:05','2024-11-29 16:48:05'),(19,'0000000021','义警注册审核提醒','恭喜您已通过审核,您的个人信息已更新','2024-11-29 17:11:17','未读','2024-11-29 17:11:17','2024-11-29 17:11:17');
/*!40000 ALTER TABLE `visitor_notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:40
