CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `task_application`
--

DROP TABLE IF EXISTS `task_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `task_application` (
  `task_id` bigint unsigned NOT NULL AUTO_INCREMENT COMMENT '任务申请单号',
  `task_name` varchar(255) NOT NULL COMMENT '任务名',
  `task_date` date NOT NULL COMMENT '任务日期',
  `task_start_time` time NOT NULL COMMENT '任务开始时间',
  `task_end_time` time NOT NULL COMMENT '任务结束时间',
  `task_type` enum('法制宣传','巡逻防护','护校安全','秩序维护') NOT NULL COMMENT '任务类型',
  `task_location` varchar(255) NOT NULL COMMENT '任务地点',
  `responsible_team` varchar(100) NOT NULL COMMENT '任务负责方',
  `limit_number` int unsigned DEFAULT '0' COMMENT '限制人数（参与人群未为所有人抢单时才填，否则为0）',
  `review_status` enum('待审核','审核通过','审核不通过') NOT NULL DEFAULT '待审核' COMMENT '审核状态',
  `reviewer_id` char(10) DEFAULT NULL COMMENT '审核人编号',
  `promotional_image_path` varchar(255) DEFAULT NULL COMMENT '任务宣传图存储路径',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `request_time` datetime NOT NULL COMMENT '申请时间',
  `review_time` datetime DEFAULT NULL COMMENT '审核时间',
  `task_content` text COMMENT '任务内容',
  `task_description` text COMMENT '任务简介',
  `task_difficulty` enum('高','中','低') NOT NULL COMMENT '任务难度',
  `rejection_reason` text COMMENT '驳回意见',
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_application`
--

LOCK TABLES `task_application` WRITE;
/*!40000 ALTER TABLE `task_application` DISABLE KEYS */;
INSERT INTO `task_application` VALUES (1,'任务','2024-11-27','18:05:34','19:05:34','巡逻防护','湖南师范大学','2024000001',20,'待审核',NULL,'https://via.placeholder.com/400x400/748e6e/fa5cfc.gif','2024-11-26 13:51:15','2024-11-26 13:51:15','2024-11-26 13:51:15',NULL,'好','好','低',NULL);
/*!40000 ALTER TABLE `task_application` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:37
