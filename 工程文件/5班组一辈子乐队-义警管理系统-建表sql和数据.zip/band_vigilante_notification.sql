CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `vigilante_notification`
--

DROP TABLE IF EXISTS `vigilante_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `vigilante_notification` (
  `notification_id` int NOT NULL AUTO_INCREMENT COMMENT '消息通知编号',
  `vigilante_id` char(10) NOT NULL COMMENT '接受消息者义警编号（外键）',
  `notification_type` enum('注册审核结果提醒','信息上报反馈提醒','活动申请反馈提醒','商品发货提醒','入队申请结果提醒','其它') DEFAULT NULL COMMENT '消息通知类型',
  `content` text COMMENT '消息通知内容',
  `read_status` enum('已读','未读') DEFAULT '未读' COMMENT '消息阅读状态',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `send_time` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`notification_id`),
  KEY `FK_义警消息通知` (`vigilante_id`),
  CONSTRAINT `FK_义警消息通知` FOREIGN KEY (`vigilante_id`) REFERENCES `vigilante` (`vigilante_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vigilante_notification`
--

LOCK TABLES `vigilante_notification` WRITE;
/*!40000 ALTER TABLE `vigilante_notification` DISABLE KEYS */;
INSERT INTO `vigilante_notification` VALUES (1,'2024000001','入队申请结果提醒','恭喜您已加入义警队伍：无敌暴龙队','未读','2024-11-19 00:09:30','2024-11-19 00:09:30','2024-11-19 00:09:30'),(2,'2024000001','入队申请结果提醒','恭喜您已加入义警队伍：无敌暴龙队','未读','2024-11-19 16:30:48','2024-11-19 16:30:48','2024-11-19 16:30:48'),(3,'2024000002','入队申请结果提醒','恭喜您已加入义警队伍：无敌暴龙队','未读','2024-11-19 16:30:48','2024-11-19 16:30:48','2024-11-19 16:30:48'),(4,'2024000002','入队申请结果提醒','恭喜你已经加入义警队伍：无敌暴龙队','未读','2024-11-20 00:04:02','2024-11-20 00:04:02','2024-11-20 00:04:02'),(5,'2024000001','商品发货提醒','您的单号为：4的快递已发货，请关注物流信息','未读','2024-11-27 09:58:55','2024-11-27 09:58:55','2024-11-27 09:58:55'),(6,'2024000001','商品发货提醒','您的单号为：5的快递已发货，请关注物流信息','未读','2024-11-27 09:59:53','2024-11-27 09:59:53','2024-11-27 09:59:53'),(7,'2024000001','商品发货提醒','您的单号为：6的快递已发货，请关注物流信息','未读','2024-11-27 09:59:57','2024-11-27 09:59:57','2024-11-27 09:59:57'),(8,'2024000002','其它','您已被移出所在义警队伍','未读','2024-11-27 11:23:05','2024-11-27 11:23:05','2024-11-27 11:23:05'),(9,'2024000001','商品发货提醒','您的单号为：57的快递已发货，请关注物流信息','未读','2024-11-27 22:29:47','2024-11-27 22:29:47','2024-11-27 22:29:47'),(10,'2024000004','入队申请结果提醒','恭喜你已经加入义警队伍：扫黑除恶队','未读','2024-11-27 22:43:24','2024-11-27 22:43:24','2024-11-27 22:43:24'),(11,'2024000001','其它','您所在的队伍已被指派进行任务：安全行动，已自动为您指派报名，请及时查看报名信息，同时已为您取消时间冲突的任务','未读','2024-11-28 10:59:03','2024-11-28 10:59:03','2024-11-28 10:59:03'),(12,'2024000002','其它','您所在的队伍已被指派进行任务：安全行动，已自动为您指派报名，请及时查看报名信息，同时已为您取消时间冲突的任务','未读','2024-11-28 10:59:03','2024-11-28 10:59:03','2024-11-28 10:59:03'),(13,'2024000002','入队申请结果提醒','恭喜你已经加入义警队伍：无敌暴龙队','未读','2024-11-28 20:43:36','2024-11-28 20:43:36','2024-11-28 20:43:36'),(14,'2024000021','商品发货提醒','您的单号为：58的快递已发货，请关注物流信息','未读','2024-11-29 11:01:07','2024-11-29 11:01:07','2024-11-29 11:01:07'),(15,'2024000021','商品发货提醒','您的单号为：59的快递已发货，请关注物流信息','未读','2024-11-29 13:43:43','2024-11-29 13:43:43','2024-11-29 13:43:43'),(16,'2024000021','商品发货提醒','您的单号为：60的快递已发货，请关注物流信息','未读','2024-11-29 13:46:14','2024-11-29 13:46:14','2024-11-29 13:46:14'),(17,'2024000024','商品发货提醒','您的单号为：61的快递已发货，请关注物流信息','已读','2024-11-29 15:31:31','2024-11-29 15:31:43','2024-11-29 15:31:31'),(18,'2024000024','商品发货提醒','您的单号为：61的快递已发货，请关注物流信息','未读','2024-11-29 16:51:33','2024-11-29 16:51:33','2024-11-29 16:51:33');
/*!40000 ALTER TABLE `vigilante_notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:38
