CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `team` (
  `team_id` char(10) NOT NULL COMMENT '队伍编号',
  `team_size` int NOT NULL COMMENT '队伍人数',
  `team_level` enum('大队','中队','小队') NOT NULL COMMENT '队伍等级',
  `team_name` varchar(50) NOT NULL COMMENT '队伍名称',
  `team_description` text COMMENT '队伍简介',
  `team_avatar_path` varchar(255) DEFAULT NULL COMMENT '队伍头像存储路径',
  `service_area` varchar(100) DEFAULT NULL COMMENT '服务区域',
  `establishment_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '成立时间',
  `total_service_duration` double DEFAULT '0' COMMENT '服务时长汇总',
  `captain_id` char(10) DEFAULT NULL COMMENT '队长编号（外键）',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  PRIMARY KEY (`team_id`),
  KEY `FK_队伍信息` (`captain_id`),
  CONSTRAINT `FK_队伍信息` FOREIGN KEY (`captain_id`) REFERENCES `vigilante` (`vigilante_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
INSERT INTO `team` VALUES ('2024000001',3,'大队','无敌暴龙队','你好好好好好好好好好好好好好好好','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','岳麓区','2024-11-19 16:30:48',0,'2024000024','2024-11-19 16:30:48','2024-11-29 15:38:45'),('2024000002',2,'小队','扫黑除恶队','非常好队伍','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','岳麓区','2024-11-27 22:00:48',0,'2024000003','2024-11-27 22:00:48','2024-11-27 22:43:24'),('2024000003',1,'小队','海底小纵队二号','非常好队伍','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','天心区','2024-11-29 00:28:36',0,'2024000005','2024-11-29 00:29:07','2024-11-29 00:29:07'),('2024000004',1,'小队','海底小纵队三号','非常好队伍','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','芙蓉区','2024-11-29 00:28:39',0,'2024000006','2024-11-29 00:29:07','2024-11-29 00:29:07'),('2024000005',1,'小队','海底小纵队四号','非常好队伍','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','芙蓉区','2024-11-29 00:28:41',0,'2024000007','2024-11-29 00:29:07','2024-11-29 00:29:07'),('2024000006',1,'小队','海底小纵队五号','非常好队伍','https://vigilante.oss-cn-shenzhen.aliyuncs.com/130540d8-bdfe-4c10-8347-5e9727d5975a.png','雨花区','2024-11-29 00:28:43',0,'2024000008','2024-11-29 00:29:07','2024-11-29 00:29:07');
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:37
