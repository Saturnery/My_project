CREATE DATABASE  IF NOT EXISTS `band` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `band`;
-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: band
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `points_details`
--

DROP TABLE IF EXISTS `points_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `points_details` (
  `points_detail_id` int NOT NULL AUTO_INCREMENT COMMENT '积分表编号',
  `vigilante_id` char(10) DEFAULT NULL COMMENT '义警编号（外键）',
  `type` enum('任务获取','信息上报获取','发圈获取','兑换商品') NOT NULL COMMENT '获取类型',
  `points_earned` int NOT NULL COMMENT '获取积分数',
  `gmt_create` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '修改时间',
  `source` char(20) DEFAULT NULL,
  PRIMARY KEY (`points_detail_id`),
  KEY `FK_积分明细` (`vigilante_id`),
  CONSTRAINT `FK_积分明细` FOREIGN KEY (`vigilante_id`) REFERENCES `vigilante` (`vigilante_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `points_details`
--

LOCK TABLES `points_details` WRITE;
/*!40000 ALTER TABLE `points_details` DISABLE KEYS */;
INSERT INTO `points_details` VALUES (1,'2024000001','兑换商品',-150,'2024-11-20 22:03:20','2024-11-20 22:03:20',NULL),(2,'2024000001','任务获取',13,'2024-11-26 10:55:29','2024-11-26 10:55:29','任务名称1'),(3,'2024000001','任务获取',14,'2024-11-26 10:57:13','2024-11-26 10:57:13','任务名称1'),(4,'2024000001','任务获取',20,'2024-11-26 13:40:22','2024-11-26 13:40:22','任务名称1'),(5,'2024000001','兑换商品',-13,'2024-11-27 10:21:27','2024-11-27 10:21:27','电子产品2 * 1'),(6,'2024000001','兑换商品',-100,'2024-11-27 22:25:09','2024-11-27 22:25:09','电子产品1 * 1'),(7,'2024000021','兑换商品',-100,'2024-11-29 11:00:03','2024-11-29 11:00:03','电子产品1 * 1'),(8,'2024000021','兑换商品',-40,'2024-11-29 13:42:39','2024-11-29 13:42:39','纸巾 * 1'),(9,'2024000021','兑换商品',-120,'2024-11-29 13:45:51','2024-11-29 13:45:51','保温杯 * 1'),(10,'2024000024','兑换商品',-120,'2024-11-29 15:31:04','2024-11-29 15:31:04','保温杯 * 1'),(11,'2024000025','兑换商品',-150,'2024-11-29 16:49:23','2024-11-29 16:49:23','泡面 * 1'),(12,'2024000026','兑换商品',-150,'2024-11-29 17:13:56','2024-11-29 17:13:56','泡面 * 1');
/*!40000 ALTER TABLE `points_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-06 16:33:42
