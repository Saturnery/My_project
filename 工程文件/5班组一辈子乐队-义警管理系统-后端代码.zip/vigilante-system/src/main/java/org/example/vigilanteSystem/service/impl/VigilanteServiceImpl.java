package org.example.vigilanteSystem.service.impl;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.*;
import org.example.vigilanteSystem.pojo.*;
import org.example.vigilanteSystem.service.VigilanteService;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.example.vigilanteSystem.utils.WebSocketServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 义警serviceImpl
 */
@Service
public class VigilanteServiceImpl implements VigilanteService {
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private WebSocketServer webSocketServer;
    @Autowired
    private PointsDetailsMapper pointsDetailsMapper;
    @Autowired
    private AdministratorMapper administratorMapper;
    @Autowired
    private TeamMapper teamMapper;
    @Autowired
    private VigilanteNotificationMapper vigilanteNotificationMapper;

    /**
     * 查看义警列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param name         名字
     * @param idCard       身份证号码
     * @param id           义警编号
     * @param phoneNumber   手机号码
     * @param startDate     开始时间
     * @param endDate       结束时间
     * @return              义警列表
     */
    @Override
    public PageBean<Vigilante> list(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startDate, LocalDate endDate) {
        //创建PageBean对象
        PageBean<Vigilante> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Vigilante> v = vigilanteMapper.list(name, idCard, id, phoneNumber, startDate, endDate);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Vigilante> p = (Page<Vigilante>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }


    /**
     * 查看未入队义警
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @return            未入队义警列表
     */
    @Override
    public PageBean<Map<String, Object>> listNoTeam(Integer pageNum,Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = vigilanteMapper.listNoTeam();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 入队
     * @param vigilanteId  义警编号
     * @param teamId       队伍编号
     */
    @Override
    public void joinTeam(String vigilanteId, String teamId) {
        vigilanteMapper.joinTeam(vigilanteId,teamId);
        //及时更新前端的teamId
        Map<String,Object> map = new HashMap<>();
        map.put("type",2);
        map.put("teamId",teamId);
        String json = JSON.toJSONString(map);
        webSocketServer.sendToClient("vigilante"+vigilanteId ,json);
    }

    /**
     * 退队
     * @param vigilanteId 义警编号
     * @param teamId      队伍编号
     */
    @Override
    public void dropTeam(String vigilanteId, String teamId) throws Exception {
        //判断是否为队伍负责人
        if(vigilanteId.equals(teamMapper.getCaptainIdByTeamId(teamId))){
            throw new Exception("队伍负责人无法退出队伍");
        }
        //判断是否已经退队
        Vigilante vigilante =vigilanteMapper.findById(vigilanteId);
        if(vigilante.getTeamId()==null||vigilante.getTeamId().isEmpty()){
            throw new Exception("您已退出该队伍");
        }
        if(vigilanteMapper.ifUnfinishedTask(vigilanteId)){
            throw new Exception("您有未完成或正在进行的任务，不可退出队伍");
        }
        //队伍人数减一
        teamMapper.reduceTeamSize(teamId);
        //义警退队
        vigilanteMapper.dropTeam(vigilanteId,teamId);
    }

    /**
     * 队伍成员列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param teamId       队伍编号
     * @param captainId    负责人编号
     * @return             队伍成员列表
     */
    @Override
    public PageBean<Map<String, Object>> listSpecificTeam(Integer pageNum, Integer pageSize, String teamId, String captainId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = vigilanteMapper.listSpecificTeam(teamId,captainId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 根据义警编号查询义警
     * @param vigilanteId 义警编号
     * @return            义警类
     */
    @Override
    public Vigilante findById(String vigilanteId) {
        return vigilanteMapper.findById(vigilanteId);
    }

    /**
     * 查看队伍负责人
     * @param captainId   负责人编号
     * @return            负责人信息
     */
    @Override
    public Map<String, Object> teamCaptain(String captainId) {
        return vigilanteMapper.teamCaptain(captainId);
    }

    /**
     * 统计义警人数
     * @return 义警总数
     */
    @Override
    public Integer vigilanteCounting() {
        return vigilanteMapper.vigilanteCounting();
    }

    /**
     * 义警信息上报
     * @param incidentReport  信息上报类
     */
    @Transactional
    @Override
    public void incidentReportVigilante(IncidentReport incidentReport) {
        //添加到信息上报表
        vigilanteMapper.incidentReportVigilante(incidentReport);
        Integer reportId = incidentReport.getReportId();

        //获取信息上报附件的存储路径
        List<Map<String,Object>> medias = incidentReport.getMedia();
        System.out.println(medias);
        for (int i=0;i<medias.size();i++) {
            Map<String,Object> media = medias.get(i);
            //获取附件类型
            String mediaType = (String) media.get("mediaType");
            //获取存储路径
            String storagePath = (String) media.get("storagePath");
            //添加信息到附件表
            vigilanteMapper.incidentMediaVigilante(reportId,i,mediaType,storagePath);
        }

        //更新管理员消息通知表
        administratorMapper.addNotification("消息上报审核提醒","上报单号"+reportId);
    }

    /**
     * 义警查看信息上报记录
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param vigilanteId    游客编号
     * @param reviewStatus   审核状态
     * @return               信息上报记录
     */
    @Override
    public PageBean<IncidentReport> incidentReportRecordVigilante(Integer pageNum, Integer pageSize, String vigilanteId, String reviewStatus) {
        //创建PageBean对象
        PageBean<IncidentReport> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<IncidentReport> v = vigilanteMapper.incidentReportRecordVigilante(vigilanteId,reviewStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<IncidentReport> p = (Page<IncidentReport>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 义警查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    @Override
    public List<Map<String, Object>> incidentMediaRecordVigilante(Integer reportId) throws Exception {
        if(!vigilanteMapper.findIncidentReportById(reportId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        if(!vigilanteMapper.findIncidentReportMediaById(reportId)){
            throw new Exception("该信息无附件");
        }
        return vigilanteMapper.incidentMediaRecordVigilante(reportId);
    }

    /**
     * 删除上报信息
     * @param params 信息上报编号
     */
    @Override
    public void incidentReportDelete(Map<String, Object> params) throws Exception {
        Integer reportId = (Integer) params.get("reportId");
        if(!vigilanteMapper.findIncidentReportById(reportId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        if(!vigilanteMapper.findIncidentReportStatusById(reportId).equals("已审核")){
            throw new Exception("不可删除未审核的信息上报记录");
        }
        vigilanteMapper.incidentReportDelete(reportId);
    }


    /**
     * 发布义警圈
     * @param dynamic 义警动态 类
     */
    @Transactional
    @Override
    public void publishDynamic(Dynamic dynamic) throws Exception {

        //添加到动态表
        vigilanteMapper.publishDynamic(dynamic);
        Integer dynamicId = dynamic.getDynamicId();

        //获取信息上报附件的存储路径
        List<Map<String,Object>> medias = dynamic.getMedia();
        for (int i=0;i<medias.size();i++) {
            Map<String,Object> media = medias.get(i);
            //获取附件类型
            String mediaType = (String) media.get("mediaType");
            //获取存储路径
            String storagePath = (String) media.get("storagePath");
            //添加信息到附件表
            vigilanteMapper.dynamicMedia(dynamicId,i,mediaType,storagePath);
        }

        if(vigilanteMapper.findDailyCirclePoints(dynamic.getVigilanteId()) < 3) {
            //触发器增加每日发布动态次数,更新积分明细表
            PointsDetails pointsDetails = new PointsDetails();
            pointsDetails.setType("发圈获取");
            pointsDetails.setVigilanteId(dynamic.getVigilanteId());
            pointsDetails.setPointsEarned(5);
            pointsDetails.setSource("发布义警圈");
            pointsDetailsMapper.addPointsDetails(pointsDetails);
        }

    }

    /**
     * 点赞
     * @param params （义警编号，动态编号）
     */
    @Override
    public void like(Map<String, Object> params) throws Exception {
        String vigilanteId = (String) params.get("vigilanteId");
        Integer dynamicId = (Integer) params.get("dynamicId");

        if(!vigilanteMapper.getDynamicById(dynamicId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }

        vigilanteMapper.like(vigilanteId,dynamicId);
    }

    /**
     * 评论
     * @param params （义警编号，动态编号，评论内容）
     */
    @Override
    public void comment(Map<String, Object> params) throws Exception {
        String vigilanteId = (String) params.get("vigilanteId");
        Integer dynamicId = (Integer) params.get("dynamicId");
        String commentContent = (String) params.get("commentContent");

        if(!vigilanteMapper.getDynamicById(dynamicId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }

        vigilanteMapper.comment(vigilanteId,dynamicId,commentContent);
    }

    /**
     * 义警圈列表
     * @param pageNum   页码
     * @param pageSize  每一页的行数
     * @return          义警圈列表
     */
    @Override
    public PageBean<Map<String, Object>> dynamicList(Integer pageNum, Integer pageSize, String vigilanteId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> dynamics = vigilanteMapper.dynamicList();

        for (Map<String, Object> map : dynamics) {
            Integer dynamicId = (Integer) map.get("dynamicId");
            if(vigilanteId!=null){
                //浏览者是否点赞
                boolean isLike = vigilanteMapper.isLike(dynamicId,vigilanteId);
                map.put("isLike", isLike);
            }
            //获取头像和昵称
            String vigilanteIdAuthor = (String) map.get("vigilanteId");
            Vigilante vigilante = vigilanteMapper.findById(vigilanteIdAuthor);
            String avatarPath = vigilante.getAvatarPath();
            String nickName = vigilante.getNickName();
            map.put("avatarPath", avatarPath);
            map.put("nickname", nickName);
            //获取附件
            List<Map<String,Object>> medias = vigilanteMapper.getDynamicMedia(dynamicId);
            map.put("medias", medias);
            //获取点赞
            List<String> likes = vigilanteMapper.getDynamicLike(dynamicId);
            map.put("likes", likes);
            //获取评论
            List<Map<String,Object>> comments = vigilanteMapper.getDynamicComment(dynamicId);
            map.put("comments", comments);
        }

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)dynamics;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看我发布的义警圈
     * @param pageNum   页码
     * @param pageSize  每一页的行数
     * @return          我发布的义警圈列表
     */
    @Override
    public PageBean<Map<String, Object>> dynamicListMyself(Integer pageNum, Integer pageSize, String vigilanteId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> dynamics = vigilanteMapper.dynamicListMyself(vigilanteId);

        for (Map<String, Object> map : dynamics) {
            Integer dynamicId = (Integer) map.get("dynamicId");
            if(vigilanteId!=null){
                //浏览者是否点赞
                boolean isLike = vigilanteMapper.isLike(dynamicId,vigilanteId);
                map.put("isLike", isLike);
            }
            //获取头像和昵称
            String vigilanteIdAuthor = (String) map.get("vigilanteId");
            Vigilante vigilante = vigilanteMapper.findById(vigilanteIdAuthor);
            String avatarPath = vigilante.getAvatarPath();
            String nickName = vigilante.getNickName();
            map.put("avatarPath", avatarPath);
            map.put("nickname", nickName);
            //获取附件
            List<Map<String,Object>> medias = vigilanteMapper.getDynamicMedia(dynamicId);
            map.put("medias", medias);
            //获取点赞
            List<String> likes = vigilanteMapper.getDynamicLike(dynamicId);
            map.put("likes", likes);
            //获取评论
            List<Map<String,Object>> comments = vigilanteMapper.getDynamicComment(dynamicId);
            map.put("comments", comments);
        }

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)dynamics;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 服务时长明细
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param vigilanteId  义警编号
     * @return             服务时长明细列表
     */
    @Override
    public PageBean<Map<String, Object>> durationList(Integer pageNum, Integer pageSize, String vigilanteId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = vigilanteMapper.durationList(vigilanteId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 切换义警账号状态
     * @param params 义警编号，账号状态
     */
    @Transactional
    @Override
    public void changeStatus(Map<String, Object> params) throws Exception {

        String vigilanteId = (String) params.get("vigilanteId");
        String vigilanteStatus = (String) params.get("vigilanteStatus");

        Map<String,Object> claims = ThreadLocalUtil.get();
        String adminId = (String) claims.get("id");
        if(adminId==null){
            throw new Exception("权限不足");
        }
        if(!(vigilanteStatus.equals("禁用")||vigilanteStatus.equals("启用"))){
            throw new Exception("信息缺失");
        }
        webSocketServer.sendToClient("vigilante"+vigilanteId,"4");
        vigilanteMapper.changeStatus(vigilanteId,vigilanteStatus);
        if(vigilanteStatus.equals("启用")){
            vigilanteNotificationMapper.add(vigilanteId,"其它","您的义警账号已被解除封禁，祝您生活愉快");
        }
    }

    /**
     * 获取义警未读消息数量
     * @param vigilanteId 义警编号
     * @return            未读消息数量
     */
    @Override
    public Integer messageCount(String vigilanteId) {
        return vigilanteMapper.messageCount(vigilanteId);
    }


    /**
     * 取消点赞
     * @param params （义警编号，动态编号）
     */
    @Override
    public void cancelLike(Map<String, Object> params) throws Exception {
        String vigilanteId = (String) params.get("vigilanteId");
        Integer dynamicId = (Integer) params.get("dynamicId");

        if(!vigilanteMapper.getDynamicById(dynamicId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        vigilanteMapper.cancelLike(dynamicId,vigilanteId);
    }

    /**
     * 删除动态
     * @param params （动态编号）
     */
    @Override
    public void dynamicDelete(Map<String, Object> params) throws Exception {
        Integer dynamicId = (Integer) params.get("dynamicId");
        if(!vigilanteMapper.getDynamicById(dynamicId)){
            throw new Exception("该动态已被删除，请刷新页面");
        }
        vigilanteMapper.dynamicDelete(dynamicId);
    }

    /**
     * 修改个人信息
     * @param params 个人信息
     */
    @Transactional
    @Override
    public void personalInfoModify(Map<String, Object> params) throws Exception {

        String avatarPath = (String) params.get("avatarPath");
        String nickname = (String) params.get("nickname");
        String phoneNumber = (String) params.get("phoneNumber");
        String workplace = (String) params.get("workplace");
        String expertise = (String) params.get("expertise");
        String gender = (String) params.get("gender");
        String occupation = (String) params.get("occupation");
        String politicalStatus = (String) params.get("politicalStatus");
        String education = (String) params.get("education");

        String vigilanteId = (String) params.get("vigilanteId");

        if(vigilanteMapper.isPhoneNumberRepeated(phoneNumber,vigilanteId)){
            throw new Exception("该电话号码已被使用");
        }

        vigilanteMapper.personalInfoModify(avatarPath,nickname,phoneNumber,workplace,
                expertise,gender,occupation,politicalStatus,education,vigilanteId);
    }


}
