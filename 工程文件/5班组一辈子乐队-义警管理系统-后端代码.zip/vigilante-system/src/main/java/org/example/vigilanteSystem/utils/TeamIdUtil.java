package org.example.vigilanteSystem.utils;

import org.example.vigilanteSystem.mapper.TeamMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;

/**
 * 生成队伍编号
 */
@Component
public class TeamIdUtil {
    @Autowired
    private TeamMapper teamMapper;

    /**
     * 生成队伍编号
     */
    public String generateTeamId(){
        //获取当前年份
        Calendar calendar = Calendar.getInstance();
        String currentYear = String.valueOf(calendar.get(Calendar.YEAR));
        //获取当前年份的最大序号
        String maxTeamId = teamMapper.findMaxNum(currentYear);
        if (maxTeamId != null) {
            int temp = Integer.parseInt(maxTeamId );
            temp++;
            maxTeamId  = String.valueOf(temp);
        } else {
            maxTeamId  = currentYear + "000001";
        }
        return maxTeamId ;
    }
}