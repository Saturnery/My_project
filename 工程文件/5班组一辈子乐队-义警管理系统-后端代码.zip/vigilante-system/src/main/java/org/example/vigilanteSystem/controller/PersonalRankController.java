package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.service.PersonalRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/personal_rank")
public class PersonalRankController {

    @Autowired
    private PersonalRankService personalRankService;


    /**
     * 查看服务时长排名月榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/month")
    public Result<PageBean<Map<String,Object>>> monthVigilante(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = personalRankService.monthVigilante(pageNum,pageSize);
        return Result.success(pb);
    }

    /**
     * 查看服务时长排名季榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/quarter")
    public Result<PageBean<Map<String,Object>>> quarterVigilante(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = personalRankService.quarterVigilante(pageNum,pageSize);
        return Result.success(pb);
    }


    /**
     * 查看服务时长排名年榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/year")
    public Result<PageBean<Map<String,Object>>> yearVigilante(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = personalRankService.yearVigilante(pageNum,pageSize);
        return Result.success(pb);
    }

    /**
     * 查看服务时长排名总榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/total")
    public Result<PageBean<Map<String,Object>>> totalVigilante(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = personalRankService.totalVigilante(pageNum,pageSize);
        return Result.success(pb);
    }

}
