package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.*;
import org.example.vigilanteSystem.service.ShoppingService;
import org.example.vigilanteSystem.service.VigilanteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;


import java.time.LocalDate;
import java.util.Map;


@RestController
@RequestMapping("/shopping")
public class ShoppingController {

    @Autowired
    private ShoppingService shoppingService;
    @Autowired
    private VigilanteService vigilanteService;

    /**
     * 导入商品信息（名称，所需积分，库存，供应商，描述，类型,图片以文件形式传递）
     * @param product       商品类
     * @return              商品列表
     */
    @PostMapping("/add_product")
    public Result addProduct(@RequestBody Product product){
        shoppingService.addProduct(product);
        return Result.success();
    }

    /**
     * 获取商品列表（已上架）
     * @param pageNum             页码
     * @param pageSize            每一页的行数
     * @param productName         商品名称
     * @param productType         商品类型
     * @param productId           商品编号
     * @return                    已上架商品列表
     */
    @GetMapping("/list_on")
    public Result<PageBean<Product>> listOn(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String productName,
            @RequestParam(required = false) String productType,
            @RequestParam(required = false) String productId)
    {
        if(productType == null || productType.equals("全部")){
            productType = null;
        }
        PageBean<Product> pb = shoppingService.listOn(pageNum,pageSize,productName,productType,productId);
        return Result.success(pb);
    }

    /**
     * 获取商品列表（已下架）
     * @param pageNum              页码
     * @param pageSize             每一页的行数
     * @param productName          商品名称
     * @param productType          商品类型
     * @param productId            商品编号
     * @return                     已下架商品列表
     */
    @GetMapping("/list_off")
    public Result<PageBean<Product>> listOff(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String productName,
            @RequestParam(required = false) String productType,
            @RequestParam(required = false) String productId)
    {
        PageBean<Product> pb = shoppingService.listOff(pageNum,pageSize,productName,productType,productId);
        return Result.success(pb);
    }


    /**
     * 切换商品状态（下架或上架）
     * @param productId               商品编号
     * @param productStatus           商品状态
     * @return                        切换结果
     */
    @PostMapping("/turn_status")
    public Result turnStatus(@RequestParam Integer productId,@RequestParam String productStatus){
        if(!productStatus.equals("上架") && !productStatus.equals("下架")){
            return Result.error("无效的状态");
        }
        shoppingService.turnStatus(productId,productStatus);
        return Result.success();
    }

    /**
     * 删除商品
     * @param productId          商品编号
     * @return                   操作结果
     */
    @PostMapping("/delete_product")
    public Result deleteProduct(@RequestParam Integer productId){
        try {
            shoppingService.deleteProduct(productId);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 修改商品信息
     * @param product            商品类
     * @return                   操作结果
     */
    @PostMapping("/modify")
    public Result modifyProduct(@RequestBody Product product){
        shoppingService.modifyProduct(product);
        return Result.success();
    }

    /**
     * 获取订单列表（）
     * @param pageNum           页码
     * @param pageSize          每一页的行数
     * @param status            状态
     * @param orderId           订单编号
     * @param vigilanteId       义警编号
     * @param productId         商品编号
     * @param startTime         开始时间
     * @param endTime           结束时间
     * @return                  订单列表
     */
    @GetMapping("/list_orders")
    public Result<PageBean<Order>> listOrder(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String orderId,
            @RequestParam(required = false) String vigilanteId,
            @RequestParam(required = false) String productId,
            @RequestParam(required = false) LocalDate startTime,
            @RequestParam(required = false) LocalDate endTime,
            @RequestParam(required = false) String antiStatus)
    {
        PageBean<Order> pb = shoppingService.listOrder(pageNum,pageSize,orderId,vigilanteId,productId,status,startTime,endTime,antiStatus);
        return Result.success(pb);
    }


    /**
     * 义警兑换商品（涉及四个表：订单表（添加订单），商品表（修改库存），义警表（扣除积分），积分明细表）
     * @param order              订单类
     * @return                   兑换结果
     */
    @Transactional
    @PostMapping("/exchange")
    public Result exchange(@RequestBody Order order){
        try{
            //用户购买商品
            shoppingService.exchange(order);
            return Result.success();
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }


    /**
     * 查询用户购买记录
     * @param vigilanteId               义警编号
     * @param orderStatus               订单状态
     * @return                          购买记录列表
     */
    @GetMapping("/record")
    public Result<PageBean<Map<String,Object>>> getShoppingRecord(Integer pageNum,Integer pageSize,@RequestParam String vigilanteId,@RequestParam String orderStatus){
        PageBean<Map<String,Object>> pb = shoppingService.getShoppingRecord(pageNum,pageSize,vigilanteId,orderStatus);
        return Result.success(pb);
    }

    /**
     * 用户签收
     */
    @PostMapping("/signed")
    public Result signed(@RequestParam Integer orderId){
        shoppingService.signed(orderId);
        return Result.success();
    }


    /**
     * 管理员发货
     * @param orderId             订单编号
     * @param vigilanteId         义警编号
     * @return                    操作结果
     */
    @PostMapping("/deliver")
    public Result deliver(@RequestBody Map<String,Object> params){
        try {
            shoppingService.deliver(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 管理员预览订单中的商品信息
     * @param productId          商品编号
     * @return                   商品预览信息列表
     */
   @GetMapping("/product_preview")
    public Result<Map<String,Order>> productPreview(@RequestParam Integer productId){
       System.out.println(productId);
        Map<String,Order> map = shoppingService.productPreview(productId);
        return Result.success(map);
    }

}
