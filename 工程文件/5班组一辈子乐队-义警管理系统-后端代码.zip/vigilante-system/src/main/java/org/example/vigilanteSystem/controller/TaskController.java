package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.pojo.TaskApplication;
import org.example.vigilanteSystem.pojo.TaskDetail;
import org.example.vigilanteSystem.service.TaskService;
import org.example.vigilanteSystem.utils.DistanceCalculator;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;


@RestController
@RequestMapping("/task")
public class TaskController {
    @Autowired
    private TaskService taskService;
    @Autowired
    private DistanceCalculator distanceCalculator;

    /**
     * 管理员查看全部任务列表
     * @param pageNum          页码
     * @param pageSize         每一页的行数
     * @param taskId           任务编号
     * @param taskName         任务名称
     * @param taskType         任务类型
     * @param taskDifficulty   任务难度
     * @param taskStatus       任务状态
     * @param startDate        开始日期
     * @param endDate          结束日期
     * @return                 任务列表
     */
    @Transactional
    @GetMapping("/list_all")
    public Result<PageBean<TaskDetail>> listAll
            (Integer pageNum, Integer pageSize,
             @RequestParam(required = false) Integer taskId,
             @RequestParam(required = false) String taskName,
             @RequestParam(required = false) String taskType,
             @RequestParam(required = false) String taskDifficulty,
             @RequestParam(required = false) String taskStatus,
             @RequestParam(required = false) LocalDate startDate,
             @RequestParam(required = false) LocalDate endDate)
    {
        PageBean<TaskDetail> pb = taskService.listAll(pageNum,pageSize,taskId,taskName,taskType,taskDifficulty,taskStatus,startDate,endDate);
        return Result.success(pb);
    }


    /**
     * 微信小程序端查看可报名任务
     * @param pageNum          页码
     * @param pageSize         每一页的行数
     * @param vigilanteId      义警编号
     * @param taskType         任务类型
     * @return                 可报名任务列表
     */
    @Transactional
    @GetMapping("list_to_register")
    public Result<PageBean<TaskDetail>> listToRegister(Integer pageNum,Integer pageSize,String vigilanteId,String taskType){
        if(taskType == null || taskType.equals("全部")){
            taskType = null;
        }
        PageBean<TaskDetail> pb = taskService.listToRegister(pageNum,pageSize,vigilanteId,taskType);
        return Result.success(pb);
    }


    /**
     * 查看已报名当前任务的所有义警
     * @param taskId             任务编号
     * @return                   已报名义警信息列表
     */
    @Transactional
    @GetMapping("/list_member")
    public Result<List<Map<String,Object>>> listMember(Integer taskId){
        List<Map<String,Object>> members = taskService.listMember(taskId);
        return Result.success(members);
    }

    /**
     * 义警查看”我的任务“
     * @param pageNum                     页码
     * @param pageSize                   每一页的行数
     * @param vigilanteId                义警编号
     * @param taskStatus                 任务状态
     * @return                           “我的任务”列表
     */
    @Transactional
    @GetMapping("/my_task")
    public Result<PageBean<TaskDetail>> myTask(Integer pageNum,Integer pageSize,String vigilanteId,String taskStatus){
        PageBean<TaskDetail> pb = taskService.myTask(pageNum,pageSize,vigilanteId,taskStatus);
        return Result.success(pb);
    }


    /**
     * 负责人查看我管理的任务
     * @param pageNum               页码
     * @param pageSize              每一页的行数
     * @param teamId                队伍编号
     * @param taskStatus            任务状态
     * @return                      ”我管理的任务“列表
     */
    @GetMapping("/my_admin_task")
    public Result<PageBean<TaskDetail>> myAdminTask(Integer pageNum,Integer pageSize,String teamId,String taskStatus){
        PageBean<TaskDetail> pb = taskService.myAdminTask(pageNum,pageSize,teamId,taskStatus);
        return Result.success(pb);
    }


    /**
     * 任务报名
     * @param vigilanteId           义警编号
     * @param taskId                任务编号
     * @return                      操作结果
     */
    @Transactional
    @PostMapping("/sign")
    public Result sign(String vigilanteId, Integer taskId){
        try{
            //更新任务报名表
            taskService.sign(vigilanteId,taskId);
            //任务报名人数加一
            taskService.addTaskMember(taskId);
            return Result.success();
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }


    /**
     * 取消报名
     * @param vigilanteId      义警编号
     * @param taskId           任务编号
     * @return                 操作结果
     */
    @Transactional
    @PostMapping("/cancel_sign")
    public Result cancelSign(String vigilanteId, Integer taskId){
        //任务报名人数减一
        taskService.reduceTaskMember(taskId);
        //在任务报名表中删除信息
        taskService.cancelSign(vigilanteId,taskId);
        return Result.success();
    }

    /**
     * 管理员审核任务申请
     * @param params
     * @return  操作结果
     */
    @Transactional
    @PostMapping("/review")
    public Result review(@RequestBody Map<String,Object> map){
        Map<String,Object> params = (Map<String, Object>) map.get("params");
        //解析数据（任务申请单号，审核状态，审核意见）
        Integer taskId = (Integer) params.get("taskId");
        String reviewStatus = (String) params.get("reviewStatus");
        String rejectionReason = (String) params.get("rejectionReason");

        //修改指定单号的审核状态，并更新任务表信息
        Map<String,Object> claims = ThreadLocalUtil.get();
        String reviewerId = (String) claims.get("id");

        taskService.review(taskId,reviewStatus,rejectionReason,reviewerId);
        return Result.success();
    }


    /**
     * 提交任务申请
     * @param taskApplication        任务申请类
     * @return                       操作结果
     */
    @Transactional
    @PostMapping("/apply")
    public Result apply(@RequestBody TaskApplication taskApplication){
        taskService.apply(taskApplication);
        return Result.success();
    }

    /**
     * 查看任务申请列表
     * @param pageNum          页码
     * @param pageSize         每一页的行数
     * @param taskId           任务编号
     * @param taskName         任务名称
     * @param taskType         任务类型
     * @param taskDifficulty   任务难度
     * @param reviewStatus     审核状态
     * @param startDate        开始日期
     * @param endDate          结束日期
     * @return                 任务申请列表
     */
    @Transactional
    @GetMapping("/list_apply")
    public Result<PageBean<TaskApplication>> listApply
            (Integer pageNum, Integer pageSize,
             @RequestParam(required = false) Integer taskId,
             @RequestParam(required = false) String taskName,
             @RequestParam(required = false) String taskType,
             @RequestParam(required = false) String taskDifficulty,
             @RequestParam(required = false) String reviewStatus,
             @RequestParam(required = false) LocalDate startDate,
             @RequestParam(required = false) LocalDate endDate)
    {
        try {
            PageBean<TaskApplication> pb = taskService.listApply(pageNum,pageSize,taskId,taskName,taskType,taskDifficulty,reviewStatus,startDate,endDate);
            return Result.success(pb);
        } catch (Exception e) {
            return Result.error(e.getMessage());
        }
    }


    /**
     * 任务签到
     * @return          操作结果
     */
    @Transactional
    @GetMapping("/check_in")
    public Result<LocalDateTime> checkIn(String vigilanteId,Integer taskId){
        taskService.checkIn(vigilanteId,taskId);
        return Result.success(LocalDateTime.now());
    }

    /**
     * 任务签退
     * @param vigilanteId         义警编号
     * @param taskId              任务编号
     * @return                    操作结果
     */
    @Transactional
    @GetMapping("/check_out")
    public Result<Map<String,Object>> checkOut(String vigilanteId,Integer taskId){
        Map<String,Object> map = taskService.checkout(vigilanteId,taskId);
        return Result.success(map);
    }


    /**
     * 获取当前正在进行的任务（用于任务签到）
     * @param vigilanteId          义警编号
     * @return                     正在进行的任务列表
     */
    @GetMapping("task_now")
    public Result<Map<String,Object>> taskNow(String vigilanteId){
        Map<String,Object> map = taskService.taskNow(vigilanteId);
        if( map == null){
            return Result.error("当前没有正在进行的任务");
        }
        return Result.success(map);
    }


    /**
     * 管理员发布所有人抢单任务
     * @param taskDetail           任务类
     * @return                     操作结果
     */
    @PostMapping("/admin_task_all")
    public Result adminTaskAll(@RequestBody TaskDetail taskDetail){
        try {
            taskService.adminTaskAll(taskDetail);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }

    }

    /**
     * 管理员发布指派任务
     * @param taskDetail           任务类
     * @return                     操作结果
     */
    @Transactional
    @PostMapping("/admin_task_assign")
    public Result adminTaskAssign(@RequestBody TaskDetail taskDetail){
        try {
            taskService.adminTaskAssign(taskDetail);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 计算距离
     */
    @GetMapping("/distance")
    public Result distance(@RequestParam Double lat1, @RequestParam Double lon1, @RequestParam Double lat2, @RequestParam Double lon2){
        if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) {
            return Result.error("参数缺失");
        }
        return Result.success(distanceCalculator.calculateDistance(lat1,lon1,lat2,lon2));
    }


    /**
     * 删除任务
     * @param map 任务编号
     * @return
     */
    @PostMapping("/delete")
    public Result delete(@RequestBody Map<String,Object> params){
        try{
            taskService.delete(params);
            return Result.success();
        }catch (Exception e){
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


}


