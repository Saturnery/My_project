package org.example.vigilanteSystem.pojo;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//lombok 在编译阶段，为实体类自动生成setter   getter   toString
//pom 文件中引入依赖  在实体类上添加注解


/**
 * 管理员类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Administrator {
    @NotNull
    private String adminId;//主键（管理员编号）
    private String name;//管理员姓名
    private String idCard;//管理员身份证号
    private String phone;//手机号码
    private String policeNumber;//警察编号


    @JsonIgnore//springmvc把当前对象转换成json字符串的时候，忽略password，最终的json字符串中就没有password
    private String password;//密码
}
