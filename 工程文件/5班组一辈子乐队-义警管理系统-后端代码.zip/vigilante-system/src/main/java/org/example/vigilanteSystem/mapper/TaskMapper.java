package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.TaskApplication;
import org.example.vigilanteSystem.pojo.TaskDetail;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

/**
 * 任务mapper
 */
@Mapper
public interface TaskMapper {
    /**
     * 查询任务列表
     * @param taskId              任务编号
     * @param taskName            任务名称
     * @param taskType            任务类型
     * @param taskDifficulty      任务难度
     * @param taskStatus          任务状态
     * @param startDate           开始日期
     * @param endDate             结束日期
     * @return                    任务列表
     */
    List<TaskDetail> listAll(Integer taskId, String taskName, String taskType, String taskDifficulty, String taskStatus, LocalDate startDate, LocalDate endDate);

    /**
     * 申请任务
     * @param taskApplication     任务申请类
     */
    void apply(TaskApplication taskApplication);

    /**
     * 查询任务申请列表(已审核)
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param reviewStatus         审核类型
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     任务申请列表
     */
    List<TaskApplication> listApplyUnfinished(Integer taskId, String taskName, String taskType, String taskDifficulty, String reviewStatus, LocalDate startDate, LocalDate endDate);

    /**
     * 查询任务申请列表(未审核)
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param reviewStatus         审核类型
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     任务申请列表
     */
    List<TaskApplication> listApplyFinished(Integer taskId, String taskName, String taskType, String taskDifficulty, String reviewStatus, LocalDate startDate, LocalDate endDate);


    /**
     * 管理员审核任务申请
     * @param taskId             任务编号
     * @param reviewStatus       审核状态
     * @param rejectionReason    拒绝原因
     * @param reviewerId         审核人编号
     */
    void review(Integer taskId, String reviewStatus, String rejectionReason, String reviewerId);

    /**
     * 根据任务申请单号查询
     * @param taskId   任务编号
     * @return         任务申请类
     */
    TaskApplication findByApplicationId(Integer taskId);

    /**
     * 根据任务编号查询
     * @param taskId 任务编号
     * @return       任务类
     */
    TaskDetail findByTaskId(Integer taskId);

    /**
     * 更新任务表（审核通过）
     * @param ta 任务申请类
     */
    void addTask(TaskApplication ta);

    /**
     * 义警查看“我的任务”
     * @param vigilanteId 义警编号
     * @param taskStatus  任务状态
     * @return            任务列表
     */
    List<TaskDetail> myTask(String vigilanteId, String taskStatus);

    /**
     * 任务报名人数加一
     * @param taskId 任务编号
     */
    void addTaskMember(Integer taskId);

    /**
     * 义警报名后更新任务报名表
     * @param vigilanteId 义警编号
     * @param taskId      任务编号
     */
    void sign(String vigilanteId, Integer taskId);

    /**
     * 查看报名了当前任务的所有义警
     * @param taskId  任务编号
     * @return        报名了当前任务的所有义警列表
     */
    List<Map<String, Object>> listMembers(Integer taskId);

    /**
     * 查找当前要报名的任务是否与已经报名的任务存在时间上的重叠
     * @param taskDate               任务日期
     * @param taskStartTime          开始时间
     * @param taskEndTime            结束时间
     * @param vigilanteId            义警编号
     * @return                       当前要报名的任务是否与已经报名的任务存在时间上的重叠
     */
    boolean ifTimeOverlaps(LocalDate taskDate, LocalTime taskStartTime, LocalTime taskEndTime, String vigilanteId);

    /**
     * 任务签到
     * @param vigilanteId 义警编号
     * @param taskId      任务编号
     */
    void checkIn(String vigilanteId, Integer taskId);

    /**
     * 查询任务报名表
     * @param vigilanteId 义警编号
     * @param taskId      任务编号
     * @return            任务列表
     */
    Map<String,Object> findTaskRegistration(String vigilanteId, Integer taskId);

    /**
     * 签退
     * @param vigilanteId       义警编号
     * @param taskId            任务编号
     * @param checkOutTime      签退时间
     * @param earnedPoints      获取的积分
     * @param serviceTime       服务时长
     */
    void checkOut(String vigilanteId, Integer taskId, LocalDateTime checkOutTime, int earnedPoints, double serviceTime);

    /**
     * 微信小程序端查看所有可报名任务
     * @param vigilanteId 义警编号
     * @param taskType    任务类型
     */
    List<TaskDetail> listToRegister(String vigilanteId, String taskType);

    /**
     * 任务报名人数减一
     * @param taskId 任务编号
     */
    void reduceTaskMember(Integer taskId);

    /**
     * 在任务报名表中删除信息
     * @param vigilanteId 义警编号
     * @param taskId      任务编号
     */
    void cancelSign(String vigilanteId, Integer taskId);

    /**
     * 获取当前正在进行的任务（用于任务签到）
     * @param vigilanteId 义警编号
     * @return            当前正在进行的任务信息
     */
    Map<String, Object> taskNow(String vigilanteId);

    /**
     * 管理员直接发布所有人抢单任务
     * @param taskDetail 任务类
     */
    void adminTaskAll(TaskDetail taskDetail);

    /**
     * 负责人查看“我管理的任务”
     * @param teamId      队伍编号
     * @param taskStatus  任务状态
     * @return            任务列表
     */
    List<TaskDetail> myAdminTask(String teamId, String taskStatus);

    /**
     * /管理员发布指派任务
     * @param taskDetail 任务类
     */
    void adminTaskAssign(TaskDetail taskDetail);

    /**
     * 查找与指派任务时间冲突的任务编号
     * @param taskDate            任务日期
     * @param taskStartTime       任务开始时间
     * @param taskEndTime         任务结束时间
     * @param memberId            参与人员编号
     * @return                    与指派任务时间冲突的任务编号
     */
    Integer findTimeOverlaps(LocalDate taskDate, LocalTime taskStartTime, LocalTime taskEndTime, String memberId);

    /**
     * 统计总任务数
     * @return 总任务数
     */
    Integer taskCounting();

    /**
     * 统计我的任务数量（包括已完成，已报名，正在进行）
     * @param vigilanteId 义警编号
     * @return            我的任务数量
     */
    Integer myTaskCounting(String vigilanteId);

    /**
     * 查找参与某一任务的所有义警（返回编号）
     * @param taskId 任务编号
     * @return       参与某一任务的所有义警（返回编号）
     */
    List<String> findTaskMember(Integer taskId);

    /**
     * 查找该义警报名的所有“未开始”的任务（当义警退队时，会取消报名所有待完成的任务）
     * @param vigilanteId 义警编号
     * @return            该义警报名的所有“未开始”的任务编号
     */
    List<Integer> findAllUnfinishedTask(String vigilanteId);

    /**
     * 删除任务信息
     * @param taskId 任务编号
     */
    void delete(Integer taskId);
}
