package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
//lombok 在编译阶段，为实体类自动生成setter   getter   toString

/**
 * 义警审核类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class VigilanteRegistrationReview {
    private Integer registrationId;      //义警注册审核单号（主键）
    private String name;                 //名字
    private String idCardNumber;         //身份证号
    private String gender;               //性别
    private String reviewerId;           //审核人编号
    private String visitorId;            //游客编号
    private String phoneNumber;          //电话号码
    private String politicalStatus;      //政治身份
    private String workPlace;            //工作单位
    private String occupation;           //职业
    private String education;            //学历
    private String expertise;            //专长（可以为空）
    private String reviewerName;         //审核人编号（可以为空）
    private String reviewStatus;         //审核状态（可以为空）
    private String rejectionReason;      //驳回意见（可以为空）
    private String commitmentLetterPath; //承诺书存储路径
    private String idCardFrontPath;      //身份证正面照存储路径
    private String idCardBackPath;       //身份证反面照存储路径
    private LocalDate requestTime;       //申请时间
    private LocalDate reviewTime;        //审核时间
}
