package org.example.vigilanteSystem.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 任务状态更新定时器
 */
@Component
public class TaskStatusScheduler {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private OnGoingTask onGoingTask;

    /**
     * 转换任务状态，并将正在进行的任务加入队列
     */
    @Scheduled(fixedRate = 60000) // 每分钟更新一次任务状态
    public void updateTaskStatus() {
        // 查询即将转为“正在进行”状态的任务ID
        String querySql = """  
            SELECT task_id FROM band.task_detail
            WHERE NOW() BETWEEN CONCAT(task_date, ' ', task_start_time)
            AND CONCAT(task_date, ' ', task_end_time)
            AND task_status != '正在进行'
        """;

        List<Integer> taskIdsToUpdate = jdbcTemplate.queryForList(querySql, Integer.class);
        //放入全局列表
        for (Integer taskId : taskIdsToUpdate) {
            onGoingTask.addOnGoingTask(taskId);
        }

        // 查询即将转为“已完成”状态的任务ID
        String queryCompletedSql = """  
            SELECT task_id FROM band.task_detail
            WHERE NOW() > CONCAT(task_date, ' ', task_end_time)
            AND task_status != '已完成'
        """;

        List<Integer> taskIdsToRemove = jdbcTemplate.queryForList(queryCompletedSql, Integer.class);

        // 从全局列表中删除已完成的任务
        for (Integer taskId : taskIdsToRemove) {
            onGoingTask.removeOnGoingTask(taskId);
        }


        //进行任务状态转变
        String sql = """
            update band.task_detail
            SET task_status = CASE
                WHEN NOW() < CONCAT(task_date, ' ', task_start_time) THEN '未开始'
                WHEN NOW() BETWEEN CONCAT(task_date, ' ', task_start_time) AND CONCAT(task_date, ' ', task_end_time) THEN '正在进行'
                ELSE '已完成'
            END
        """;
        jdbcTemplate.update(sql);
    }
}
