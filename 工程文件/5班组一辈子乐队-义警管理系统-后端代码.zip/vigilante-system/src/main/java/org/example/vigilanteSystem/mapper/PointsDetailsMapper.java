package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.PointsDetails;

import java.util.List;

/**
 * 积分明细mapper
 */
@Mapper
public interface PointsDetailsMapper {

    /**
     * 查询义警的积分明细
     * @param vigilanteId 义警编号
     * @return             积分明细列表
     */
    List<PointsDetails> list(String vigilanteId);

    /**
     * 更新义警的积分明细
     * @param pd         积分明细类
     */
    void addPointsDetails(PointsDetails pd);
}
