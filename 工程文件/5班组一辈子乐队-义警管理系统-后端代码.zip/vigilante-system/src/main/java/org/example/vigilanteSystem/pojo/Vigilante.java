package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * 义警类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Vigilante {
    private String vigilanteId;                  //义警编号（主键）
    private String realName;                     //真实姓名
    private String nickName;                     //昵称
    private String idNumber;                     //身份证号
    private String phoneNumber;                  //电话号码
    private String gender;                       //性别
    private String workplace;                    //工作单位
    private String occupation;                   //职业
    private String politicalStatus;              //政治身份
    private String education;                    //学历
    private String expertise;                    //专长
    private String commitmentPath;               //承诺书存储路径
    private String idFrontPath;                  //身份证正面照存储路径
    private String idBackPath;                   //身份证反面照存储路径
    private String avatarPath;                   //头像存储路径
    private String teamId;                       //队伍编号
    private Integer availablePoints;             //可用积分
    private String defaultAddress;               //默认收货地址
    private Integer dailyCirclePoints;           //可通过义警圈获得积分的次数（每天三次)
    private LocalDate registrationTime;          //注册时间
    private String openid;                       //微信用户标识
    private String vigilanteStatus;              //账号状态

}
