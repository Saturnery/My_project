package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 商品类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    private Integer productId;                //商品编号
    private String productName;               //商品名字
    private String productType;               //商品类型
    private String imagePath;                 //图片路径
    private String provider;                  //供应商
    private String description;               //描述
    private String productStatus;             //商品状态
    private Integer requiredPoints;           //需要的积分
    private Integer deliveryDeadline;         //发货时限（小时）
    private Integer stock;                    //库存

}
