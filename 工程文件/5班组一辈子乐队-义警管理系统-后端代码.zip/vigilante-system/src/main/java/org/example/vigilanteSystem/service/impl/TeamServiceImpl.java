package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.*;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Team;
import org.example.vigilanteSystem.pojo.Vigilante;
import org.example.vigilanteSystem.service.PersonalRankService;
import org.example.vigilanteSystem.service.TeamService;
import org.example.vigilanteSystem.utils.TeamIdUtil;
import org.example.vigilanteSystem.utils.WebSocketServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

/**
 * 队伍serviceImpl
 */
@Service
public class TeamServiceImpl implements TeamService {

    @Autowired
    private TeamMapper teamMapper;
    @Autowired
    private TaskMapper taskMapper;
    @Autowired
    private WebSocketServer webSocketServer;
    @Autowired
    private TeamIdUtil teamIdUtil;
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private PersonalRankMapper personalRankMapper;
    @Autowired
    private TeamRankMapper teamRankMapper;
    @Autowired
    private VigilanteNotificationMapper vigilanteNotificationMapper;

    /**
     * 查看队伍列表
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param teamId          队伍编号
     * @param teamLevel       队伍规模
     * @param teamName        队伍名称
     * @param startTime       开始日期
     * @param endTime         结束日期
     * @return                队伍列表
     */
    @Override
    public PageBean<Team> listTeam(Integer pageNum, Integer pageSize, String teamId, String teamLevel, String teamName, String startTime, String endTime) {
        //创建PageBean对象
        PageBean<Team> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Team> team = teamMapper.listTeam(teamId,teamLevel,teamName, startTime, endTime);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Team> p = (Page<Team>)team;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 创建队伍（管理员操作）
     * @param params          队伍信息
     */
    @Transactional
    @Override
    public void establishTeam(Map<String, Object> params) throws Exception {

        Map<String,Object> map = (Map<String, Object>)params.get("params");

        System.out.println(map);
        List<String> members = (List<String>) map.get("members");
        String captainId = (String) map.get("captainId");
        String teamLevel = (String) map.get("teamLevel");
        String teamName = (String) map.get("teamName");
        String teamDescription = (String) map.get("teamDescription");
        String teamAvatarPath = (String) map.get("teamAvatarPath");
        String serviceArea = (String) map.get("serviceArea");


        if(captainId == null){
            throw new Exception("必须指定队伍负责人");
        }

        //实时通知小程序用户
        webSocketServer.sendToClient("vigilante"+captainId, "2");

        //生成队伍编号
        String teamId = teamIdUtil.generateTeamId();
        Integer teamSize = members.size();

        //队伍总的服务时长
        double serviceDuration = 0;

        //更新队伍表，新添队伍信息
        teamMapper.establishTeam(captainId,teamLevel,teamName,teamDescription,teamAvatarPath,serviceArea,teamId,teamSize,serviceDuration);

        //对于每一个队伍成员
        for(String vigilanteId : members){
            //入队
            vigilanteMapper.joinTeam(vigilanteId,teamId);
            //消息通知表
            vigilanteNotificationMapper.add(vigilanteId,"其它","恭喜您已加入义警队伍："+ teamName);
            //计算此队伍总的服务时长
            serviceDuration += personalRankMapper.getPersonalTotalDuration(vigilanteId);
        }

        //在排名表里创建队伍
        teamRankMapper.addNewTeam(teamId,serviceDuration);
        //更新队伍的服务时长
        teamMapper.addDuration(serviceDuration,teamId);
    }

    /**
     * 修改头像
     * @param url        头像url
     * @param teamId     队伍编号
     */
    @Override
    public void modifyAvatar(String url, String teamId) {
        teamMapper.modifyAvatar(url,teamId);
    }

    /**
     * 入队申请
     * @param teamId       队伍编号
     * @param vigilanteId  义警编号
     */
    @Override
    public void joinRequest(String teamId, String vigilanteId) {
        teamMapper.joinRequest(teamId,vigilanteId);
    }


    /**
     * 查看入队申请队列（队伍负责人查看）
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @param teamId     队伍编号
     * @return           入队申请队列
     */
    @Override
    public PageBean<Map<String, Object>> joinRequestList(Integer pageNum,Integer pageSize,String teamId,String reviewResult) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = teamMapper.joinRequestList(teamId,reviewResult);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 队伍人数加一
     * @param teamId 队伍编号
     */
    @Transactional
    @Override
    public void addTeamSize(String teamId,String vigilanteId) throws Exception {
        //判断队伍人数是否已达上限
        Team team = teamMapper.findTeamByCaptainId(teamId);
        Integer teamSize = team.getTeamSize();
        String teamLevel = team.getTeamLevel();

        if(teamLevel.equals("小队")&&teamSize==20){
            throw new Exception("队伍人数已达上限");
        }
        if(teamLevel.equals("中队")&&teamSize==40) {
            throw new Exception("队伍人数已达上限");
        }
        if(teamLevel.equals("大队")&&teamSize==60) {
            throw new Exception("队伍人数已达上限");
        }
        //队伍人数加一
        teamMapper.addTeamSize(teamId);
        //更新队伍的服务时长
        double serviceDuration = personalRankMapper.getPersonalTotalDuration(vigilanteId);
        teamRankMapper.updateDuration(teamId,serviceDuration);
    }

    /**
     * 队伍人数减一
     * @param teamId 队伍编号
     */
    @Override
    public void reduceTeamSize(String vigilanteId, String teamId) {
        //更新队伍的服务时长
        double serviceDuration =  personalRankMapper.getPersonalTotalDuration(vigilanteId);
        teamRankMapper.updateDuration(teamId,-serviceDuration);
        //队伍人数减一
        teamMapper.reduceTeamSize(teamId);
    }

    /**
     * 入队申请审核
     * @param requestId           入队申请列表
     * @param reviewResult        审核结果
     */
    @Override
    public void joinRequestReview(Integer requestId, String reviewResult) {
        //更新入队申请表
        teamMapper.joinRequestReview(requestId,reviewResult);
    }

    /**
     * 踢出队伍成员
     * @param vigilanteId   义警编号
     */
    @Override
    public void kickOut(String teamId, String vigilanteId) throws Exception {
        Map<String,Object> claims = ThreadLocalUtil.get();
        String id = (String) claims.get("id");
        String captainId = teamMapper.getCaptainIdByTeamId(teamId);
        if(!id.equals(captainId)){
            throw new Exception("权限不足");
        }
        if (taskMapper.ifTimeOverlaps(LocalDate.now(), LocalTime.now(),LocalTime.now(),vigilanteId)){
            throw new Exception("该队员当前正在执行任务，无法将其移出队伍");
        }
        teamMapper.kickOut(vigilanteId);
        //更新前端的teamId
        webSocketServer.sendToClient("vigilante"+vigilanteId,"1");
    }

    /**
     * 查询一共有多少队伍
     * @return 队伍总数
     */
    @Override
    public Integer teamCounting() {
        return teamMapper.teamCounting();
    }

    /**
     * 更新队伍简介
     * @param description 简介
     * @param teamId      队伍编号
     */
    @Override
    public void modifyDescription(String description, String teamId) throws Exception {
        Map<String,Object> claims = ThreadLocalUtil.get();
        String id = (String) claims.get("id");
        String captainId = teamMapper.getCaptainIdByTeamId(teamId);
        if(!id.equals(captainId)){
            throw new Exception("权限不足");
        }
        teamMapper.modifyDescription(description,teamId);
    }

    /**
     * 更换队伍负责人
     * @param map 原负责人编号，新负责人编号，队伍编号
     */
    @Transactional
    @Override
    public void changeCaptain(Map<String, Object> map) throws Exception {
        //解析数据
        String oldCaptainId = (String) map.get("oldCaptainId");
        String newCaptainId = (String) map.get("newCaptainId");
        String teamId = (String) map.get("teamId");

        if(oldCaptainId==null||newCaptainId==null||teamId==null){
            throw new Exception("信息缺失");
        }

        if(oldCaptainId.equals(newCaptainId)){
            throw new Exception("新的负责人不能和当前负责人相同");
        }

        Vigilante vigilante = vigilanteMapper.findById(newCaptainId);
        if(vigilante.getVigilanteStatus().equals("禁用")){
            throw new Exception("此义警账号已被禁用,不可作为新的队伍负责人");
        }

        //更换队伍负责人
        teamMapper.changeCaptain(teamId,newCaptainId);
        //通知小程序用户
        webSocketServer.sendToClient("vigilante"+newCaptainId,"2");
        webSocketServer.sendToClient("vigilante"+oldCaptainId,"2");
        //消息通知
        vigilanteNotificationMapper.add(oldCaptainId,"其它","您已不再是当前队伍的负责人");
        vigilanteNotificationMapper.add(newCaptainId,"其它","您被指定为当前队伍的负责人");
    }

    /**
     * 判断义警是否可以申请入队
     * @param teamId        队伍编号
     * @param vigilanteId   义警编号
     * @return
     */
    @Override
    public boolean ifJoinRequest(String teamId, String vigilanteId) {
        return teamMapper.ifJoinRequest(teamId,vigilanteId);
    }

    /**
     * 根据队伍编号查找队伍信息
     * @param teamId 队伍编号
     * @return       队伍类
     */
    @Override
    public Team findByTeamId(String teamId) {
        return teamMapper.findByTeamId(teamId);
    }



}
