package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 入队申请类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JoinRequest {
    private Integer requestId;                    //入队申请编号
    private String initiatorVigilanteId;          //申请人编号
    private String teamId;                        //队伍编号
    private String reviewResult;                  //申请结果
    private String requestTime;                   //发起时间
    private String reviewTime;                    //审核时间
}
