package org.example.vigilanteSystem.controller;


import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.service.TeamRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;


@RestController
@RequestMapping("/team_rank")
public class TeamRankController {

    @Autowired
    private TeamRankService teamRankService;

    /**
     * 查看服务时长排名月榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/month")
    public Result<PageBean<Map<String,Object>>> monthTeam(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = teamRankService.monthTeam(pageNum,pageSize);
        return Result.success(pb);
    }

    /**
     * 查看服务时长排名季榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/quarter")
    public Result<PageBean<Map<String,Object>>> quarterTeam(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = teamRankService.quarterTeam(pageNum,pageSize);
        return Result.success(pb);
    }


    /**
     * 查看服务时长排名年榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/year")
    public Result<PageBean<Map<String,Object>>> yearTeam(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = teamRankService.yearTeam(pageNum,pageSize);
        return Result.success(pb);
    }

    /**
     * 查看服务时长排名总榜
     * @param pageNum  页码
     * @param pageSize 每一页的行数
     * @return         排名分页结果
     */
    @GetMapping("/total")
    public Result<PageBean<Map<String,Object>>> totalTeam(Integer pageNum, Integer pageSize) {
        PageBean<Map<String,Object>> pb = teamRankService.totalTeam(pageNum,pageSize);
        return Result.success(pb);
    }

}
