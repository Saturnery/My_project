package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 游客类
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Visitor {
    private String visitorId;             //游客编号
    private String openid;                //微信登录openid
    private String nickName;              //昵称
    private String avatarPath;            //头像存储路径
}
