package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * 义警圈类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Dynamic {
    private Integer dynamicId;                     // 动态编号
    private String vigilanteId;                    // 义警编号
    private String content;                        // 动态内容
    private String location;                       // 地址
    private LocalDateTime gmtCreate;               // 发布时间
    private List<Map<String,Object>> media;        // 图片或视频存储路径
}
