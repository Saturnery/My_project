package org.example.vigilanteSystem.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.example.vigilanteSystem.utils.JwtUtil;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Map;

/**
 * 登录拦截器
 */
@Component
public class LoginInterceptor implements HandlerInterceptor {

    /**
     * 登录拦截器
     * @param request      请求
     * @param response     响应
     * @return             是否放行
     * @throws Exception   异常
     */
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //令牌验证
        String token = request.getHeader("Authorization");
        String sessionKey = request.getHeader("Authentication");
        try{
            if(sessionKey != null){
                Map<String,Object> claims = JwtUtil.parseSessionKey(sessionKey);
                //把业务数据存储到ThreadLocal中
                ThreadLocalUtil.set(claims);
            }else if(token != null){
                Map<String,Object> claims = JwtUtil.parseToken(token);
                //把业务数据存储到ThreadLocal中
                ThreadLocalUtil.set(claims);
            }else {
                response.setStatus(401);
                return false;
            }
            // 通过验证
            return true;
        }catch (Exception e){
            response.setStatus(401);
            return false;
        }
    }

    /**
     * 在处理完请求后清理资源。
     * @param request    当前请求对象
     * @param response   当前响应对象
     * @param handler    处理该请求的控制器对象
     * @param ex         可能发生的异常，如果没有异常则为 null
     * @throws Exception 如果在清理过程中发生错误
     */
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        //清空ThreadLocal中的数据
        ThreadLocalUtil.remove();
    }
}