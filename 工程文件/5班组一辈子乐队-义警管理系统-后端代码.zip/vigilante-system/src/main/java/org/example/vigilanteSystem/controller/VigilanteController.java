package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.mapper.VigilanteMapper;
import org.example.vigilanteSystem.pojo.*;
import org.example.vigilanteSystem.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/vigilante")
public class VigilanteController {

    @Autowired
    private VigilanteService vigilanteService;
    @Autowired
    private VigilanteNotificationService vigilanteNotificationService;
    @Autowired
    private PointsDetailsService pointsDetailsService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private PersonalRankService personalRankService;


    /**
     * 管理员查看所有义警
     * @param pageNum             页码
     * @param pageSize            每一页的行数
     * @param name                名字
     * @param idCard              身份证号码
     * @param id                  义警编号
     * @param phoneNumber         电话号码
     * @param startDate           开始日期
     * @param endDate             结束日期
     * @return                    义警列表
     */
    @GetMapping("/list")
    public Result<PageBean<Vigilante>> list(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String idCard,
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String phoneNumber,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate)

    {
        PageBean<Vigilante> pb = vigilanteService.list(pageNum,pageSize,name,idCard,id,phoneNumber,startDate,endDate);
        return Result.success(pb);
    }


    /**
     * 更换义警账号的状态（禁用、启用）
     * @param params 义警编号，状态
     * @return
     */
    @PostMapping("/change_status")
    public Result<Boolean> changeStatus(@RequestBody Map<String, Object> params){
        try {
            vigilanteService.changeStatus(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 消息列表
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param readStatus      阅读状态（已读，未读）
     * @return                消息列表
     */
    @GetMapping("/message")
    public Result<PageBean<Map<String,Object>>> message(Integer pageNum, Integer pageSize, String readStatus, String vigilanteId){
        PageBean<Map<String,Object>> pb = vigilanteNotificationService.message(pageNum,pageSize,readStatus,vigilanteId);
        return Result.success(pb);
    }

    /**
     * 删除消息通知
     * @param notificationId           消息通知编号
     * @return                         操作结果
     */
    @PostMapping("/delete_message")
    public Result deleteMessage(@RequestParam Integer notificationId){
        vigilanteNotificationService.deleteMessage(notificationId);
        return Result.success();
    }

    /**
     * 标记为已读
     * @param notificationId        消息通知编号
     * @return                      操作结果
     */
    @PostMapping("/read_message")
    public Result readMessage(@RequestParam Integer notificationId){
        vigilanteNotificationService.readMessage(notificationId);
        return Result.success();
    }

    /**
     * 查看积分明细列表
     * @param vigilanteId           义警编号
     * @return                      积分明细列表
     */
    @GetMapping("/points_detail")
    public Result<PageBean<PointsDetails>> pointsDetail(Integer pageNum,Integer pageSize,String vigilanteId){
        PageBean<PointsDetails> pb = pointsDetailsService.list(pageNum,pageSize,vigilanteId);
        return Result.success(pb);
    }

    /**
     * 查看义警个人信息
     * @param vigilanteId        义警编号
     * @return                   义警个人信息
     */
    @GetMapping("/personal_info")
    public Result<Vigilante> personalInfo(String vigilanteId) {
        Vigilante vigilante = vigilanteService.findById(vigilanteId);
        vigilante.setIdNumber(null);
        vigilante.setIdBackPath(null);
        vigilante.setIdFrontPath(null);
        vigilante.setOpenid(null);
        return Result.success(vigilante);
    }

    /**
     * 获取义警个人信息界面初始化信息
     * @param vigilanteId          义警编号
     * @return                     初始信息
     */
    @GetMapping("/init_data")
    public Result<Map<String,Object>> initData(String vigilanteId){
        Map<String,Object> map = new HashMap<>();
        //获取可用爱心积分
        Vigilante vigilante = vigilanteService.findById(vigilanteId);
        Integer myPoints = vigilante.getAvailablePoints();
        //获取我参与的任务总数
        Integer myTask = taskService.myTaskCounting(vigilanteId);
        //获取我的总服务时长
        double myDuration = personalRankService.getPersonalTotalDuration(vigilanteId);
        //获取我的排名
        Integer myRank = personalRankService.getMyTotalRank(vigilanteId);

        map.put("myPoints",myPoints);
        map.put("myTask",myTask);
        map.put("myDuration",myDuration);
        map.put("myRank",myRank);

        return Result.success(map);
    }


    /**
     * 信息上报
     * @param incidentReport
     * @return
     */
    @PostMapping("/incident_report")
    public Result incidentReportVigilante(@RequestBody IncidentReport incidentReport) {
        vigilanteService.incidentReportVigilante(incidentReport);
        return Result.success();
    }

    /**
     * 义警查看我的信息上报记录
     * @param params
     * @return
     */
    @GetMapping("/incident_report_record")
    public Result<PageBean<IncidentReport>> incidentReportRecordVigilante(Integer pageNum,Integer pageSize,String vigilanteId,String reviewStatus){
        PageBean<IncidentReport> pb = vigilanteService.incidentReportRecordVigilante(pageNum,pageSize,vigilanteId,reviewStatus);
        return Result.success(pb);
    }

    /**
     * 义警查看某一信息上报记录的附件
     */
    @GetMapping("/incident_media_record")
    public Result<List<Map<String,Object>>> incidentMediaRecordVigilante(Integer reportId){
        List<Map<String,Object>> medias = null;
        try {
            medias = vigilanteService.incidentMediaRecordVigilante(reportId);
            return Result.success(medias);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除上报信息
     * @param params 信息上报编号
     * @return
     */
    @PostMapping("/incident_report_delete")
    public Result incidentReportDelete(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.incidentReportDelete(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }

    }


    /**
     * 发布义警圈
     * @param dynamic 义警动态 类
     * @return
     */
    @PostMapping("/publish_dynamic")
    public Result publishDynamic(@RequestBody Dynamic dynamic){
        try {
            vigilanteService.publishDynamic(dynamic);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 点赞
     * @param id
     * @return
     */
    @PostMapping("/like")
    public Result like(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.like(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 取消点赞
     * @param params
     * @return
     */
    @PostMapping("/cancel_like")
    public Result cancelLike(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.cancelLike(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 评论
     * @param params
     * @return
     */
    @PostMapping("/comment")
    public Result comment(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.comment(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


     /**
     * 浏览义警圈
     * @return  动态列表
     */
    @GetMapping("/dynamic_list")
    public Result<PageBean<Map<String,Object>>> dynamicList(Integer pageNum,Integer pageSize,@RequestParam(required = false) String vigilanteId){
        PageBean<Map<String,Object>> pb = vigilanteService.dynamicList(pageNum,pageSize,vigilanteId);
        return Result.success(pb);
    }

    /**
     * 查看"我发布的义警圈“
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param vigilanteId   义警编号
     * @return
     */
    @GetMapping("/dynamic_list_myself")
    public Result<PageBean<Map<String,Object>>> dynamicListMyself(Integer pageNum,Integer pageSize,@RequestParam String vigilanteId){
        PageBean<Map<String,Object>> pb = vigilanteService.dynamicListMyself(pageNum,pageSize,vigilanteId);
        return Result.success(pb);
    }

    /**
     * 删除动态
     * @param params
     * @return
     */
    @PostMapping("/dynamic_delete")
    public Result dynamicDelete(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.dynamicDelete(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());

        }
    }

    /**
     * 修改个人信息
     * @param params
     * @return
     */
    @PostMapping("/personal_info_modify")
    public Result personalInfoModify(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.personalInfoModify(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 服务时长明细
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param vigilanteId  义警编号
     * @return             服务时长明细列表
     */
    @GetMapping("/duration_list")
    public Result<PageBean<Map<String,Object>>> durationList(Integer pageNum,Integer pageSize,@RequestParam String vigilanteId){
        PageBean<Map<String,Object>> pb = vigilanteService.durationList(pageNum,pageSize,vigilanteId);
        return Result.success(pb);
    }

    /**
     * 获取未读消息数量
     */
    @GetMapping("/message_count")
    public Result messageCount(@RequestParam String vigilanteId){
        Integer messageCount = vigilanteService.messageCount(vigilanteId);
        return Result.success(messageCount);
    }

}
