package org.example.vigilanteSystem.service.impl;


import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.TeamRankMapper;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.service.TeamRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 队伍排行serviceImpl
 */
@Service
public class TeamRankServiceImpl implements TeamRankService {
    @Autowired
    private TeamRankMapper teamRankMapper;


    /**
     * 查看个人排名月榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> monthTeam(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = teamRankMapper.monthTeam();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名季榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> quarterTeam(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = teamRankMapper.quarterTeam();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名年榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> yearTeam(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = teamRankMapper.yearTeam();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名总榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> totalTeam(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = teamRankMapper.totalTeam();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }



}
