package org.example.vigilanteSystem.service;

/**
 * 验证码service
 */
public interface VerificationCodeService {

    /**
     * 生成验证码
     * @return 验证码
     */
    String generateVerificationCode();

    /**
     * 发送邮件
     * @param email  邮箱
     */
    void sendVerificationCode(String email);

    /**
     * 检查验证码是否正确
     * @param email  邮箱
     * @param code   验证码
     * @return       验证码是否正确
     */
    boolean verifyCode(String email, String code);
}
