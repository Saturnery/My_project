package org.example.vigilanteSystem.pojo;

import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 信息上报类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IncidentReport {
    private Integer reportId;           // 信息上报单号
    @Pattern(regexp = "治安秩序|环境秩序|消防安全|安全生产|矛盾纠纷|犯罪线索|其他线索", message = "请提交预定义的事件类型")
    private String eventType;           // 事件类型
    private String location;            // 所在地
    private String policeStation;       // 所属派出所
    private String detailedAddress;     // 详细地址
    private String contentDescription;  // 内容描述
    private String reviewStatus;        // 审核状态 (待审核, 已审核)
    private String reviewFeedback;      // 审核人回复
    @Pattern(regexp = "游客|义警", message = "请提交正确的上报人身份")
    private String reporterType;        // 上报人身份
    private String vigilanteId;         // 义警编号
    private String visitorId;           // 游客编号
    private String reviewerId;          // 审核人编号
    private LocalDate requestTime;      // 发起时间
    private LocalDate reviewTime;       // 审核时间
    private List<Map<String,Object>> media;   // 图片或视频存储路径
    private String reviewerName;        // 审核人姓名
}
