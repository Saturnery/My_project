package org.example.vigilanteSystem.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

/*
  积分明细类
 */
public class PointsDetails {
    private Integer pointsDetailId;        //积分明细编号
    private String vigilanteId;            //义警编号
    private String type;                   //类型
    private Integer pointsEarned;          //变化的积分
    private String source;                 //来源
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String gmtCreate;              //创建时间
}
