package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.*;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.VigilanteRegistrationReview;
import org.example.vigilanteSystem.service.VigilanteRegistrationReviewService;
import org.example.vigilanteSystem.utils.VigilanteIdUtil;
import org.example.vigilanteSystem.utils.WebSocketServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 义警注册审核serviceImpl
 */
@Service
public class VigilanteRegistrationReviewServiceImpl implements VigilanteRegistrationReviewService {
    @Autowired
    private VigilanteRegistrationReviewMapper vigilanteRegistrationReviewMapper;
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private VisitorNotificationMapper visitorNotificationMapper;
    @Autowired
    private VigilanteIdUtil vigilanteIdUtil;
    @Autowired
    private VisitorMapper visitorMapper;
    @Autowired
    private PersonalRankMapper personalRankMapper;
    @Autowired
    private WebSocketServer webSocketServer;
    @Autowired
    private AdministratorMapper administratorMapper;
    @Autowired
    private VigilanteNotificationMapper vigilanteNotificationMapper;


    /**
     * 查看未审核义警注册申请
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @param name       名字
     * @param idCard     身份证号码
     * @param id         义警编号
     * @param phoneNumber 手机号码
     * @param startTime   开始时间
     * @param endTime     结束时间
     * @return            未审核义警注册申请列表
     */
    @Override
    public PageBean<VigilanteRegistrationReview> listUnfinished(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime) {
        //创建PageBean对象
        PageBean<VigilanteRegistrationReview> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<VigilanteRegistrationReview> vrr = vigilanteRegistrationReviewMapper.listUnfinished(name, idCard, id, phoneNumber, startTime, endTime);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<VigilanteRegistrationReview> p = (Page<VigilanteRegistrationReview>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看已审核义警申请
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @param name        名字
     * @param idCard      身份证号码
     * @param id          义警编号
     * @param phoneNumber 手机号码
     * @param startTime   开始时间
     * @param endTime     结束时间
     * @return            已审核义警申请列表
     */
    @Override
    public PageBean<VigilanteRegistrationReview> listFinished(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime) {
        //创建PageBean对象
        PageBean<VigilanteRegistrationReview> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<VigilanteRegistrationReview> vrr = vigilanteRegistrationReviewMapper.listFinished(name, idCard, id, phoneNumber, startTime, endTime);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<VigilanteRegistrationReview> p = (Page<VigilanteRegistrationReview>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }


    /**
     * 管理员审核申请
     * @param id               申请编号
     * @param status           审核状态
     * @param reviewerName     审核人姓名
     * @param reviewerId       审核人编号
     * @param rejectionReason  拒绝原因
     */
    @Transactional
    @Override
    public void review(int id, String status, String reviewerName,String reviewerId, String rejectionReason) {
        vigilanteRegistrationReviewMapper.review(id, status, reviewerName, reviewerId, rejectionReason);
        VigilanteRegistrationReview vrr = vigilanteRegistrationReviewMapper.get(id);

        if(status.equals("审核通过")) {
            //生成义警编号
            String vigilanteId = vigilanteIdUtil.generateVigilanteId();
            //将义警注册申请的信息更新至义警表中
            String visitorId = vrr.getVisitorId();
            String openid = visitorMapper.getOpenid(visitorId);
            String avatarPath = visitorMapper.getAvatarPath(visitorId);
            String nickName = visitorMapper.getNickName(visitorId);
            vigilanteMapper.add(vrr,vigilanteId,openid,avatarPath,nickName);
            //消息通知给游客
            vigilanteNotificationMapper.add(vigilanteId,"注册审核结果提醒","恭喜您已通过审核,您的个人信息已更新");
            //更新前端的vigilanteId
            webSocketServer.sendToClient("visitor"+visitorId,"0");
            //更新服务时长排名表(新义警)
            personalRankMapper.addNewVigilante(vigilanteId);
        }else {
            visitorNotificationMapper.add(vrr.getVisitorId(),"义警注册审核提醒",rejectionReason);
        }
    }


    /**
     * 删除义警注册申请
     * @param id  申请编号
     */
    @Override
    public void delete(Integer id) {
        vigilanteRegistrationReviewMapper.delete(id);
    }

    /**
     * 提交义警注册申请
     * @param vrr  义警注册申请类
     */
    @Transactional
    @Override
    public void submit(VigilanteRegistrationReview vrr) throws Exception {
        //判断电话号码是否重复
        String phoneNumber = vrr.getPhoneNumber();
        if(vigilanteRegistrationReviewMapper.isPhoneNumberRepeated(phoneNumber)){
            throw new Exception("该电话号码已被使用");
        }
        vigilanteRegistrationReviewMapper.add(vrr);
        //更新管理员通知表
        administratorMapper.addNotification("义警注册审核提醒","游客" + vrr.getVisitorId() + "提交了义警注册申请");
    }

    /**
     * 查询该义警是否存在正在审核的义警注册申请
     * @param visitorId 游客编号
     * @return          布尔值
     */
    @Override
    public boolean ifSubmit(String visitorId) {
        return vigilanteRegistrationReviewMapper.ifSubmit(visitorId);
    }

}
