package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.Order;
import org.example.vigilanteSystem.pojo.Product;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 商城mapper
 */
@Mapper
public interface ShoppingMapper {
    /**
     * 添加商品
     * @param product  商品类
     */
    void addProduct(Product product);

    /**
     * 查询商品列表（已上架）
     * @param productName  商品名称
     * @param productType  商品类型
     * @param productId    商品编号
     * @return             已上架商品列表
     */
    List<Product> listOn(String productName, String productType, String productId);

    /**
     * 查询商品列表（已下架）
     * @param productName 商品名称
     * @param productType 商品类型
     * @param productId   商品编号
     * @return            已下架商品列表
     */
    List<Product> listOff(String productName, String productType, String productId);

    /**
     * 切换商品状态
     * @param productId     商品编号
     * @param productStatus 商品状态
     */
    void turnStatus(Integer productId, String productStatus);

    /**
     * 添加订单信息到订单表
     * @param order     订单类
     */
    void addOrder(Order order);

    /**
     * 获取商品库存
     * @param productId 商品编号
     * @return          商品库存
     */
    Integer getStock(Integer productId);

    /**
     * 获取商品名字
     * @param productId 商品编号
     * @return          商品名称
     */
    String getName(Integer productId);

    /**
     * 修改商品库存
     * @param productId            商品编号
     * @param purchaseQuantity     购买数量
     */
    Integer changeStock(Integer productId, Integer purchaseQuantity);

    /**
     * 查询订单
     * @param vigilanteId 义警编号
     * @param orderStatus 订单状态
     * @return            订单类型
     */
    List<Map<String,Object>> getShoppingRecord(String vigilanteId,String orderStatus);

    /**
     * 用户签收
     * @param orderId 订单编号
     */
    void signed(Integer orderId);

    /**
     * 管理员发货
     * @param orderId 订单编号
     */
    void deliver(Integer orderId);

    /**
     * 查询所有订单
     * @param orderId     订单编号
     * @param vigilanteId 义警编号
     * @param productId   商品编号
     * @param status      订单状态
     * @param startTime   开始日期
     * @param endTime     结束日期
     * @param antiStatus  订单状态
     * @return            订单列表
     */
    List<Order> listOrder(String orderId, String vigilanteId, String productId, String status, LocalDate startTime, LocalDate endTime,String antiStatus);

    /**
     * 删除商品
     * @param productId 商品编号
     */
    void deleteProduct(Integer productId);

    /**
     * 修改商品信息
     * @param product 商品类
     */
    void modifyProduct(Product product);

    /**
     * 管理员预览订单中的商品信息
     * @param productId 商品编号
     * @return          商品预览信息
     */
    Map<String, Order> productPreview(Integer productId);

    /**
     * 查找某一商品是否有正在进行的订单
     * @param productId 商品编号
     * @return          布尔值
     */
    boolean findUnfinishedOrderByProductId(Integer productId);
}
