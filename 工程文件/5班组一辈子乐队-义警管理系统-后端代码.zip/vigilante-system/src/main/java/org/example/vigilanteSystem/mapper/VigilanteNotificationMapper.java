package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 消息通知mapper
 */
@Mapper
public interface VigilanteNotificationMapper {

    /**
     * 添加消息
     * @param vigilanteId        义警编号
     * @param notificationType   通知类型
     * @param content            通知内容
     */
    void add(String vigilanteId, String notificationType, String content);

    /**
     * 查看消息列表
     * @param readStatus     阅读状态
     * @param vigilanteId    义警编号
     * @return               消息列表
     */
    List<Map<String, Object>> message(String readStatus, String vigilanteId);

    /**
     * 删除消息
     * @param notificationId 消息通知编号
     */
    void deleteMessage(Integer notificationId);

    /**
     * 标记为已读
     * @param notificationId 消息通知编号
     */
    void readMessage(Integer notificationId);
}
