package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.*;
import org.example.vigilanteSystem.pojo.*;
import org.example.vigilanteSystem.service.PointsDetailsService;
import org.example.vigilanteSystem.service.TaskService;
import org.example.vigilanteSystem.service.TeamRankService;
import org.example.vigilanteSystem.utils.WebSocketServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 任务serviceImpl
 */
@Service
public class TaskServiceImpl implements TaskService {
    @Autowired
    private TaskMapper taskMapper;
    @Autowired
    private TeamMapper teamMapper;
    @Autowired
    private VigilanteNotificationMapper vigilanteNotificationMapper;
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private PersonalRankMapper personalRankMapper;
    @Autowired
    private TeamRankMapper teamRankMapper;
    @Autowired
    private PointsDetailsService pointsDetailsService;
    @Autowired
    private WebSocketServer webSocketServer;
    @Autowired
    private TeamRankService teamRankService;
    @Autowired
    private AdministratorMapper administratorMapper;

    /**
     * 所有任务列表
     * @param pageNum              页码
     * @param pageSize             每一页的行数
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param taskStatus           任务状态
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     所有任务列表
     */
    @Override
    public PageBean<TaskDetail> listAll(Integer pageNum, Integer pageSize, Integer taskId, String taskName, String taskType, String taskDifficulty, String taskStatus, LocalDate startDate, LocalDate endDate) {
        //创建PageBean对象
        PageBean<TaskDetail> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<TaskDetail> tasks = taskMapper.listAll(taskId,taskName,taskType,taskDifficulty,taskStatus,startDate,endDate);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<TaskDetail> p = (Page<TaskDetail>) tasks;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());

        return pb;
    }

    /**
     * 申请任务
     * @param taskApplication   任务申请类
     */
    @Transactional
    @Override
    public void apply(TaskApplication taskApplication) {
        taskMapper.apply(taskApplication);
        //更新管理员通知表
        Integer taskId = taskApplication.getTaskId();
        administratorMapper.addNotification("活动申请审核提醒","任务申请单号" + taskId);
    }

    /**
     * 任务申请列表
     * @param pageNum              页码
     * @param pageSize             每一页的行数
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param reviewStatus         审核状态
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     任务申请列表
     */
    @Override
    public PageBean<TaskApplication> listApply(Integer pageNum, Integer pageSize, Integer taskId, String taskName, String taskType, String taskDifficulty, String reviewStatus, LocalDate startDate, LocalDate endDate) throws Exception {
        //创建PageBean对象
        PageBean<TaskApplication> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象

        List<TaskApplication> tasks;
        if(reviewStatus.equals("待审核")){
            tasks = taskMapper.listApplyUnfinished(taskId,taskName,taskType,taskDifficulty,reviewStatus,startDate,endDate);
        }else if(reviewStatus.equals("已审核")){
            tasks = taskMapper.listApplyFinished(taskId,taskName,taskType,taskDifficulty,reviewStatus,startDate,endDate);
        }else {
            throw new Exception("无效的审核状态");
        }

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<TaskApplication> p = (Page<TaskApplication>) tasks;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 审核任务申请
     * @param taskId             任务编号
     * @param reviewStatus       审核状态
     * @param rejectionReason    拒绝理由
     * @param reviewerId         审核人编号
     */
    @Transactional
    @Override
    public void review(Integer taskId, String reviewStatus, String rejectionReason, String reviewerId) {
        taskMapper.review(taskId,reviewStatus,rejectionReason,reviewerId);
        TaskApplication ta = taskMapper.findByApplicationId(taskId);

        if(reviewStatus.equals("审核通过")){
            //更新任务表
            taskMapper.addTask(ta);
            //更新消息通知表
            String vigilanteId = teamMapper.getCaptainIdByTeamId(ta.getResponsibleTeam());
            vigilanteNotificationMapper.add(vigilanteId,"活动申请反馈提醒","您申请的任务" + ta.getTaskName() + "已通过审核");
        }else{
            //更新消息通知表
            String vigilanteId = teamMapper.getCaptainIdByTeamId(ta.getResponsibleTeam());
            vigilanteNotificationMapper.add(vigilanteId,"活动申请反馈提醒",ta.getRejectionReason());
        }
    }

    /**
     * 义警查看“我的任务”
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param vigilanteId     义警编号
     * @param taskStatus      任务状态
     * @return                “我的任务”列表
     */
    @Override
    public PageBean<TaskDetail> myTask(Integer pageNum, Integer pageSize, String vigilanteId, String taskStatus) {
        //创建PageBean对象
        PageBean<TaskDetail> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<TaskDetail> tasks = taskMapper.myTask(vigilanteId,taskStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<TaskDetail> p = (Page<TaskDetail>) tasks;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 通过编号查找任务
     * @param taskId    任务编号
     * @return          任务类
     */
    @Override
    public TaskDetail findByTaskId(Integer taskId) {
        return taskMapper.findByTaskId(taskId);
    }

    /**
     * 增加任务报名成员人数
     * @param taskId   任务编号
     */
    @Override
    public void addTaskMember(Integer taskId) {
        taskMapper.addTaskMember(taskId);
    }

    /**
     * 报名任务
     * @param vigilanteId    义警编号
     * @param taskId         任务编号
     */
    @Override
    public void sign(String vigilanteId, Integer taskId) throws Exception {
        //查找是否有正在进行的任务，如果有则报名失败
        List<TaskDetail> tasks = taskMapper.myTask(vigilanteId,"正在进行");
        if(tasks.size()>0){
            throw new Exception("您有正在进行的任务，请先完成当前任务哦");
        }

        //获取要报名的任务的时间
        TaskDetail taskDetail = taskMapper.findByTaskId(taskId);
        LocalDate taskDate = taskDetail.getTaskDate();
        LocalTime taskStartTime = taskDetail.getTaskStartTime();
        LocalTime taskEndTime = taskDetail.getTaskEndTime();
        //查找要报名的任务与已报名的任务是否存在时间上的重叠
        if(taskMapper.ifTimeOverlaps(taskDate,taskStartTime,taskEndTime,vigilanteId)){
            throw new Exception("您当前报名的任务与已经报名的任务存在时间上的冲突");
        }

        //判断是否已达最大人数
        if(taskDetail.getLimitPeople() == taskDetail.getEnrolledPeople()){
            throw new Exception("已达最大报名人数");
        }

        //更新任务报名表
        taskMapper.sign(vigilanteId,taskId);
    }

    /**
     * 任务报名成员列表
     * @param taskId    任务编号
     * @return          任务报名成员列表
     */
    @Override
    public List<Map<String, Object>> listMember(Integer taskId) {
        return taskMapper.listMembers(taskId);
    }

    /**
     * 判断是否出现时间冲突
     * @param taskDate             日期
     * @param taskStartTime        开始时间
     * @param taskEndTime          结束时间
     * @param vigilanteId          义警编号
     * @return                     是否出现时间冲突
     */
    @Override
    public boolean ifTimeOverlaps(LocalDate taskDate, LocalTime taskStartTime, LocalTime taskEndTime, String vigilanteId) {
        return taskMapper.ifTimeOverlaps(taskDate,taskStartTime,taskEndTime,vigilanteId);
    }

    /**
     * 打卡签到
     * @param vigilanteId        义警编号
     * @param taskId             任务编号
     */
    @Override
    public void checkIn(String vigilanteId, Integer taskId) {
        taskMapper.checkIn(vigilanteId,taskId);
    }

    /**
     * 签退
     * @param vigilanteId     义警编号
     * @param taskId          任务编号
     * @return                签退信息
     */
    @Transactional
    @Override
    public Map<String,Object> checkout(String vigilanteId, Integer taskId) {
        //查询任务报名表,计算签到和签退的时间差
        Map<String,Object> map = taskMapper.findTaskRegistration(vigilanteId,taskId);
        LocalDateTime checkInTime = (LocalDateTime) map.get("checkInTime");
        LocalDateTime checkOutTime = LocalDateTime.now();
        Duration durationCheck = Duration.between(checkInTime, checkOutTime);
        // 将时间差转换为小时
        double serviceTime = durationCheck.toMinutes() / 60.0;

        //查询并计算任务总时长
        TaskDetail taskDetail = taskMapper.findByTaskId(taskId);
        LocalTime taskStartTime = taskDetail.getTaskStartTime();
        LocalTime taskEndTime = taskDetail.getTaskEndTime();
        Duration durationTask = Duration.between(taskStartTime,taskEndTime);
        //将时间差转换为小时
        double totalTime = durationTask.toMinutes() / 60.0;

        //根据难度决定积分
        double earnedPoints = 0;
        if(taskDetail.getTaskDifficulty().equals("低")){
            earnedPoints = 20;
        } else if (taskDetail.getTaskDifficulty().equals("中")) {
            earnedPoints = 50;
        }else {
            earnedPoints = 100;
        }

        //根据时长计算积分
        double percentage = serviceTime / totalTime;
        if(percentage <0.5){
            earnedPoints = 0;
        }else if(percentage < 0.8){
            earnedPoints *= percentage;
        }else {
            earnedPoints *= 1;
        }

        //服务时长保留一位小数
        serviceTime = Math.round(serviceTime * 10.0) / 10.0;
        //签退成功，更新任务报名表
        taskMapper.checkOut(vigilanteId,taskId,checkOutTime,(int)Math.round(earnedPoints),serviceTime);

        //更新积分明细表
        if(earnedPoints > 0) {
            PointsDetails pd = new PointsDetails();
            pd.setVigilanteId(vigilanteId);                         //义警编号
            pd.setType("任务获取");                                  //积分获取类型
            pd.setPointsEarned((int)Math.round(earnedPoints));     //获取积分数量
            pd.setSource(taskDetail.getTaskName());                //来源
            pointsDetailsService.addPointsDetails(pd);
            vigilanteMapper.changeAvailablePoints(vigilanteId,(int)Math.round(earnedPoints));
        }

        //更新个人服务时长（排名表）
        personalRankMapper.updateDuration(vigilanteId,serviceTime);

        //队伍服务时长（队伍表）
        Vigilante vigilante = vigilanteMapper.findById(vigilanteId);
        teamMapper.addDuration(serviceTime,vigilante.getTeamId());

        //更新队伍服务时长（排名表）
        teamRankMapper.updateDuration(vigilante.getTeamId(),serviceTime);

        //返回信息（服务时长，获取积分，签退时间）
        Map<String,Object> result = new HashMap<>();
        result.put("serviceTime",serviceTime);
        result.put("earnedPoints",earnedPoints);
        result.put("checkOutTime",checkOutTime);
        return result;
    }

    /**
     * 可报名任务列表
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param vigilanteId    义警编号
     * @param taskType       任务类型
     * @return               可报名任务列表
     */
    @Override
    public PageBean<TaskDetail> listToRegister(Integer pageNum, Integer pageSize, String vigilanteId, String taskType) {
        //创建PageBean对象
        PageBean<TaskDetail> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<TaskDetail> tasks = taskMapper.listToRegister(vigilanteId,taskType);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<TaskDetail> p = (Page<TaskDetail>) tasks;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 任务报名成员人数减少
     * @param taskId     任务编号
     */
    @Override
    public void reduceTaskMember(Integer taskId) {
        taskMapper.reduceTaskMember(taskId);
    }

    /**
     * 取消报名
     * @param vigilanteId  义警编号
     * @param taskId       任务编号
     */
    @Override
    public void cancelSign(String vigilanteId, Integer taskId) {
        taskMapper.cancelSign(vigilanteId,taskId);
    }

    /**
     * 现在正在进行的任务
     * @param vigilanteId  义警编号
     * @return             现在正在进行的任务信息
     */
    @Override
    public Map<String, Object> taskNow(String vigilanteId) {
        return taskMapper.taskNow(vigilanteId);
    }

    /**
     * 管理员发布所有人抢单任务
     * @param taskDetail     任务类
     */
    @Override
    public void adminTaskAll(TaskDetail taskDetail) throws Exception {
        System.out.println(taskDetail);

        //得到任务的日期，具体开始时间，具体结束时间
        LocalDate taskDate = taskDetail.getTaskDate();
        LocalTime taskStartTime = taskDetail.getTaskStartTime();
        LocalTime taskEndTime = taskDetail.getTaskEndTime();

        // 计算任务的开始时间
        LocalDateTime taskStartDateTime = taskDate.atTime(taskStartTime);
        //指派任务的时间不可以早于现在的时间
        if(taskStartDateTime.isBefore(LocalDateTime.now())){
            throw new Exception("任务开始时间不能早于当前时间");
        }

        String teamId = taskDetail.getTeamId();
        if(teamMapper.findByTeamId(teamId) == null){
            throw new Exception("请填写正确的队伍编号");
        }

        taskMapper.adminTaskAll(taskDetail);
    }

    /**
     * ”我管理的任务“
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param teamId         队伍编号
     * @param taskStatus     任务状态
     * @return               ”我管理的任务“列表
     */
    @Override
    public PageBean<TaskDetail> myAdminTask(Integer pageNum, Integer pageSize, String teamId, String taskStatus) {
        //创建PageBean对象
        PageBean<TaskDetail> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<TaskDetail> tasks = taskMapper.myAdminTask(teamId,taskStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<TaskDetail> p = (Page<TaskDetail>) tasks;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 管理员发布指派任务
     * @param taskDetail  任务类
     * @return            操作结果
     */
    @Transactional
    @Override
    public void adminTaskAssign(TaskDetail taskDetail) throws Exception {

        String teamId = taskDetail.getTeamId();
        Team team = teamMapper.findByTeamId(teamId);
        if(team == null){
            throw new Exception("请填写正确的队伍编号");
        }

        //得到任务的日期，具体开始时间，具体结束时间
        LocalDate taskDate = taskDetail.getTaskDate();
        LocalTime taskStartTime = taskDetail.getTaskStartTime();
        LocalTime taskEndTime = taskDetail.getTaskEndTime();

        // 计算任务的开始时间
        LocalDateTime taskStartDateTime = taskDate.atTime(taskStartTime);
        //指派任务的时间不可以早于现在的时间
        if(taskStartDateTime.isBefore(LocalDateTime.now())){
            throw new Exception("任务开始时间不能早于当前时间");
        }

        //判断是否存在指派任务时间冲突
        if(teamMapper.ifTimeOverlaps(taskDate,taskStartTime,taskEndTime,teamId)){
            throw new Exception("该队伍在此时间段已被指派进行其它任务");
        }


        //更新任务表并得到任务编号
        taskMapper.adminTaskAssign(taskDetail);
        Integer taskId = taskDetail.getTaskId();

        //得到队伍人数
        Integer teamSize = team.getTeamSize();
        //如果队伍人数大于指派任务人数限制，则指派失败
        if(teamSize > taskDetail.getLimitPeople()) {
            throw new Exception("该队伍人数大于指派任务的人数限制");
        }
        //查询此队伍的所有成员编号
        List<String> membersId = teamMapper.findMembers(teamId);
        //为每一个队伍成员报名此任务
        for(String memberId : membersId){
            //如果队员其它任务存在时间冲突，则为其取消报名
            //查找冲突的任务编号
                Integer anotherTaskId = taskMapper.findTimeOverlaps(taskDate,taskStartTime,taskEndTime,memberId);
                if(anotherTaskId == null){
                    //更新任务报名表
                    taskMapper.sign(memberId,taskId);
                    //任务报名人数加一
                    taskMapper.addTaskMember(taskId);
                    //消息通知
                    vigilanteNotificationMapper.add(memberId,"其它",
                            "您所在的队伍已被指派进行任务：" + taskDetail.getTaskName() + "，已自动为您指派报名，同时已为您取消其它时间冲突的任务，请及时查看报名信息" );
                }else {
                    TaskDetail anotherTaskDetail = taskMapper.findByTaskId(anotherTaskId);
                    //如果队员其它任务存在时间冲突，则为其取消报名
                    if(!anotherTaskDetail.getTaskStatus().equals("正在进行")){
                        //如果队员其它任务存在时间冲突，则为其取消报名
                        taskMapper.cancelSign(memberId,anotherTaskId);
                        //任务报名人数减一
                        taskMapper.reduceTaskMember(anotherTaskId);
                    }
                }
        }

    }

    /**
     * 任务总数
     * @return  任务总数
     */
    @Override
    public Integer taskCounting() {
        return taskMapper.taskCounting();
    }

    /**
     * 我报名的任务总数
     * @param vigilanteId  义警编号
     * @return             我报名的任务总数
     */
    @Override
    public Integer myTaskCounting(String vigilanteId) {
        return taskMapper.myTaskCounting(vigilanteId);
    }

    /**
     * 任务报名成员列表
     * @param taskId   任务编号
     * @return         任务报名成员列表
     */
    @Override
    public List<String> findTaskMember(Integer taskId) {
        return taskMapper.findTaskMember(taskId);
    }

    /**
     * 取消某义警的所有未开始任务的报名
     * @param vigilanteId        义警编号
     */
    @Transactional
    @Override
    public void cancelAllUnfinishedTask(String vigilanteId) {
        //查找该义警所有未完成的任务
        List<Integer> tasks = taskMapper.findAllUnfinishedTask(vigilanteId);
        for(Integer taskId : tasks){
            //任务报名人数减一
            taskMapper.reduceTaskMember(taskId);
            //在任务报名表中删除信息
            taskMapper.cancelSign(vigilanteId,taskId);
        }
    }

    /**
     * 删除任务
     * @param params 任务编号
     */
    @Transactional
    @Override
    public void delete(Map<String, Object> params) throws Exception {
        Integer taskId = (Integer) params.get("taskId");
        TaskDetail taskDetail = taskMapper.findByTaskId(taskId);

        if(!taskDetail.getTaskStatus().equals("未开始")){
            throw new Exception("只能删除未开始的任务");
        }

        List<String> members = taskMapper.findTaskMember(taskId);
        for(String vigilanteId : members){
            vigilanteNotificationMapper.add(vigilanteId,"其它","原计划于"+taskDetail.getTaskDate()+" "+taskDetail.getTaskStartTime()
            +"开始的任务："+taskDetail.getTaskName()+"已被取消,很抱歉给您造成不便");
        }

        //删除任务信息
        taskMapper.delete(taskId);
    }

}
