package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;

import java.util.List;
import java.util.Map;

/**
 * 游客service
 */
public interface VisitorService {

    /**
     * 处理微信登录以及初始化信息
     * @param code    微信code
     * @return        初始化信息
     */
    Map<String, Object> login(String code) throws Exception;

    /**
     * 用户第一次登录提交头像和昵称
     * @param visitorId      游客编号
     * @param nickName       昵称
     * @param avatarPath     头像url
     */
    void loginFirst(String visitorId, String nickName, String avatarPath);

    /**
     * 游客查看消息列表
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param readStatus    阅读状态
     * @param visitorId     游客编号
     * @return              消息列表
     */
    PageBean<Map<String, Object>> message(Integer pageNum, Integer pageSize, String readStatus, String visitorId);

    /**
     * 删除消息通知
     * @param notificationId   消息通知编号
     */
    void deleteMessage(String notificationId);

    /**
     * 标记为已读
     * @param notificationId   消息通知编号
     */
    void readMessage(String notificationId);

    /**
     * 游客信息上报
     * @param incidentReport  信息上报类
     */
    void incidentReportVisitor(IncidentReport incidentReport);

    /**
     * 游客查看信息上报记录
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param visitorId      游客编号
     * @param reviewStatus   审核状态
     * @return               信息上报记录
     */
    PageBean<IncidentReport> incidentReportRecordVisitor(Integer pageNum, Integer pageSize, String visitorId, String reviewStatus);

    /**
     * 游客查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    List<Map<String, Object>> incidentMediaRecordVisitor(Integer reportId) throws Exception;

    /**
     * 获取游客未读消息数量
     * @param visitorId    游客编号
     * @return            未读消息数量
     */
    Integer messageCount(String visitorId);

}
