package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.PointsDetails;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.service.PointsDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/points_details")
public class PointsDetailsController {

    @Autowired
    private PointsDetailsService pointsDetailsService;

    /**
     * 查询义警的积分明细
     * @param pageNum           页数
     * @param pageSize          每一页的行数
     * @param vigilanteId       义警编号
     * @return                  积分明细列表
     */
    @GetMapping("/list")
    public Result<PageBean<PointsDetails>> list(Integer pageNum,Integer pageSize,@RequestParam String vigilanteId){
        PageBean<PointsDetails> pb = pointsDetailsService.list(pageNum,pageSize,vigilanteId);
        return Result.success(pb);
    }

}
