package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.pojo.Team;
import org.example.vigilanteSystem.pojo.Vigilante;
import org.example.vigilanteSystem.service.TaskService;
import org.example.vigilanteSystem.service.TeamService;
import org.example.vigilanteSystem.service.VigilanteNotificationService;
import org.example.vigilanteSystem.service.VigilanteService;
import org.example.vigilanteSystem.utils.TeamIdUtil;
import org.example.vigilanteSystem.utils.WebSocketServer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Map;


@RestController
@RequestMapping("/team")
public class TeamController {
    @Autowired
    private TeamService teamService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private TeamIdUtil teamIdUtil;
    @Autowired
    private VigilanteService vigilanteService;
    @Autowired
    private VigilanteNotificationService vigilanteNotificationService;
    @Autowired
    private WebSocketServer webSocketServer;

    /**
     * 展示所有队伍
     * @param pageNum     页码
     * @param pageSize    大小
     * @param teamId      队伍编号
     * @param teamLevel   队伍规模
     * @param teamName    队伍名称
     * @param startTime   开始日期
     * @param endTime     截止日期
     * @return            队伍列表
     */
    @Transactional
    @GetMapping("/list_team")
    public Result<PageBean<Team>> listTeam(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String teamId,
            @RequestParam(required = false) String teamLevel,
            @RequestParam(required = false) String teamName,
            @RequestParam(required = false) String startTime,
            @RequestParam(required = false) String endTime)
    {
        PageBean<Team> pb = teamService.listTeam(pageNum,pageSize,teamId,teamLevel,teamName,startTime,endTime);
        return Result.success(pb);
    }

    /**
     * 查看我的队伍
     * @param teamId       任务编号
     * @return             我的队伍信息
     */
    @GetMapping("/my_team")
    public Result<Team> myTeam(String teamId) {
        Team team = teamService.findByTeamId(teamId);
        return Result.success(team);
    }


    /**
     * 查询所有未入队义警，返回头像url和姓名以及编号
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @return              未入队义警列表
     */
    @Transactional
    @GetMapping("/list_no_team")
    public Result<PageBean<Map<String,Object>>> listNoTeam(Integer pageNum,Integer pageSize){
        PageBean<Map<String,Object>> pb = vigilanteService.listNoTeam(pageNum,pageSize);
        return Result.success(pb);
    }

    /**
     * 查询队伍成员（显示简略信息：名字,头像url,编号）
     * @param pageNum     页码
     * @param pageSize    大小
     * @param teamId      队伍编号
     * @return            队伍成员列表
     */
    @Transactional
    @GetMapping("/team_members")
    public Result<PageBean<Map<String,Object>>> teamMembers(Integer pageNum,Integer pageSize,String teamId,String captainId){
        PageBean<Map<String,Object>> pb = vigilanteService.listSpecificTeam(pageNum,pageSize,teamId,captainId);
        return Result.success(pb);
    }

    /**
     * 查询队伍负责人（显示简略信息：名字，头像url,编号）
     * @param captainId       队伍负责人编号
     * @return                队伍负责人信息
     */
    @GetMapping("team_captain")
    public Result<Map<String,Object>> teamCaptain(String captainId){
        Map<String,Object> map = vigilanteService.teamCaptain(captainId);
        return Result.success(map);
    }

    /**
     * 展示队伍成员的详细信息
     * @param vigilanteId       义警编号
     * @return                  队伍成员详细信息
     */
    @GetMapping("/member_detail")
    public Result<Vigilante> memberDetail(String vigilanteId){
        Vigilante vigilante = vigilanteService.findById(vigilanteId);
        vigilante.setIdNumber(null);
        vigilante.setIdBackPath(null);
        vigilante.setIdFrontPath(null);
        vigilante.setOpenid(null);
        return Result.success(vigilante);
    }

    /**
     * 管理员创建队伍
     */
    @Transactional
    @PostMapping("/establish_team")
    public Result establishTeam(@RequestBody Map<String, Object> params){
        try {
            teamService.establishTeam(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 更换队伍头像
     * @param teamAvatarPath    头像url
     * @param teamId            队伍编号
     * @return                  操作结果
     */
    @Transactional
    @PostMapping("modify_avatar")
    public Result modifyAvatar(String teamAvatarPath,String teamId) {
        //更新队伍头像的url
        teamService.modifyAvatar(teamAvatarPath,teamId);
        return Result.success();
    }

    /**
     * 更新队伍简介
     * @param description      队伍简介
     * @param teamId           队伍编号
     * @return                 操作结果
     */
    @PostMapping("modify_description")
    public Result modifyDescription(String description, String teamId) {
        //更新队伍的简介
        try {
            teamService.modifyDescription(description,teamId);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 入队申请
     * @param teamId           队伍编号
     * @param vigilanteId      义警编号
     * @return                 操作结果
     */
    @Transactional
    @PostMapping("/join_request")
    public Result joinRequest(@RequestParam String teamId,@RequestParam String vigilanteId){
        Team team = teamService.findByTeamId(teamId);
        switch (team.getTeamLevel()){
            case "大队":
                if(team.getTeamSize() == 60){return Result.error("当前队伍人数已满");}
            case "中队":
                if(team.getTeamSize() == 40){return Result.error("当前队伍人数已满");}
            case "小队":
                if(team.getTeamSize() == 20){return Result.error("当前队伍人数已满");}
        }
        //更新入队申请表
        teamService.joinRequest(teamId,vigilanteId);
        return Result.success();
    }

    /**
     * 查看入队申请列表
     * @param teamId           队伍编号
     * @return                 入队申请列表
     */
    @Transactional
    @GetMapping("/join_request_list")
    public Result<PageBean<Map<String,Object>>> joinRequestList(Integer pageNum,Integer pageSize,String teamId,String reviewResult){
        PageBean<Map<String,Object>> pb = teamService.joinRequestList(pageNum,pageSize,teamId,reviewResult);
        return Result.success(pb);
    }

    /**
     * 负责人审核入队申请
     * @param requestId              申请编号
     * @param teamId                 申请队伍的编号
     * @param vigilanteId            申请人编号
     * @param reviewResult           审核状态
     * @return                       操作结果
     */
    @Transactional
    @PostMapping("/join_request_review")
    public Result joinRequestReview(@RequestParam Integer requestId,@RequestParam String teamId,@RequestParam String vigilanteId,@RequestParam String reviewResult){
        Vigilante vigilante = vigilanteService.findById(vigilanteId);
        if(vigilante.getTeamId()!=null){
            //更新入队申请表
            teamService.joinRequestReview(requestId,"审核不通过");
            return Result.error("该义警已经加入其它队伍");
        } else if(reviewResult.equals("审核通过")){
            //更新入队申请表
            teamService.joinRequestReview(requestId,reviewResult);
            //义警入队
            vigilanteService.joinTeam(vigilanteId,teamId);
            //队伍人数加一
            try {
                teamService.addTeamSize(teamId,vigilanteId);
            } catch (Exception e) {
                System.out.println(e.getMessage());
                return Result.error(e.getMessage());
            }
            //更新前端的teamId
            webSocketServer.sendToClient("vigilante"+vigilanteId,"1");
            //更新消息通知表
            Team team = teamService.findByTeamId(teamId);
            vigilanteNotificationService.add(vigilanteId,"入队申请结果提醒","恭喜你已经加入义警队伍：" + team.getTeamName());
        }else {
            //更新入队申请表
            teamService.joinRequestReview(requestId,reviewResult);
            //更新消息通知表
            Team team = teamService.findByTeamId(teamId);
            vigilanteNotificationService.add(vigilanteId,"入队申请结果提醒","很遗憾" + team.getTeamName() + "拒绝了您的入队申请");
        }
        return Result.success();
    }

    /**
     * 义警退出队伍
     * @param teamId             队伍编号
     * @param vigilanteId        义警编号
     * @return                   操作结果
     */
    @Transactional
    @PostMapping("/drop_out")
    public Result dropOut(@RequestParam String teamId,@RequestParam String vigilanteId){
        try {
            vigilanteService.dropTeam(vigilanteId,teamId);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 踢出队伍成员
     * @param teamId        队伍编号
     * @param vigilanteId   义警编号
     * @return              操作结果
     */
    @Transactional
    @PostMapping("/kick_out")
    public Result kickOut(@RequestParam String teamId,@RequestParam String vigilanteId){
        //为其取消所有未开始任务的报名
        taskService.cancelAllUnfinishedTask(vigilanteId);
        //踢出队伍成员
        try {
            teamService.kickOut(teamId,vigilanteId);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
        //队伍人数减一
        teamService.reduceTeamSize(vigilanteId,teamId);
        //消息通知
        vigilanteNotificationService.add(vigilanteId,"其它","您已被移出所在义警队伍,同时取消所有未开始任务的报名");
        return Result.success();
    }


    /**
     * 管理员更换队伍负责人
     * @param map      原负责人编号，新负责人编号，队伍编号
     * @return         操作结果
     */
    @PostMapping("/change_captain")
    public Result changeCaptain(@RequestBody Map<String,Object> map){
        try{
            //更换队伍负责人
            teamService.changeCaptain(map);
            return Result.success();
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }

    /**
     * 判断义警是否可以申请入队
     * @param teamId        队伍编号
     * @param vigilanteId   义警编号
     */
    @GetMapping("/if_join_request")
    public Result ifJoinRequest(@RequestParam String teamId,@RequestParam String vigilanteId){
        if(teamService.ifJoinRequest(teamId,vigilanteId)){
            return Result.success(1);
        }else {
            Team team = teamService.findByTeamId(teamId);
            Integer teamSize = team.getTeamSize();
            String teamLevel = team.getTeamLevel();
            if(teamSize==20&&teamLevel.equals("小队")){
                return Result.success(2);
            }
            if(teamSize==40&&teamLevel.equals("中队")){
                return Result.success(2);
            }
            if(teamSize==60&&teamLevel.equals("大队")){
                return Result.success(2);
            }
        }
        return Result.success(0);
    }

}
