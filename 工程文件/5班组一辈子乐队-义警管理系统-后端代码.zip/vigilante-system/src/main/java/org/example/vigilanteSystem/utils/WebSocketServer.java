package org.example.vigilanteSystem.utils;


import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 双向通信
 */
@Component
@ServerEndpoint("/ws/{sid}")
public class WebSocketServer {

    //存放会话对象
    private static final Map<String, Session> sessionMap = new ConcurrentHashMap<>();

    @OnOpen
    public void onOpen(Session session, @PathParam("sid") String sid) {
        if (!sessionMap.containsKey(sid)) {
            System.out.println("客户端：" + sid + "已建立连接");
            sessionMap.put(sid, session);
        } else {
            System.out.println("客户端：" + sid + "已经连接");
        }
    }

    /**
     * 收到客户端消息后调用的方法
     */
    @OnMessage
    public void onMessage(String message, @PathParam("sid") String sid) {
        try {
            System.out.println("收到来自客户端：" + sid + "的消息：" + message);
            // 在此添加具体的消息处理逻辑
        } catch (Exception e) {
            System.err.println("处理消息时发生异常：" + e.getMessage());
        }
    }


    /**
     * 群发
     */
    @Scheduled(fixedRate = 30000)
    public void sendToAllClient() {
        Collection<Session> sessions = sessionMap.values();
        for (Session session : sessions) {
            try {
                if (session.isOpen()) {
                    session.getBasicRemote().sendText("heart");
                    System.out.println("向所有客户端发送消息：" + "heart");
                } else {
                    // 如果会话未打开，则从会话列表中移除它
                    System.out.println("发现已关闭的会话，移除客户端");
                    sessionMap.values().remove(session);
                }
            } catch (Exception e) {
                System.out.println("发送消息时发生异常：" + e.getMessage());
            }
        }
    }


    /**
     * 向指定客户端发送消息
     * @param sid 要发送消息的客户端标识
     * @param message 要发送的消息内容
     */
    public void sendToClient(String sid, String message) {
        Session session = sessionMap.get(sid);
        if (session != null && session.isOpen()) {
            try {
                session.getBasicRemote().sendText(message);
                System.out.println("向客户端：" + sid + "发送消息：" + message);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("客户端：" + sid + "未连接或会话已关闭");
        }
    }

    @OnClose
    public void onClose(Session session, @PathParam("sid") String sid) {
        sessionMap.remove(sid);
        System.out.println("客户端：" + sid + "已断开连接");
    }

    /**
     * 配置错误信息处理
     * @param session
     * @param t
     */
    @OnError
    public void onError(Session session, Throwable t) {
        t.printStackTrace();
    }
}
