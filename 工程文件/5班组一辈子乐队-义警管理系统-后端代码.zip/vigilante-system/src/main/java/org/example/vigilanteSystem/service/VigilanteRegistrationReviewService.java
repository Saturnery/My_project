package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.VigilanteRegistrationReview;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Map;

/**
 * 义警注册审核service
 */
@Service
public interface VigilanteRegistrationReviewService {

    /**
     * 查看未审核义警注册申请
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @param name       名字
     * @param idCard     身份证号码
     * @param id         义警编号
     * @param phoneNumber 手机号码
     * @param startTime   开始时间
     * @param endTime     结束时间
     * @return            未审核义警注册申请列表
     */
    PageBean<VigilanteRegistrationReview> listUnfinished(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime);

    /**
     * 查看已审核义警申请
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @param name        名字
     * @param idCard      身份证号码
     * @param id          义警编号
     * @param phoneNumber 手机号码
     * @param startTime   开始时间
     * @param endTime     结束时间
     * @return            已审核义警申请列表
     */
    PageBean<VigilanteRegistrationReview> listFinished(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime);

    /**
     * 管理员审核申请
     * @param id               申请编号
     * @param status           审核状态
     * @param reviewerName     审核人姓名
     * @param reviewerId       审核人编号
     * @param rejectionReason  拒绝原因
     */
    void review(int id, String status, String reviewerName,String reviewerId,String rejectionReason);

    /**
     * 删除义警注册申请
     * @param id  申请编号
     */
    void delete(Integer id);

    /**
     * 提交义警注册申请
     * @param vrr  义警注册申请类
     */
    void submit(VigilanteRegistrationReview vrr) throws Exception;

    /**
     * 查询该用户是否有正在审核的义警注册申请
     * @param visitorId 游客编号
     * @return          布尔值
     */
    boolean ifSubmit(String visitorId);
}
