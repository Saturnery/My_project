package org.example.vigilanteSystem.service.impl;

import org.example.vigilanteSystem.service.VerificationCodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * 验证码serviceImpl
 */
@Service
public class VerificationCodeServiceImpl implements VerificationCodeService {
    @Autowired
    private JavaMailSender mailSender;

    // 存储验证码和过期时间 (这里简单使用HashMap，实际场景中应考虑存储过期时间)
    private final Map<String, String> verificationCodes = new HashMap<>();

    /**
     * 生成验证码
     * @return 验证码
     */
    @Override
    public String generateVerificationCode() {
        Random random = new Random();
        int code = 100000 + random.nextInt(900000); // 生成100000到999999之间的数字
        return String.valueOf(code);
    }

    /**
     * 发送邮件
     * @param email  邮箱
     */
    @Override
    public void sendVerificationCode(String email) {
        String code = generateVerificationCode();
        verificationCodes.put(email, code);

        // 创建邮件消息
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("2972587441@qq.com"); // 发件人邮箱
        message.setTo(email); // 收件人邮箱
        message.setSubject("您的验证码");
        message.setText("您的验证码是: " + code);

        // 发送邮件
        mailSender.send(message);
    }

    /**
     * 检查验证码是否正确
     * @param email  邮箱
     * @param code   验证码
     * @return       验证码是否正确
     */
    @Override
    public boolean verifyCode(String email, String code) {
        String storedCode = verificationCodes.get(email);
        if (storedCode != null && storedCode.equals(code)) {
            // 验证成功后，可以选择移除验证码
            verificationCodes.remove(email);
            return true;
        }
        return false;
    }
}
