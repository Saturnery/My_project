package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.Order;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Product;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Map;

/**
 * 商城service
 */
@Service
public interface ShoppingService {
    /**
     * 导入商品
     * @param product  商品类
     */
    void addProduct(Product product);

    /**
     * 上架商品列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param productName  商品名称
     * @param productType  商品类型
     * @param productId    商品编号
     * @return             上架商品列表
     */
    PageBean<Product> listOn(Integer pageNum, Integer pageSize, String productName,  String productType, String productId);

    /**
     * 下架商品列表
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @param productName 商品名称
     * @param productType 商品类型
     * @param productId   商品编号
     * @return            下架商品列表
     */
    PageBean<Product> listOff(Integer pageNum, Integer pageSize, String productName,  String productType, String productId);

    /**
     * 切换商品状态
     * @param productId     商品编号
     * @param productStatus 商品状态
     */
    void turnStatus(Integer productId, String productStatus);

    /**
     * 用户购买商品
     * @param order 订单类
     */
    void exchange(Order order) throws Exception;


    /**
     * 获取商品名称
     * @param productId  商品编号
     * @return           商品名称
     */
    String getName(Integer productId);

    /**
     * 用户查看购买记录
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param vigilanteId   义警编号
     * @param orderStatus   商品状态
     * @return              购买记录
     */
    PageBean<Map<String,Object>> getShoppingRecord(Integer pageNum,Integer pageSize,String vigilanteId,String orderStatus);

    /**
     * 签收
     * @param orderId 订单编号
     */
    void signed(Integer orderId);

    /**
     * 发货
     * @param params 义警编号，订单编号
     */
    void deliver(Map<String,Object> params) throws Exception;

    /**
     * 订单列表
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param orderId         订单编号
     * @param vigilanteId     义警编号
     * @param productId       商品编号
     * @param status          订单状态
     * @param startTime       开始时间
     * @param endTime         结束时间
     * @param antiStatus      订单状态
     * @return                订单列表
     */
    PageBean<Order> listOrder(Integer pageNum, Integer pageSize, String orderId, String vigilanteId, String productId, String status, LocalDate startTime, LocalDate endTime, String antiStatus);

    /**
     * 删除商品
     * @param productId    商品编号
     */
    void deleteProduct(Integer productId) throws Exception;

    /**
     * 修改商品信息
     * @param product   商品类
     */
    void modifyProduct(Product product);

    /**
     * 商品预览
     * @param productId  商品编号
     * @return           商品预览信息
     */
    Map<String, Order> productPreview(Integer productId);
}
