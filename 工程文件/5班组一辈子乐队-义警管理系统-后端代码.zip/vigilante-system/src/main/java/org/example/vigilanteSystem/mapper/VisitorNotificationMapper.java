package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

/**
 * 消息通知mapper
 */
@Mapper
public interface VisitorNotificationMapper {

    /**
     * 添加游客消息通知
     * @param visitorId             游客编号
     * @param notificationType      消息通知类型
     * @param content               消息通知内容
     */
    @Insert("insert into band.visitor_notification(visitor_id,notification_type,content,send_time) values(#{visitorId},#{notificationType},#{content},now())")
    void add(String visitorId, String notificationType, String content);
}
