package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.Dynamic;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Vigilante;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 义警service
 */
@Service
public interface VigilanteService {

    /**
     * 查看义警列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param name         名字
     * @param idCard       身份证号码
     * @param id           义警编号
     * @param phoneNumber   手机号码
     * @param startDate     开始时间
     * @param endDate       结束时间
     * @return              义警列表
     */
    PageBean<Vigilante> list(Integer pageNum, Integer pageSize, String name, String idCard, String id, String phoneNumber, LocalDate startDate, LocalDate endDate);

    /**
     * 查看未入队义警（返回头像url和姓名）
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @return            未入队义警列表
     */
    PageBean<Map<String, Object>> listNoTeam(Integer pageNum,Integer pageSize);

    /**
     * 入队
     * @param vigilanteId  义警编号
     * @param teamId       队伍编号
     */
    void joinTeam(String vigilanteId, String teamId);

    /**
     * 退队
     * @param vigilanteId 义警编号
     * @param teamId      队伍编号
     */
    void dropTeam(String vigilanteId, String teamId) throws Exception;

    /**
     * 队伍成员列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param teamId       队伍编号
     * @param captainId    负责人编号
     * @return             队伍成员列表（头像url和姓名）
     */
    PageBean<Map<String, Object>> listSpecificTeam(Integer pageNum, Integer pageSize, String teamId,String captainId);

    /**
     * 根据义警编号查询义警
     * @param vigilanteId 义警编号
     * @return            义警类
     */
    Vigilante findById(String vigilanteId);

    /**
     * 查看队伍负责人
     * @param captainId   负责人编号
     * @return            负责人信息（头像url和姓名）
     */
    Map<String, Object> teamCaptain(String captainId);

    /**
     * 统计义警人数
     * @return 义警总数
     */
    Integer vigilanteCounting();

    /**
     * 义警信息上报
     * @param incidentReport  信息上报类
     */
    void incidentReportVigilante(IncidentReport incidentReport);

    /**
     * 义警查看信息上报记录
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param vigilanteId    游客编号
     * @param reviewStatus   审核状态
     * @return               信息上报记录
     */
    PageBean<IncidentReport> incidentReportRecordVigilante(Integer pageNum, Integer pageSize, String vigilanteId, String reviewStatus);

    /**
     * 义警查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    List<Map<String, Object>> incidentMediaRecordVigilante(Integer reportId) throws Exception;

    /**
     * 删除上报信息
     * @param params 信息上报编号
     */
    void incidentReportDelete(Map<String, Object> params) throws Exception;

    /**
     * 发布义警圈
     * @param dynamic 义警动态 类
     */
    void publishDynamic(Dynamic dynamic) throws Exception;

    /**
     * 点赞
     * @param params （义警编号，动态编号）
     */
    void like(Map<String, Object> params) throws Exception;

    /**
     * 评论
     * @param params （义警编号，动态编号，评论内容）
     */
    void comment(Map<String, Object> params) throws Exception;

    /**
     * 义警圈列表
     * @param pageNum   页码
     * @param pageSize  每一页的行数
     * @return          义警圈列表
     */
    PageBean<Map<String, Object>> dynamicList(Integer pageNum, Integer pageSize, String vigilanteId);

    /**
     * 取消点赞
     * @param params （义警编号，动态编号）
     */
    void cancelLike(Map<String, Object> params) throws Exception;

    /**
     * 删除动态
     * @param params （动态编号）
     */
    void dynamicDelete(Map<String, Object> params) throws Exception;

    /**
     * 修改个人信息
     * @param params 个人信息
     */
    void personalInfoModify(Map<String, Object> params) throws Exception;

    /**
     * 查看我发布的义警圈
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param vigilanteId  义警编号
     * @return             我发布的义警圈列表
     */
    PageBean<Map<String, Object>> dynamicListMyself(Integer pageNum, Integer pageSize, String vigilanteId);

    /**
     * 服务时长明细
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param vigilanteId  义警编号
     * @return             服务时长明细列表
     */
    PageBean<Map<String, Object>> durationList(Integer pageNum, Integer pageSize, String vigilanteId);

    /**
     * 切换义警账号状态
     * @param params 义警编号，账号状态
     */
    void changeStatus(Map<String, Object> params) throws Exception;

    /**
     * 获取义警未读消息数量
     * @param vigilanteId 义警编号
     * @return            未读消息数量
     */
    Integer messageCount(String vigilanteId);
}
