package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 队伍排行service
 */
@Service
public interface TeamRankService {

    /**
     * 查看服务时长排名月榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> monthTeam(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名季榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> quarterTeam(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名年榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> yearTeam(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名总榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> totalTeam(Integer pageNum, Integer pageSize);

}
