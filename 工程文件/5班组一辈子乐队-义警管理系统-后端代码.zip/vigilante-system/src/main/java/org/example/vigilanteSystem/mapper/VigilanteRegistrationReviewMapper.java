package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.VigilanteRegistrationReview;

import java.util.List;
import java.time.LocalDate;

/**
 * 义警注册审核mapper
 */
@Mapper
public interface VigilanteRegistrationReviewMapper {

    /**
     * 分页查询（未审核）
     * @param name           名称
     * @param idCard         身份证号码
     * @param id             义警编号
     * @param phoneNumber    电话号码
     * @param startTime      开始日期
     * @param endTime        结束日期
     * @return               未审核的注册申请
     */
    List<VigilanteRegistrationReview> listUnfinished(String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime);

    /**
     * 分页查询（已审核）
     * @param name          名称
     * @param idCard        身份证号
     * @param id            义警编号
     * @param phoneNumber   电话号码
     * @param startTime     开始日期
     * @param endTime       结束日期
     * @return              已审核的注册申请
     */
    List<VigilanteRegistrationReview> listFinished(String name, String idCard, String id, String phoneNumber, LocalDate startTime, LocalDate endTime);

    /**
     * 更新状态（审核）
     * @param id              注册审核编号
     * @param status          审核状态
     * @param reviewerName    审核人姓名
     * @param reviewerId      审核人编号
     * @param rejectionReason 拒绝原因
     */
    void review(int id, String status, String reviewerName, String reviewerId, String rejectionReason);

    /**
     * 根据编号查找
     * @param id      义警注册申请编号
     * @return        义警注册申请详细信息
     */
    VigilanteRegistrationReview get(int id);

    /**
     * 删除记录
     * @param id       注册申请编号
     */
    void delete(Integer id);

    /**
     * 添加注册申请
     * @param vrr     注册申请类
     */
    void add(VigilanteRegistrationReview vrr);

    /**
     * 判断电话号码是否已被使用
     * @param phoneNumber 电话号码
     * @return            此电话号码是否已被使用
     */
    boolean isPhoneNumberRepeated(String phoneNumber);

    /**
     * 查询该义警是否有正在审核的义警注册申请
     * @param visitorId     游客编号
     * @return            布尔值
     */
    boolean ifSubmit(String visitorId);
}
