package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

/**
 * 队伍类
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Team {
    private String teamId;                       //队伍编号
    private Integer teamSize;                     //队伍人数
    private String teamLevel;                    //队伍规模·
    private String teamName;                     //队伍名字
    private String teamDescription;              //队伍描述
    private String teamAvatarPath;               //队伍头像存储路径
    private String serviceArea;                  //服务区域
    private LocalDate establishmentTime;         //建立时间
    private Integer totalServiceDuration;        //服务总时长
    private String captainId;                    //队长编号
    private String captainName;                  //队长姓名
    private String captainPhoneNumber;           //队长电话号码

}
