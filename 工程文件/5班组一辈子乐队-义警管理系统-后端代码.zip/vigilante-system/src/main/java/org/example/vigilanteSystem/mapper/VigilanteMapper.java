package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.Dynamic;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.Vigilante;
import org.example.vigilanteSystem.pojo.VigilanteRegistrationReview;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 义警mapper
 */
@Mapper
public interface VigilanteMapper {

    /**
     * 返回当前年份的最大序号（主键格式：年份+序号）
     * @param currentYear 当前年份
     * @return            当前年份的最大序号
     */
    String findMaxNum(String currentYear);

    /**
     * 插入数据（义警信息）
     * @param vrr           义警注册申请类
     * @param vigilanteId   义警编号
     * @param openid        微信openid
     * @param avatarPath    头像url
     * @param nickName      昵称
     */
    void add(VigilanteRegistrationReview vrr, String vigilanteId, String openid, String avatarPath,String nickName);

    /**
     * 查询义警信息
     * @param name         名字
     * @param idCard       身份证号码
     * @param id           义警编号
     * @param phoneNumber  电话号码
     * @param startDate    开始日期
     * @param endDate      结束日期
     * @return             义警信息
     */
    List<Vigilante> list(String name, String idCard, String id, String phoneNumber, LocalDate startDate, LocalDate endDate);

    /**
     * 删除义警信息
     * @param id     义警编号
     */
    void delete(String id);

    /**
     * 获取义警可用爱心积分
     * @param vigilanteId 义警编号
     * @return            可用爱心积分
     */
    Integer getAvailablePoints(String vigilanteId);

    /**
     * 修改义警可用爱心积分
     * @param vigilanteId     义警编号
     * @param availablePoints 更新后的可以爱心积分
     */
    void changeAvailablePoints(String vigilanteId, Integer availablePoints);

    /**
     * 查找未入队义警，返回头像url和姓名
     * @return  未入队义警的头像url和姓名列表
     */
    List<Map<String, Object>> listNoTeam();

    /**
     * 查找特定队伍的义警成员，返回头像url和姓名
     * @param teamId      队伍编号
     * @param captainId   负责人编号
     * @return            特定队伍的义警成员的头像url和姓名列表
     */
    List<Map<String, Object>> listSpecificTeam(String teamId,String captainId);

    /**
     * 义警入队
     * @param vigilanteId  义警编号
     * @param teamId       队伍编号
     */
    void joinTeam(String vigilanteId, String teamId);

    /**
     * 义警退队
     * @param vigilanteId 义警编号
     * @param teamId      队伍编号
     */
    void dropTeam(String vigilanteId, String teamId);

    /**
     * 根据openid查询义警
     * @param openid 微信openid
     * @return       义警信息
     */
    Vigilante findByOpenid(String openid);

    /**
     * 根据义警编号查询义警
     * @param vigilanteId 义警编号
     * @return            义警信息
     */
    Vigilante findById(String vigilanteId);

    /**
     * 查看消息列表
     * @param readStatus        阅读状态
     * @param vigilanteId       义警编号
     * @return                  消息列表
     */
    List<Map<String, Object>> message(String readStatus, String vigilanteId);

    /**
     * 查询队伍负责人，返回头像url和姓名
     * @param captainId       负责人编号
     * @return                负责人的头像url和姓名
     */
    Map<String, Object> teamCaptain(String captainId);

    /**
     * 统计总义警人数
     * @return      义警总人数
     */
    Integer vigilanteCounting();

    /**
     * 判断义警是否是队伍负责人
     * @param captainId   义警编号
     * @return            义警是否是队伍负责人（true  or   false）
     */
    boolean isCaptain(String captainId);

    /**
     * 添加信息到上报表
     * @param incidentReport 信息上报类
     */
    void incidentReportVigilante(IncidentReport incidentReport);

    /**
     * 添加信息到附件表
     * @param reportId    信息上报编号
     * @param mediaIndex  索引号
     * @param mediaType   附件类型
     * @param storagePath 存储路径
     */
    void incidentMediaVigilante(Integer reportId, Integer mediaIndex, String mediaType, String storagePath);

    /**
     * 义警查看信息上报记录
     * @param vigilanteId   义警编号
     * @param reviewStatus  审核状态
     * @return              信息上报记录
     */
    List<IncidentReport> incidentReportRecordVigilante(String vigilanteId, String reviewStatus);

    /**
     * 义警查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    List<Map<String, Object>> incidentMediaRecordVigilante(Integer reportId);

    /**
     * 查看义警当天发布动态的次数
     * @param vigilanteId 义警编号
     * @return            当天发布动态的次数
     */
    Integer findDailyCirclePoints(String vigilanteId);

    /**
     * 发布新的动态
     * @param dynamic 义警动态 类
     */
    void publishDynamic(Dynamic dynamic);

    /**
     * 添加动态附件
     * @param dynamicId    动态编号
     * @param i            附件索引
     * @param mediaType    附件类型
     * @param storagePath  附件存储路径
     */
    void dynamicMedia(Integer dynamicId, int i, String mediaType, String storagePath);

    /**
     * 点赞
     * @param vigilanteId 义警编号
     * @param dynamicId   动态编号
     */
    void like(String vigilanteId,Integer dynamicId);

    /**
     * 评论
     * @param vigilanteId     义警编号
     * @param dynamicId       动态编号
     * @param commentContent  评论内容
     */
    void comment(String vigilanteId, Integer dynamicId, String commentContent);

    /**
     * 义警圈列表
     * @return 义警圈列表
     */
    List<Map<String, Object>> dynamicList();

    /**
     * 获取义警圈附件
     * @param dynamicId 义警圈附件
     * @return          附件
     */
    List<Map<String, Object>> getDynamicMedia(Integer dynamicId);

    /**
     * 获取义警圈点赞
     * @param dynamicId 义警圈编号
     * @return          点赞列表
     */
    List<String> getDynamicLike(Integer dynamicId);

    /**
     * 获取评论
     * @param dynamicId 义警圈编号
     * @return          评论列表
     */
    List<Map<String, Object>> getDynamicComment(Integer dynamicId);

    /**
     * 判断浏览者是否已经对该动态点赞
     * @param dynamicId 动态编号
     * @return          布尔值
     */
    boolean isLike(Integer dynamicId,String vigilanteId);

    /**
     * 取消点赞
     * @param dynamicId   动态编号
     * @param vigilanteId 义警编号
     */
    void cancelLike(Integer dynamicId, String vigilanteId);

    /**
     * 查找某一动态是否存在
     * @param dynamicId 动态编号
     * @return          布尔值
     */
    boolean getDynamicById(Integer dynamicId);

    /**
     * 删除某一义警圈
     * @param dynamicId 动态编号
     */
    void dynamicDelete(Integer dynamicId);

    /**
     * 修改个人信息接口
     * @param avatarPath      头像路径
     * @param nickname        昵称
     * @param phoneNumber     手机号码
     * @param workplace       工作单位
     * @param expertise       专长
     * @param gender          性别
     * @param occupation      职业
     * @param politicalStatus 政治面貌
     * @param education       学历
     */
    void personalInfoModify(String avatarPath, String nickname, String phoneNumber, String workplace, String expertise, String gender, String occupation, String politicalStatus, String education, String vigilanteId);

    /**
     * 查看我发布的义警圈
     * @param vigilanteId 义警编号
     * @return            我发布的义警圈列表
     */
    List<Map<String, Object>> dynamicListMyself(String vigilanteId);

    /**
     * 查找某一信息上报是否存在
     * @param reportId 信息上报编号
     * @return         布尔值
     */
    boolean findIncidentReportById(Integer reportId);

    /**
     * 删除信息上报记录
     * @param reportId 信息上报编号
     */
    void incidentReportDelete(Integer reportId);

    /**
     * 查询信息上报审核状态
     * @param reportId 信息上报编号
     * @return         信息上报审核状态
     */
    String findIncidentReportStatusById(Integer reportId);

    /**
     * 查询信息上报附件是否存在
     * @param reportId 信息上报编号
     * @return         布尔值
     */
    boolean findIncidentReportMediaById(Integer reportId);

    /**
     * 服务时长明细列表
     * @param vigilanteId 义警编号
     * @return            服务时长明细列表
     */
    List<Map<String, Object>> durationList(String vigilanteId);

    /**
     * 判断该义警是否有未完成或正在进行的任务
     * @param vigilanteId 义警编号
     * @return            布尔值
     */
    boolean ifUnfinishedTask(String vigilanteId);

    /**
     * 修改个人信息时判断电话号码是否已经被使用
     * @param phoneNumber  电话号码
     * @param vigilanteId  义警编号
     * @return             布尔值
     */
    boolean isPhoneNumberRepeated(String phoneNumber, String vigilanteId);

    /**
     * 切换义警账号状态
     * @param vigilanteId        义警编号
     * @param vigilanteStatus    账号状态
     */
    void changeStatus(String vigilanteId, String vigilanteStatus);

    /**
     * 获取未读消息数量
     * @param vigilanteId 义警编号
     * @return            未读消息数量
     */
    Integer messageCount(String vigilanteId);
}
