package org.example.vigilanteSystem.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * 任务申请类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskApplication {
    private Integer taskId;                     //任务申请单号
    private String taskName;                    //任务名称
    private LocalDate taskDate;                 //任务日期
    private LocalTime taskStartTime;            //任务具体开始时间
    private LocalTime taskEndTime;              //任务具体结束时间
    private String taskType;                    //任务类型
    private String taskDifficulty;              //任务难度
    private String taskLocation;                //任务位置
    private String responsibleTeam;             //负责方队伍编号
    private Integer limitNumber;                //最大人数
    private String reviewStatus;                //审核状态
    private String reviewerId;                  //审核人编号
    private String promotionalImagePath;        //宣传图片存储路径
    private String taskDescription;             //任务描述
    @JsonFormat(pattern = "yyyy-MM-dd HH")
    private String requestTime;                 //任务申请时间
    @JsonFormat(pattern = "yyyy-MM-dd HH")
    private String reviewTime;                  //审核时间
    private String taskContent;                 //任务内容
    private String taskStatus;                  //任务状态
    private String rejectionReason;             //驳回意见
}
