package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.utils.AliOssUtil;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;


@RestController
public class FileUploadController {

    /**
     * 上传图片
     * @param file                文件
     * @return                    上传结果
     * @throws Exception          异常
     */
    @PostMapping("/upload")
    public String upload(MultipartFile file) throws Exception {
        //获取文件名字
        String filename = file.getOriginalFilename();
        //保证文件的名字是唯一的，从而防止文件覆盖
        filename = UUID.randomUUID().toString() + filename.substring(filename.lastIndexOf("."));
        //获取文件存储的URL
       return AliOssUtil.uploadFile(filename,file.getInputStream());
    }

}
