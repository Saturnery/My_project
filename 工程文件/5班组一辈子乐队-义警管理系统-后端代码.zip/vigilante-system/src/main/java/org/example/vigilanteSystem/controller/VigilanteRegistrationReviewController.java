package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.pojo.VigilanteRegistrationReview;
import org.example.vigilanteSystem.service.VigilanteRegistrationReviewService;
import org.example.vigilanteSystem.service.VigilanteService;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;


@RestController
@RequestMapping("/vigilante_registration_review")
public class VigilanteRegistrationReviewController {

    @Autowired
    private VigilanteRegistrationReviewService vigilanteRegistrationReviewService;

    /**
     * 查询未审核的义警注册申请
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param name           名字
     * @param idCard         身份证号
     * @param id             义警编号
     * @param phoneNumber    电话号码
     * @param startDate      开始日期
     * @param endDate        结束日期
     * @return               未审核的注册申请列表
     */
    @GetMapping("/list_unfinished")
    public Result<PageBean<VigilanteRegistrationReview>> listUnfinished(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String idCard,
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String phoneNumber,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate)
    {
        PageBean<VigilanteRegistrationReview> pb = vigilanteRegistrationReviewService.listUnfinished(pageNum,pageSize,name,idCard,id,phoneNumber,startDate,endDate);
        return Result.success(pb);
    }

    /**
     * 查询已审核的义警注册申请
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param name           名字
     * @param idCard         身份证号
     * @param id             义警编号
     * @param phoneNumber    电话号码
     * @param startDate      开始日期
     * @param endDate        结束日期
     * @return               已审核的注册申请
     */
    @GetMapping("/list_finished")
    public Result<PageBean<VigilanteRegistrationReview>> listFinished(
            Integer pageNum, Integer pageSize,
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String idCard,
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String phoneNumber,
            @RequestParam(required = false) LocalDate startDate,
            @RequestParam(required = false) LocalDate endDate)
    {
        PageBean<VigilanteRegistrationReview> pb = vigilanteRegistrationReviewService.listFinished(pageNum,pageSize,name,idCard,id,phoneNumber,startDate,endDate);
        return Result.success(pb);
    }

    /**
     * 管理员审核义警注册申请
     * @param params
     * @return            操作结果
     */
    @PostMapping("/review")
    public Result review(@RequestBody Map<String,Object> params){
        //解析数据(审核编号，审核状态，驳回意见)
        Integer id = (Integer) params.get("id");
        String status = (String) params.get("status");
        String rejectionReason = (String) params.get("rejectionReason");

        //修改指定id的审核状态，并更新义警表信息
        Map<String,Object> claims = ThreadLocalUtil.get();
        String reviewerName = claims.get("name").toString();
        String reviewerId = claims.get("id").toString();

        vigilanteRegistrationReviewService.review(id, status, reviewerName,reviewerId,rejectionReason);
        return Result.success();
    }

    /**
     * 管理员删除某一条审核申请
     * @param params
     * @return        操作结果
     */
    @PostMapping("/delete")
    public Result delete(@RequestBody Map params){
        Integer id = (Integer) params.get("id");
        vigilanteRegistrationReviewService.delete(id);
        return Result.success();
    }

    /**
     * 小程序用户提交义警注册审核
     * @param vrr        注册申请类
     * @return           操作结果
     */
    @PostMapping("/submit")
    public Result submit(@RequestBody VigilanteRegistrationReview vrr){

        //获取当前登录的游客编号
        Map<String,Object> claims = ThreadLocalUtil.get();
        String visitorId = (String) claims.get("id");
        vrr.setVisitorId(visitorId);

        try {
            vigilanteRegistrationReviewService.submit(vrr);
            return Result.success();
        }catch (Exception e){
            return Result.error(e.getMessage());
        }
    }


    /**
     * 查询该用户是否有正在审核的义警注册申请
     * @param visitorId 游客编号
     * @return
     */
    @GetMapping("/if_submit")
    public Result ifSubmit(@RequestParam String visitorId){
        return Result.success(vigilanteRegistrationReviewService.ifSubmit(visitorId));
    }


}
