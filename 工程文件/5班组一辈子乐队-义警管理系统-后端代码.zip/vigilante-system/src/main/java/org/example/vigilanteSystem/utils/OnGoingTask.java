package org.example.vigilanteSystem.utils;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * 当前正在进行的任务列表
 */
@Component
public class OnGoingTask {

    //存储当前正在进行的任务编号
    private final List<Integer> onGoingTask = new ArrayList<>();

    /**
     * 添加正在进行的任务
     * @param taskId  任务编号
     */
    public void addOnGoingTask(Integer taskId) {
        if (!onGoingTask.contains(taskId)) { // 防止重复添加
            onGoingTask.add(taskId);
            System.out.println("正在进行的任务列表：加入任务" + taskId);
        } else {
            System.out.println("正在进行的任务列表：此任务已经存在" + taskId);
        }
    }

    /**
     * 删除正在进行的任务
     * @param taskId   任务编号
     */
    public void removeOnGoingTask(Integer taskId) {
        if (onGoingTask.remove(taskId)) {
            System.out.println("正在进行的任务列表：删除任务" + taskId);
        }
    }

    /**
     * 获取所有正在进行的任务
     */
    public List<Integer> getOnGoingTasks() {
        //将可变列表包装成不可修改的列表
        return Collections.unmodifiableList(onGoingTask);
    }

}
