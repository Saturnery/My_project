package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.example.vigilanteSystem.pojo.Administrator;
import org.example.vigilanteSystem.pojo.IncidentReport;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 管理员mapper
 */
@Mapper
public interface AdministratorMapper {

    /**
     * 根据查询邮箱查询
     * @param email 邮箱
     * @return      管理员信息
     */
    @Select("select * from band.admin where email = #{email}")
    Administrator findByEmail(String email);

    /**
     * 根据身份证号查询
     * @param idCard   身份证号码
     * @return         管理员信息
     */
    @Select("select * from band.admin where id_card_number = #{idCard}")
    Administrator findByIdCard(String idCard);

    /**
     * 新添管理员信息
     * @param email          邮箱
     * @param password       密码
     * @param name           名字
     * @param idCard         身份证号码
     * @param policeNumber   警察编号
     */
    @Insert("insert into band.admin(admin_id,email,password,name,id_card_number,police_number) values(#{adminId},#{email},#{password},#{name},#{idCard},#{policeNumber})")
    void add(String adminId,String email, String password,String name,String idCard,String policeNumber);

    /**
     * 查看信息上报列表
     * @param reportId       上报编号
     * @param eventType      上报类型
     * @param reviewStatus   审核状态
     * @param startDate      开始时间
     * @param endDate        结束时间
     * @return               信息上报列表
     */
    List<IncidentReport> incidentReportList(Integer reportId, String eventType, String reviewStatus, LocalDate startDate, LocalDate endDate);

    /**
     * 信息上报审核
     * @param reviewerId       审核人编号
     * @param reportId         信息上报编号
     * @param reviewFeedback   反馈信息
     */
    void incidentReportReview(String reviewerId, Integer reportId, String reviewFeedback);

    /**
     * 查看信息上报附件
     * @param reportId 信息上报编号
     * @return         附件
     */
    List<Map<String, Object>> incidentReportMedia(Integer reportId);

    /**
     * 查找某一信息上报
     * @param reportId 信息上报编号
     * @return         信息上报
     */
    IncidentReport getIncidentReportById(Integer reportId);

    /**
     * 删除信息上报
     * @param reportId 信息上报编号
     */
    void incidentReportDelete(Integer reportId);

    /**
     *获取义警总数
     * @return 义警总数
     */
    Integer getTotalVigilante();

    /**
     * 获取队伍总数
     * @return 队伍总数
     */
    Integer getTotalTeam();

    /**
     * 获取任务总数
     * @return 任务总数
     */
    Integer getTotalTask();

    /**
     * 获取总服务时长
     * @return 总服务时长
     */
    double getTotalServiceTime();

    /**
     * 获取未审核的注册申请数
     * @return 未审核的注册申请数
     */
    Integer getUnfinishedRegister();

    /**
     * 获取未审核的任务申请数
     * @return 未审核的任务申请数
     */
    Integer getUnfinishedTask();

    /**
     * 获取未审核的信息上报数
     * @return 未审核的信息上报数
     */
    Integer getUnfinishedReport();

    /**
     * 获取管理员个人信息
     * @param adminId 管理员编号
     * @return        管理员个人信息
     */
    Map<String, Object> personalInfo(String adminId);

    /**
     * 查找最大的管理员编号
     * @return 最大的管理员编号
     */
    String findMaxAdminId();

    /**
     * 管理员消息通知
     * @param notificationType 消息通知类型
     * @param content          消息通知内容
     */
    void addNotification(String notificationType, String content);

    /**
     * 管理员查看消息通知列表
     * @param readStatus 阅读状态
     * @return           消息通知列表
     */
    List<Map<String, Object>> notificationList(String readStatus);

    /**
     * 标记消息通知为已读
     * @param notificationId 消息通知编号
     */
    void notificationRead(Integer notificationId);
}
