package org.example.vigilanteSystem.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * 任务类
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskDetail {
    private Integer taskId;                     //任务编号
    private String taskName;                    //任务名称
    private LocalDate taskDate;                 //任务日期
    @JsonFormat(pattern = "HH:mm")
    private LocalTime taskStartTime;            //任务具体开始时间
    @JsonFormat(pattern = "HH:mm")
    private LocalTime taskEndTime;              //任务具体结束时间
    private String taskType;                    //任务类型
    private String taskDifficulty;              //任务难度
    private String taskLocation;                //任务位置
    private String teamId;                      //参与任务的队伍编号（指派任务）
    private String participationMethod;         //参与方式（抢单或者指派）
    private Integer limitPeople;                //最大人数
    private Integer enrolledPeople;              //已报名人数
    private String promotionImagePath;          //宣传图片存储路径
    private String taskDescription;             //任务描述
    private String taskContent;                 //任务内容
    private String taskStatus;                  //任务状态
    private String teamName;                    //负责方队伍名称
}
