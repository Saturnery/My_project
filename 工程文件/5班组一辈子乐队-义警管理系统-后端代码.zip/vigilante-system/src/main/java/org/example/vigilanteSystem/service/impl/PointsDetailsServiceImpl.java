package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.PointsDetailsMapper;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.PointsDetails;
import org.example.vigilanteSystem.service.PointsDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 积分明细serviceImpl
 */
@Service
public class PointsDetailsServiceImpl implements PointsDetailsService {
    @Autowired
    private PointsDetailsMapper pointsDetailsMapper;

    /**
     * 积分明细列表
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param vigilanteId   义警编号
     * @return              积分明细列表
     */
    @Override
    public PageBean<PointsDetails> list(Integer pageNum,Integer pageSize,String vigilanteId) {
        //创建PageBean对象
        PageBean<PointsDetails> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<PointsDetails> vrr = pointsDetailsMapper.list(vigilanteId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<PointsDetails> p = (Page<PointsDetails>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 新添积分明细
     * @param pointsDetails    积分明细类
     */
    @Override
    public void addPointsDetails(PointsDetails pointsDetails) {
        pointsDetailsMapper.addPointsDetails(pointsDetails);
    }

}
