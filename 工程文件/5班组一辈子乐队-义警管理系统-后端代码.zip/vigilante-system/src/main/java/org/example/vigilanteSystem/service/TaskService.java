package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.TaskApplication;
import org.example.vigilanteSystem.pojo.TaskDetail;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

/**
 * 任务service
 */
@Service
public interface TaskService {

    /**
     * 所有任务列表
     * @param pageNum              页码
     * @param pageSize             每一页的行数
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param taskStatus           任务状态
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     所有任务列表
     */
    PageBean<TaskDetail> listAll(Integer pageNum, Integer pageSize, Integer taskId, String taskName, String taskType, String taskDifficulty, String taskStatus, LocalDate startDate, LocalDate endDate);

    /**
     * 申请任务
     * @param taskApplication   任务申请类
     */
    void apply(TaskApplication taskApplication);

    /**
     * 任务申请列表
     * @param pageNum              页码
     * @param pageSize             每一页的行数
     * @param taskId               任务编号
     * @param taskName             任务名称
     * @param taskType             任务类型
     * @param taskDifficulty       任务难度
     * @param reviewStatus         审核状态
     * @param startDate            开始日期
     * @param endDate              结束日期
     * @return                     任务申请列表
     */
    PageBean<TaskApplication> listApply(Integer pageNum, Integer pageSize, Integer taskId, String taskName, String taskType, String taskDifficulty, String reviewStatus, LocalDate startDate, LocalDate endDate) throws Exception;

    /**
     * 审核任务申请
     * @param taskId             任务编号
     * @param reviewStatus       审核状态
     * @param rejectionReason    拒绝理由
     * @param reviewerId         审核人编号
     */
    void review(Integer taskId, String reviewStatus, String rejectionReason, String reviewerId);

    /**
     * 义警查看“我的任务”
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param vigilanteId     义警编号
     * @param taskStatus      任务状态
     * @return                “我的任务”列表
     */
    PageBean<TaskDetail> myTask(Integer pageNum, Integer pageSize, String vigilanteId, String taskStatus);

    /**
     * 通过编号查找任务
     * @param taskId    任务编号
     * @return          任务类
     */
    TaskDetail findByTaskId(Integer taskId);

    /**
     * 增加任务报名成员人数
     * @param taskId   任务编号
     */
    void addTaskMember(Integer taskId);

    /**
     * 报名任务
     * @param vigilanteId    义警编号
     * @param taskId         任务编号
     */
    void sign(String vigilanteId, Integer taskId) throws Exception;

    /**
     * 任务报名成员列表
     * @param taskId    任务编号
     * @return          任务报名成员列表
     */
    List<Map<String, Object>> listMember(Integer taskId);

    /**
     * 判断是否出现时间冲突
     * @param taskDate             日期
     * @param taskStartTime        开始时间
     * @param taskEndTime          结束时间
     * @param vigilanteId          义警编号
     * @return                     是否出现时间冲突
     */
    boolean ifTimeOverlaps(LocalDate taskDate, LocalTime taskStartTime, LocalTime taskEndTime, String vigilanteId);

    /**
     * 打卡签到
     * @param vigilanteId        义警编号
     * @param taskId             任务编号
     */
    void checkIn(String vigilanteId, Integer taskId);

    /**
     * 签退
     * @param vigilanteId     义警编号
     * @param taskId          任务编号
     * @return                签退信息
     */
    Map<String,Object> checkout(String vigilanteId, Integer taskId);

    /**
     * 可报名任务列表
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param vigilanteId    义警编号
     * @param taskType       任务类型
     * @return               可报名任务列表
     */
    PageBean<TaskDetail> listToRegister(Integer pageNum, Integer pageSize, String vigilanteId, String taskType);

    /**
     * 任务报名成员人数减少
     * @param taskId     任务编号
     */
    void reduceTaskMember(Integer taskId);

    /**
     * 取消报名
     * @param vigilanteId  义警编号
     * @param taskId       任务编号
     */
    void cancelSign(String vigilanteId, Integer taskId);

    /**
     * 现在正在进行的任务（用于任务签到）
     * @param vigilanteId  义警编号
     * @return             现在正在进行的任务信息
     */
    Map<String, Object> taskNow(String vigilanteId);

    /**
     * 管理员发布所有人抢单任务
     * @param taskDetail     任务类
     */
    void adminTaskAll(TaskDetail taskDetail) throws Exception;

    /**
     * ”我管理的任务“
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param teamId         队伍编号
     * @param taskStatus     任务状态
     * @return               ”我管理的任务“列表
     */
    PageBean<TaskDetail> myAdminTask(Integer pageNum, Integer pageSize, String teamId, String taskStatus);

    /**
     * 管理员发布指派任务
     * @param taskDetail  任务类
     */
    void adminTaskAssign(TaskDetail taskDetail) throws Exception;

    /**
     * 任务总数
     * @return  任务总数
     */
    Integer taskCounting();

    /**
     * 我报名的任务总数
     * @param vigilanteId  义警编号
     * @return             我报名的任务总数
     */
    Integer myTaskCounting(String vigilanteId);

    /**
     * 任务报名成员列表
     * @param taskId   任务编号
     * @return         任务报名成员列表
     */
    List<String> findTaskMember(Integer taskId);


    /**
     * 取消某义警的所有未开始任务的报名
     * @param vigilanteId        义警编号
     */
    void cancelAllUnfinishedTask(String vigilanteId);

    /**
     * 删除任务
     * @param params 任务编号
     */
    void delete(Map<String, Object> params) throws Exception;
}
