package org.example.vigilanteSystem.controller;

import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/visitor")
public class VisitorController {

    @Autowired
    private VisitorService visitorService;
    @Autowired
    private VigilanteService vigilanteService;
    @Autowired
    private TeamService teamService;
    @Autowired
    private TaskService taskService;
    @Autowired
    private PersonalRankService personalRankService;

    /**
     * 小程序用户登录
     * @param code          微信code
     * @return              操作结果
     */
    @GetMapping("/login")
    public Result<Map<String, Object>> login(String code) {
        try {
            Map<String, Object> result = visitorService.login(code);
            return Result.success(result);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 首次登录提交头像和昵称
     * @param visitorId        游客编号
     * @param nickName         昵称
     * @param avatarPath       头像url
     * @return                 操作结果
     */
    @PostMapping("/login_first")
    public Result loginFirst(String visitorId,String nickName,String avatarPath) {
        visitorService.loginFirst(visitorId,nickName,avatarPath);
        return Result.success();
    }


    /**
     * 消息列表
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param readStatus    阅读状态
     * @return              消息列表
     */
    @GetMapping("/message")
    public Result<PageBean<Map<String,Object>>> message(Integer pageNum, Integer pageSize, String readStatus, String visitorId){
        PageBean<Map<String,Object>> pb = visitorService.message(pageNum,pageSize,readStatus,visitorId);
        return Result.success(pb);
    }

    /**
     * 删除消息通知
     * @param notificationId     消息通知编号
     * @return                   操作结果
     */
    @PostMapping("/delete_message")
    public Result deleteMessage(String notificationId) {
        visitorService.deleteMessage(notificationId);
        return Result.success();
    }

    /**
     * 标记为已读
     * @param notificationId    消息通知编号
     * @return                  操作结果
     */
    @PostMapping("/read_message")
    public Result readMessage(String notificationId) {
        visitorService.readMessage(notificationId);
        return Result.success();
    }


    /**
     * 获取初始化信息
     * @return         初始化信息
     */
    @GetMapping("/init_data")
    public Result<Map<String,Object>> initData() {
        Map<String,Object> map = new HashMap<>();
        Integer vigilanteCounting = vigilanteService.vigilanteCounting();
        Integer teamCounting = teamService.teamCounting();
        Integer taskCounting = taskService.taskCounting();
        Double durationCounting = personalRankService.durationCounting();

        map.put("vigilanteCounting",vigilanteCounting);
        map.put("teamCounting",teamCounting);
        map.put("taskCounting",taskCounting);
        map.put("durationCounting",String.format("%.1f",durationCounting));

        return Result.success(map);
    }


    /**
     * 信息上报
     * @param incidentReport
     * @return
     */
    @PostMapping("/incident_report")
    public Result incidentReportVisitor(@RequestBody IncidentReport incidentReport) {
        visitorService.incidentReportVisitor(incidentReport);
        return Result.success();
    }

    /**
     * 游客查看信息上报记录
     * @param params
     * @return
     */
    @GetMapping("/incident_report_record")
    public Result<PageBean<IncidentReport>> incidentReportRecord(Integer pageNum,Integer pageSize,String visitorId,String reviewStatus){
        PageBean<IncidentReport> pb = visitorService.incidentReportRecordVisitor(pageNum,pageSize,visitorId,reviewStatus);
        return Result.success(pb);
    }

    /**
     * 游客查看某一信息上报记录的附件
     */
    @GetMapping("/incident_media_record")
    public Result<List<Map<String,Object>>> incidentMediaRecord(Integer reportId){
        List<Map<String,Object>> medias = null;
        try {
            medias = visitorService.incidentMediaRecordVisitor(reportId);
            return Result.success(medias);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除上报信息
     * @param params 信息上报编号
     * @return
     */
    @PostMapping("/incident_report_delete")
    public Result incidentReportDelete(@RequestBody Map<String,Object> params){
        try {
            vigilanteService.incidentReportDelete(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }


    /**
     * 获取未读消息数量
     */
    @GetMapping("/message_count")
    public Result messageCount(@RequestParam String visitorId){
        Integer messageCount = visitorService.messageCount(visitorId);
        return Result.success(messageCount);
    }

}
