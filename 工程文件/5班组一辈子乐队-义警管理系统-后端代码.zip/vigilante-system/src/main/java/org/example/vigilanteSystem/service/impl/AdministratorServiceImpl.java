package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.AdministratorMapper;
import org.example.vigilanteSystem.pojo.Administrator;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.service.AdministratorService;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 管理员serviceImpl
 */
@Service
public class AdministratorServiceImpl implements AdministratorService {

    @Autowired
    AdministratorMapper administratorMapper;


    /**
     * 管理员注册
     * @param email     邮箱
     * @param password  密码
     * @param name      姓名
     * @param idCard    身份证号码
     * @param policeNumber  警察编号
     */
    @Override
    public void register(String adminId, String email, String password, String name, String idCard, String policeNumber) {
        administratorMapper.add(adminId, email, password, name, idCard, policeNumber);
    }

    /**
     * 通过邮箱查找
     * @param email 邮箱
     * @return 管理员信息
     */
    @Override
    public Administrator findByEmail(String email) {
        return administratorMapper.findByEmail(email);
    }

    /**
     * 通过身份证号查找
     * @param idCard 身份证号码
     * @return 管理员信息
     */
    @Override
    public Administrator findByIdCard(String idCard) {
        return administratorMapper.findByIdCard(idCard);
    }

    /**
     * 匹配授权码
     * @param policeNumber  警察编号
     * @return 授权码
     */
    @Override
    public String getCodeFromFile(String policeNumber) {
        String filePath = "/projects/code.txt";
        System.out.println(filePath);
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 文件格式是：policeNumber=code，每行一个键值对
                String[] parts = line.split("=");
                if (parts.length == 2 && parts[0].trim().equals(policeNumber)) {
                    return parts[1].trim();
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return null; // 如果文件中没有找到对应的授权码
    }

    /**
     * 查看信息上报列表
     * @param pageNum           页码
     * @param pageSize          每一页的行数
     * @param reportId          上报编号
     * @param eventType         上报类型
     * @param reviewStatus      审核状态
     * @param startDate         开始日期
     * @param endDate           结束日期
     * @return                  信息上报列表
     */
    @Override
    public PageBean<IncidentReport> incidentReportList(Integer pageNum, Integer pageSize, Integer reportId, String eventType, String reviewStatus, LocalDate startDate, LocalDate endDate) {
        //创建PageBean对象
        PageBean<IncidentReport> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<IncidentReport> vrr = administratorMapper.incidentReportList(reportId,eventType,reviewStatus,startDate,endDate);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<IncidentReport> p = (Page<IncidentReport>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 信息上报审核
     * @param params 审核信息
     */
    @Override
    public void incidentReportReview(Map<String, Object> params) throws Exception {
        Integer reportId = (Integer) params.get("reportId");
        String reviewFeedback = (String) params.get("reviewFeedback");

        Map<String,Object> claims = ThreadLocalUtil.get();
        String reviewerId = claims.get("id").toString();

        if(reviewFeedback == null || reportId==null){
            throw new Exception("信息缺失");
        }
        IncidentReport incidentReport = administratorMapper.getIncidentReportById(reportId);
        if(incidentReport==null){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        if(incidentReport.getReviewStatus().equals("已审核")){
            throw new Exception("该信息已被审核，请刷新页面");
        }
        administratorMapper.incidentReportReview(reviewerId,reportId,reviewFeedback);
    }

    /**
     * 查看信息上报附件
     * @param reportId 信息上报编号
     * @return         附件
     */
    @Override
    public List<Map<String, Object>> incidentReportMedia(Integer reportId) throws Exception {
        if(administratorMapper.getIncidentReportById(reportId)==null){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        return administratorMapper.incidentReportMedia(reportId);
    }

    /**
     * 删除已审核的信息上报
     * @param params 信息上报编号
     */
    @Override
    public void incidentReportDelete(Map<String, Object> params) throws Exception {
        Integer reportId = (Integer) params.get("reportId");
        IncidentReport incidentReport = administratorMapper.getIncidentReportById(reportId);
        if(incidentReport==null){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        if(!incidentReport.getReviewStatus().equals("已审核")){
            throw new Exception("该信息未被审核，不可删除");
        }
        //在表中删除信息
        administratorMapper.incidentReportDelete(reportId);
    }

    /**
     * 获取初始化信息
     * @return 初始化信息
     */
    @Override
    public Map<String, Object> initData() {
        Map<String, Object> map = new HashMap<>();
        Integer totalVigilante = administratorMapper.getTotalVigilante();
        Integer totalTeam = administratorMapper.getTotalTeam();
        Integer totalTask = administratorMapper.getTotalTask();
        double totalServiceTime = administratorMapper.getTotalServiceTime();

        Integer unfinishedRegisterAudit = administratorMapper.getUnfinishedRegister();
        Integer unfinishedTaskAudit = administratorMapper.getUnfinishedTask();
        Integer unfinishedReportAudit = administratorMapper.getUnfinishedReport();

        map.put("totalVigilante", totalVigilante);
        map.put("totalTeam", totalTeam);
        map.put("totalTask", totalTask);
        map.put("totalServiceTime", totalServiceTime);
        map.put("unfinishedRegisterAudit", unfinishedRegisterAudit);
        map.put("unfinishedTaskAudit", unfinishedTaskAudit);
        map.put("unfinishedReportAudit", unfinishedReportAudit);

        return map;
    }

    /**
     * 获取管理员个人信息
     * @param adminId 管理员编号
     * @return        管理员个人信息
     */
    @Override
    public Map<String, Object> personalInfo(String adminId) {
        return administratorMapper.personalInfo(adminId);
    }

    /**
     * 管理员查看消息通知列表
     * @param pageNum        页面
     * @param pageSize       每一页的行数
     * @param readStatus     阅读状态
     * @return               消息通知列表
     */
    @Override
    public PageBean<Map<String, Object>> notificationList(Integer pageNum, Integer pageSize, String readStatus) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = administratorMapper.notificationList(readStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 标记消息通知为已读
     * @param params 消息通知编号
     */
    @Override
    public void notificationRead(Map<String, Object> params) {
        Integer notificationId = (Integer) params.get("notificationId");
        administratorMapper.notificationRead(notificationId);
    }


}
