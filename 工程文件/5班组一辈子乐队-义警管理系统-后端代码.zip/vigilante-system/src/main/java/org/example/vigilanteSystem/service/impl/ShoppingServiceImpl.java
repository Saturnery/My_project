package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.AdministratorMapper;
import org.example.vigilanteSystem.mapper.PointsDetailsMapper;
import org.example.vigilanteSystem.mapper.ShoppingMapper;
import org.example.vigilanteSystem.mapper.VigilanteMapper;
import org.example.vigilanteSystem.pojo.Order;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.PointsDetails;
import org.example.vigilanteSystem.pojo.Product;
import org.example.vigilanteSystem.service.ShoppingService;
import org.example.vigilanteSystem.service.VigilanteNotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 积分商城serviceImpl
 */
@Service
public class ShoppingServiceImpl implements ShoppingService {
    @Autowired
    private ShoppingMapper shoppingMapper;
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private VigilanteNotificationService vigilanteNotificationService;
    @Autowired
    private PointsDetailsMapper pointsDetailsMapper;
    @Autowired
    private AdministratorMapper administratorMapper;

    /**
     * 导入商品
     * @param product  商品类
     */
    @Override
    public void addProduct(Product product) {
        shoppingMapper.addProduct(product);
    }

    /**
     * 上架商品列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param productName  商品名称
     * @param productType  商品类型
     * @param productId    商品编号
     * @return             上架商品列表
     */
    @Override
    public PageBean<Product> listOn(Integer pageNum, Integer pageSize, String productName, String productType, String productId) {
        //创建PageBean对象
        PageBean<Product> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Product> products = shoppingMapper.listOn(productName,productType,productId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Product> p = (Page<Product>) products;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }


    /**
     * 下架商品列表
     * @param pageNum     页码
     * @param pageSize    每一页的行数
     * @param productName 商品名称
     * @param productType 商品类型
     * @param productId   商品编号
     * @return            下架商品列表
     */
    @Override
    public PageBean<Product> listOff(Integer pageNum, Integer pageSize, String productName, String productType, String productId) {
        //创建PageBean对象
        PageBean<Product> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Product> products = shoppingMapper.listOff(productName,productType,productId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Product> p = (Page<Product>) products;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 切换商品状态
     * @param productId     商品编号
     * @param productStatus 商品状态
     */
    @Override
    public void turnStatus(Integer productId, String productStatus) {
        shoppingMapper.turnStatus(productId,productStatus);
    }

    /**
     * 用户购买商品
     * @param order 订单类
     */
    @Transactional
    @Override
    public void exchange(Order order) throws Exception {

        //获取义警编号,商品编号,购买数量,商品库存,商品名称,订单总积分
        String vigilanteId = order.getVigilanteId();
        Integer productId = order.getProductId();
        Integer purchaseQuantity = order.getPurchaseQuantity();
        Integer stock = shoppingMapper.getStock(productId);
        String productName = shoppingMapper.getName(productId);
        Integer requiredPoints = order.getRequiredPoints();

        //判断商品库存是否足够
        if(stock < purchaseQuantity) {
            throw new Exception("商品库存不足");
        }
        //判断义警积分是否足够
        Integer availablePoints = vigilanteMapper.getAvailablePoints(vigilanteId);
        if(availablePoints < requiredPoints) {
            throw new Exception("可用爱心积分不足");
        }

        //修改商品库存
        Integer rowsAffected = shoppingMapper.changeStock(productId,purchaseQuantity);
        if(rowsAffected == 0){
            throw new Exception("商品库存不足,请刷新页面");
        }

        //修改义警可用爱心积分
        vigilanteMapper.changeAvailablePoints(vigilanteId,-requiredPoints);

        //添加订单信息到订单表
        shoppingMapper.addOrder(order);

        //积分明细表
        PointsDetails p = new PointsDetails();
        p.setType("兑换商品");
        p.setVigilanteId(vigilanteId);
        p.setPointsEarned(-requiredPoints);
        p.setSource(productName+" * "+purchaseQuantity);
        pointsDetailsMapper.addPointsDetails(p);

        //更新管理员消息通知表
        administratorMapper.addNotification("商品发货提醒","订单号"+order.getOrderId());
    }



    /**
     * 获取商品名称
     * @param productId  商品编号
     * @return           商品名称
     */
    @Override
    public String getName(Integer productId) {
        return shoppingMapper.getName(productId);
    }

    /**
     * 用户查看购买记录
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param vigilanteId   义警编号
     * @param orderStatus   商品状态
     * @return              购买记录
     */
    @Override
    public PageBean<Map<String,Object>> getShoppingRecord(Integer pageNum,Integer pageSize,String vigilanteId,String orderStatus) {
        //创建PageBean对象
        PageBean<Map<String,Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String,Object>> records = shoppingMapper.getShoppingRecord(vigilanteId,orderStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String,Object>> p = (Page<Map<String,Object>>) records;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 签收
     * @param orderId 订单编号
     */
    @Override
    public void signed(Integer orderId) {
        shoppingMapper.signed(orderId);
    }

    /**
     * 商品发货
     * @param params 义警编号，订单编号
     */
    @Override
    public void deliver(Map<String,Object> params) throws Exception {
        Integer orderId = (Integer) params.get("orderId");
        String vigilanteId = (String) params.get("vigilanteId");
        if(vigilanteId == null||orderId == null) {
            throw new Exception("信息缺失");
        }
        shoppingMapper.deliver(orderId);
        vigilanteNotificationService.add(vigilanteId,"商品发货提醒","您的单号为："+ orderId + "的快递已发货，请关注物流信息");
    }

    /**
     * 订单列表
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param orderId         订单编号
     * @param vigilanteId     义警编号
     * @param productId       商品编号
     * @param status          订单状态
     * @param startTime       开始时间
     * @param endTime         结束时间
     * @param antiStatus      订单状态
     * @return                订单列表
     */
    @Override
    public PageBean<Order> listOrder(Integer pageNum, Integer pageSize, String orderId, String vigilanteId, String productId, String status, LocalDate startTime, LocalDate endTime,String antiStatus) {
        //创建PageBean对象
        PageBean<Order> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Order> orders = shoppingMapper.listOrder(orderId,vigilanteId,productId,status,startTime,endTime,antiStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Order> p = (Page<Order>) orders;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 删除商品
     * @param productId    商品编号
     */
    @Override
    public void deleteProduct(Integer productId) throws Exception {
        if(shoppingMapper.getName(productId)==null){
            throw new Exception("该商品已被删除，请刷新页面");
        }
        if(shoppingMapper.findUnfinishedOrderByProductId(productId)){
            throw new Exception("该商品有尚未完成的订单，不可删除");
        }
        shoppingMapper.deleteProduct(productId);
    }

    /**
     * 修改商品信息
     * @param product   商品类
     */
    @Override
    public void modifyProduct(Product product) {
        shoppingMapper.modifyProduct(product);
    }

    /**
     * 商品预览
     * @param productId  商品编号
     * @return           商品预览信息
     */
    @Override
    public Map<String, Order> productPreview(Integer productId) {
        return shoppingMapper.productPreview(productId);
    }
}
