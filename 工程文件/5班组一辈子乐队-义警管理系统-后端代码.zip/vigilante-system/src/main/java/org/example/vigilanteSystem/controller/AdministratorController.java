package org.example.vigilanteSystem.controller;


import jakarta.servlet.http.HttpSession;
import org.example.vigilanteSystem.pojo.Administrator;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Result;
import org.example.vigilanteSystem.service.AdministratorService;
import org.example.vigilanteSystem.service.VerificationCodeService;
import org.example.vigilanteSystem.utils.AdminIdUtil;
import org.example.vigilanteSystem.utils.JwtUtil;
import org.example.vigilanteSystem.utils.ThreadLocalUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;

@RestController
@RequestMapping("/admin")
public class AdministratorController {

    @Autowired
    VerificationCodeService verficationCodeService;
    @Autowired
    private AdministratorService administratorService;
    @Autowired
    private AdminIdUtil adminIdUtil;


    /**
     * 管理员注册
     * @param password        密码
     * @param name            姓名
     * @param idCard          身份证号码
     * @param policeNumber    警察编号
     * @param code            授权码
     * @param session         当前会话
     * @return 注册结果
     */
    @Transactional
    @PostMapping("/register")
    public Result register(String password, String name, String idCard, String policeNumber, String code, HttpSession session) {
        //查询用户是否存在
        Administrator administratorByIdCard = administratorService.findByIdCard(idCard);
        if (administratorByIdCard != null) {
            //占用
            return Result.error("该身份证号已被注册");
        } else if (!code.equals(administratorService.getCodeFromFile(policeNumber))) {
            return Result.error("授权码不正确");
        } else {
            //注册
            String email = (String) session.getAttribute("email");
            String adminId = adminIdUtil.generateAdminId();
            administratorService.register(adminId,email, password, name, idCard, policeNumber);
            return Result.success();
        }
    }

    /**
     * 管理员登录
     * @param email           邮箱
     * @param password        密码
     * @return 登录结果
     */
    @PostMapping("/login")
    public Result<String> login(@RequestParam String email,@RequestParam String password){
        // 邮箱格式的正则表达式
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(emailRegex);
        // 验证邮箱格式
        if (!pattern.matcher(email).matches()) {
            return Result.error("邮箱格式不正确");
        }

        //查询用户
        Administrator loginUser = administratorService.findByEmail(email);
        //判断该用户是否存在
        if(loginUser == null){
            return Result.error("用户不存在");
        }

        //判断密码是否正确
        if(password.equals(loginUser.getPassword())){
            //生成令牌
            Map<String,Object> claims = new HashMap<>();
            claims.put("id",loginUser.getAdminId());
            claims.put("name",loginUser.getName());
            String token = JwtUtil.genToken(claims);
            return Result.success(token);
        }

        return Result.error("密码错误");
    }


    /**
     * 注册发送验证码
     * @param email            邮箱
     * @param session          当前会话
     * @return 发送结果
     */
    @PostMapping("/sendCode")
    public Result sendcode(@RequestParam String email, HttpSession session){

        // 邮箱格式的正则表达式
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(emailRegex);
        // 验证邮箱格式
        if (!pattern.matcher(email).matches()) {
            return Result.error("邮箱格式不正确");
        }

        Administrator administratorByEmail = administratorService.findByEmail(email);
        if (administratorByEmail != null) {
            //占用
            return Result.error("该邮箱已被注册");
        }
        // 若邮箱未被使用，存储邮箱到会话中
        session.setAttribute("email", email);
        // 发送验证码到用户邮箱
        verficationCodeService.sendVerificationCode(email);
        // 返回提示，要求用户输入验证码
        return Result.success();
    }


    /**
     * 注册校验验证码
     * @param emailCode          验证码
     * @param session            当前会话
     * @return 校验结果
     */
    @PostMapping("/verifyCode")
    public Result verifycode(@RequestParam String emailCode, HttpSession session){
        String email = (String) session.getAttribute("email");
        if(!verficationCodeService.verifyCode(email,emailCode)){
            return Result.error("验证码错误");
        }
        return Result.success();
    }

    /**
     * 查询信息上报列表
     * @param pageNum            页码
     * @param pageSize           每一页的行数
     * @param reportId           上报编号
     * @param eventType          上报类型
     * @param reviewStatus       审核状态
     * @param startDate          开始日期
     * @param endDate            结束日期
     * @return
     */
    @GetMapping("/incident_report_list")
    public Result<PageBean<IncidentReport>> incidentReportList
            (Integer pageNum, Integer pageSize,
             @RequestParam(required = false) Integer reportId,
             @RequestParam(required = false) String eventType,
             @RequestParam(required = false) String reviewStatus,
             @RequestParam(required = false) LocalDate startDate,
             @RequestParam(required = false) LocalDate endDate)
    {
        PageBean<IncidentReport> pb = administratorService.incidentReportList(pageNum,pageSize,reportId,eventType,reviewStatus,startDate,endDate);
        return Result.success(pb);
    }

    /**
     * 查看信息上报附件
     * @return   附件
     */
    @GetMapping("/incident_report_media")
    public Result<List<Map<String,Object>>> incidentReportMedia(Integer reportId){
        List<Map<String,Object>> medias = null;
        try {
            medias = administratorService.incidentReportMedia(reportId);
            return Result.success(medias);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 审核信息上报
     * @param params 审核信息
     * @return
     */
    @PostMapping("/incident_report_review")
    public Result incidentReportReview(@RequestBody Map<String,Object> params){
        try {
            administratorService.incidentReportReview(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 删除已审核的信息上报
     * @param params 信息上报编号
     * @return
     */
    @PostMapping("/incident_report_delete")
    public Result incidentReportDelete(@RequestBody Map<String,Object> params){
        try {
            administratorService.incidentReportDelete(params);
            return Result.success();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return Result.error(e.getMessage());
        }
    }

    /**
     * 获取初始化信息
     * @return 初始化信息
     */
    @GetMapping("/init_data")
    public Result<Map<String,Object>> initData(){
        return Result.success(administratorService.initData());
    }

    /**
     * 获取管理员个人信息
     */
    @GetMapping("/personal_info")
    public Result<Map<String,Object>> personalInfo(){
        //获取管理员编号
        Map<String,Object> map = ThreadLocalUtil.get();
        String adminId = (String) map.get("id");
        //获取管理员个人信息
        Map<String,Object> params = administratorService.personalInfo(adminId);
        return Result.success(params);
    }

    /**
     * 管理员获取消息通知列表
     * @param pageNum      页码
     * @param pageSize     每一页的行数
     * @param readStatus   阅读状态
     * @return
     */
    @GetMapping("/notification_list")
    public Result<PageBean<Map<String,Object>>> notificationList(Integer pageNum, Integer pageSize,@RequestParam String readStatus){
        PageBean<Map<String,Object>> pb = administratorService.notificationList(pageNum,pageSize,readStatus);
        return Result.success(pb);
    }

    /**
     * 标记消息通知为已读
     * @param params 消息通知编号
     * @return
     */
    @PostMapping("/notification_read")
    public Result notificationRead(@RequestBody Map<String,Object> params){
        administratorService.notificationRead(params);
        return Result.success();
    }

}