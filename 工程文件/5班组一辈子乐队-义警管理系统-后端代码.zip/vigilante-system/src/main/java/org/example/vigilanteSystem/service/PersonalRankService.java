package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 个人排行service
 */
@Service
public interface PersonalRankService {
    /**
     * 查看服务时长排名月榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> monthVigilante(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名季榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> quarterVigilante(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名年榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> yearVigilante(Integer pageNum, Integer pageSize);

    /**
     * 查看服务时长排名总榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    PageBean<Map<String, Object>> totalVigilante(Integer pageNum, Integer pageSize);

    /**
     * 查看我的总服务时长
     * @param vigilanteId 义警编号
     * @return            总服务时长
     */
    double getPersonalTotalDuration(String vigilanteId);

    /**
     * 查看我的总排名
     * @param vigilanteId 义警编号
     * @return            个人服务时长总排名
     */
    Integer getMyTotalRank(String vigilanteId);

    /**
     * 统计系统总的服务时长
     * @return 总服务时长
     */
    Double durationCounting();
}
