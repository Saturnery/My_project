package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 消息通知service
 */
@Service
public interface VigilanteNotificationService {

    /**
     * 新添义警消息提醒
     * @param vigilanteId      义警编号
     * @param notificationType 消息提醒类型
     * @param content          内容
     */
    void add(String vigilanteId, String notificationType,String content);

    /**
     * 义警查看“我的消息”
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param readStatus     阅读状态
     * @param vigilanteId    义警编号
     * @return               “我的消息”列表
     */
    PageBean<Map<String, Object>> message(Integer pageNum, Integer pageSize, String readStatus, String vigilanteId);

    /**
     * 删除消息通知
     * @param notificationId   消息通知编号
     */
    void deleteMessage(Integer notificationId);

    /**
     * 标记为已读
     * @param notificationId  消息通知编号
     */
    void readMessage(Integer notificationId);
}
