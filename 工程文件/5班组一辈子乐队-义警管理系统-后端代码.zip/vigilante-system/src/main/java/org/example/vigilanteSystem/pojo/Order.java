package org.example.vigilanteSystem.pojo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 订单类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {
    private Integer orderId;                       //订单编号
    private String vigilanteId;                    //义警编号
    private Integer productId;                      //商品编号
    private Integer requiredPoints;                //所需积分
    private String phoneNumber;                    //电话号码
    private String deliveryAddress;                //收货地址
    private String recipientName;                  //收货人称呼
    private String notes;                          //备注
    private String status;                         //订单状态
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private String signedTime;                     //签收时间
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private String postTime;                       //发货时间
    private Integer purchaseQuantity;              //购买数量
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private String orderTime;                      //下单时间
}
