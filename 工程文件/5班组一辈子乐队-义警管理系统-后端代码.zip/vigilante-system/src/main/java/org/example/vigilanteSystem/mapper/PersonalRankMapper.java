package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * 个人排行mapper
 */
@Mapper
public interface PersonalRankMapper {

    /**
     * 更新服务时长排行表（新义警）
     * @param vigilanteId 义警编号
     */
    void addNewVigilante(String vigilanteId);

    /**
     * 更新服务时长
     * @param vigilanteId    义警编号
     * @param serviceTime    新增服务时长
     */
    void updateDuration(String vigilanteId, double serviceTime);

    /**
     * 查看个人排名月榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> monthVigilante();

    /**
     * 查看个人排名季榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> quarterVigilante();

    /**
     * 查看个人排名年榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> yearVigilante();

    /**
     * 查看个人排名总榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> totalVigilante();

    /**
     * 查看个人总服务时长
     * @param vigilanteId 义警编号
     * @return            总服务时长
     */
    double getPersonalTotalDuration(String vigilanteId);

    /**
     * 查看个人服务时长总排名
     * @param vigilanteId 义警编号
     * @return            个人服务时长总排名
     */
    Integer getMyTotalRank(String vigilanteId);

    /**
     * 统计系统总服务时长
     * @return  总服务时长
     */
    Double durationCounting();
}
