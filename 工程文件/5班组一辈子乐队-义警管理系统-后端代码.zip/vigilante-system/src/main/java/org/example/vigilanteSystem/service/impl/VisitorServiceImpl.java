package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.example.vigilanteSystem.mapper.AdministratorMapper;
import org.example.vigilanteSystem.mapper.VigilanteMapper;
import org.example.vigilanteSystem.mapper.VisitorMapper;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Vigilante;
import org.example.vigilanteSystem.pojo.Visitor;
import org.example.vigilanteSystem.service.VisitorService;
import org.example.vigilanteSystem.utils.JwtUtil;
import org.example.vigilanteSystem.utils.VisitorIdUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 游客serviceImpl
 */
@Service
public class VisitorServiceImpl implements VisitorService {

    @Autowired
    private VisitorMapper visitorMapper;
    @Autowired
    private VisitorIdUtil visitorIdUtil;
    @Autowired
    private VigilanteMapper vigilanteMapper;
    @Autowired
    private AdministratorMapper administratorMapper;

    @Value("${wechat.appId}")
    private String appId;
    @Value("${wechat.appSecret}")
    private String appSecret;


    private static final String WECHAT_URL = "https://api.weixin.qq.com/sns/jscode2session";

    /**
     * 处理微信登录以及初始化信息
     * @param code    微信code
     * @return        初始化信息
     */
    @Override
    // 处理微信小程序登录
    public Map<String, Object> login(String code) throws Exception {

        // 请求微信 API 获取 openid 和 session_key
        String url = String.format("%s?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code",
                WECHAT_URL, appId, appSecret, code);


        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);


        if (response.getStatusCode().is2xxSuccessful()) {
            // 解析微信返回的数据 (返回值为 JSON 格式)
            String jsonResponse = response.getBody();
            Map<String, Object> result = new HashMap<>();


            // 使用 Gson 解析 JSON
            assert jsonResponse != null;
            JsonObject jsonObject = JsonParser.parseString(jsonResponse).getAsJsonObject();
            // 解析 openid 和 session_key
            // 注意: 这里需要根据实际微信 API 返回的格式来解析
            String openid = jsonObject.get("openid").getAsString();
            String sessionKey = jsonObject.get("session_key").getAsString();

            //创建claims
            Map<String,Object> claims = new HashMap<>();

            // 根据 openid 查询义警用户
            Vigilante vigilante = vigilanteMapper.findByOpenid(openid);
            // 根据 openid 查询游客用户
            Visitor visitor = visitorMapper.findByOpenid(openid);

            if (vigilante != null) {
                if(vigilante.getVigilanteStatus().equals("禁用")){
                    throw new Exception("您的账号已被禁用，请联系相关人员，电话号码：19173556086");
                }
                claims.put("id",vigilante.getVigilanteId());
                claims.put("isVigilante",true);
                //返回前端需要的缓存数据
                result.put("id",vigilante.getVigilanteId());
                result.put("isVigilante",true);
                result.put("isCaptain",vigilanteMapper.isCaptain(vigilante.getVigilanteId()));
                result.put("teamId",vigilante.getTeamId());
                result.put("nickname",vigilante.getNickName());
                result.put("avatarPath",vigilante.getAvatarPath());
                result.put("isFirstLogin",false);
            }else if(visitor!=null){
                claims.put("id",visitor.getVisitorId());
                claims.put("isVigilante",false);
                //返回前端需要的缓存数据
                result.put("id",visitor.getVisitorId());
                result.put("isVigilante",false);
                result.put("nickname",visitor.getNickName());
                result.put("avatarPath",visitor.getAvatarPath());
                result.put("isFirstLogin",false);
            }else {
                //生成游客编号
                String visitorId = visitorIdUtil.generateVisitorId();
                visitor = Visitor.builder().visitorId(visitorId).openid(openid).build();
                //添加游客信息至游客表
                visitorMapper.addVisitor(visitor);
                claims.put("id",visitor.getVisitorId());
                claims.put("isVigilante",false);
                //返回前端需要的缓存数据
                result.put("id",visitor.getVisitorId());
                result.put("isVigilante",false);
                result.put("isFirstLogin",true);
            }

            //生成令牌
            String authentication = JwtUtil.genSessionKey(claims);

            result.put("openid", openid);
            result.put("sessionKey", sessionKey);
            result.put("Authentication", authentication);

            return result;
        } else {
            // 微信登录失败处理
            throw new RuntimeException("微信登录失败");
        }
    }

    /**
     * 用户第一次登录提交头像和昵称
     * @param visitorId      游客编号
     * @param nickName       昵称
     * @param avatarPath     头像url
     */
    @Override
    public void loginFirst(String visitorId, String nickName, String avatarPath) {
        visitorMapper.loginFirst(visitorId,nickName,avatarPath);
    }

    /**
     * 游客查看消息列表
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param readStatus    阅读状态
     * @param visitorId     游客编号
     * @return              消息列表
     */
    @Override
    public PageBean<Map<String, Object>> message(Integer pageNum, Integer pageSize, String readStatus, String visitorId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = visitorMapper.message(readStatus,visitorId);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 删除消息通知
     * @param notificationId   消息通知编号
     */
    @Override
    public void deleteMessage(String notificationId) {
        visitorMapper.deleteMessage(notificationId);
    }

    /**
     * 标记为已读
     * @param notificationId   消息通知编号
     */
    @Override
    public void readMessage(String notificationId) {
        visitorMapper.readMessage(notificationId);
    }

    /**
     * 游客信息上报
     * @param incidentReport  信息上报类
     */
    @Transactional
    @Override
    public void incidentReportVisitor(IncidentReport incidentReport) {
        //添加到信息上报表
        visitorMapper.incidentReportVisitor(incidentReport);
        Integer reportId = incidentReport.getReportId();

        //获取信息上报附件的存储路径
        List<Map<String,Object>> medias = incidentReport.getMedia();
        for (int i=0;i<medias.size();i++) {
            Map<String,Object> media = medias.get(i);
            //获取附件类型
            String mediaType = (String) media.get("mediaType");
            //获取存储路径
            String storagePath = (String) media.get("storagePath");
            //添加信息到附件表
            visitorMapper.incidentMediaVisitor(reportId,i,mediaType,storagePath);
        }

        //更新管理员消息通知表
        administratorMapper.addNotification("消息上报审核提醒","上报单号"+reportId);
    }

    /**
     * 游客查看信息上报记录
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param visitorId      游客编号
     * @param reviewStatus   审核状态
     * @return               信息上报记录
     */
    @Override
    public PageBean<IncidentReport> incidentReportRecordVisitor(Integer pageNum, Integer pageSize, String visitorId, String reviewStatus) {
        //创建PageBean对象
        PageBean<IncidentReport> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<IncidentReport> v = visitorMapper.incidentReportRecordVisitor(visitorId,reviewStatus);

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<IncidentReport> p = (Page<IncidentReport>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 游客查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    @Override
    public List<Map<String, Object>> incidentMediaRecordVisitor(Integer reportId) throws Exception {
        if(!visitorMapper.findIncidentReportById(reportId)){
            throw new Exception("该信息已被删除，请刷新页面");
        }
        if(!visitorMapper.findIncidentReportMediaById(reportId)){
            throw new Exception("该信息无附件");
        }
        return visitorMapper.incidentMediaRecordVisitor(reportId);
    }

    /**
     * 获取游客未读消息数量
     * @param  visitorId   游客编号
     * @return            未读消息数量
     */
    @Override
    public Integer messageCount(String visitorId) {
        return visitorMapper.messageCount(visitorId);
    }
}
