package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.Team;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 队伍service
 */
@Service
public interface TeamService {

    /**
     * 查看队伍列表
     * @param pageNum         页码
     * @param pageSize        每一页的行数
     * @param teamId          队伍编号
     * @param teamLevel       队伍规模
     * @param teamName        队伍名称
     * @param startTime       开始日期
     * @param endTime         结束日期
     * @return                队伍列表
     */
    PageBean<Team> listTeam(Integer pageNum, Integer pageSize, String teamId, String teamLevel, String teamName, String startTime, String endTime);

    /**
     * 创建队伍（管理员操作）
     * @param params          队伍信息
     */
    void establishTeam(Map<String, Object> params) throws Exception;

    /**
     * 修改头像
     * @param url        头像url
     * @param teamId     队伍编号
     */
    void modifyAvatar(String url, String teamId);

    /**
     * 入队申请
     * @param teamId       队伍编号
     * @param vigilanteId  义警编号
     */
    void joinRequest(String teamId, String vigilanteId);

    /**
     * 根据队伍编号查找队伍信息
     * @param teamId 队伍编号
     * @return       队伍类
     */
    Team findByTeamId(String teamId);


    /**
     * 查看入队申请队列（队伍负责人查看）
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @param teamId     队伍编号
     * @return           入队申请队列
     */
    PageBean<Map<String, Object>> joinRequestList(Integer pageNum,Integer pageSize, String teamId,String reviewResult);

    /**
     * 队伍人数加一
     * @param teamId 队伍编号
     */
    void addTeamSize(String teamId,String vigilanteId) throws Exception;

    /**
     * 队伍人数减一
     * @param teamId 队伍编号
     */
    void reduceTeamSize(String vigilanteId,String teamId);

    /**
     * 入队申请审核
     * @param requestId           入队申请列表
     * @param reviewResult        审核结果
     */
    void joinRequestReview(Integer requestId, String reviewResult);

    /**
     * 踢出队伍成员
     * @param vigilanteId   义警编号
     */
    void kickOut(String teamId,String vigilanteId) throws Exception;

    /**
     * 查询一共有多少队伍
     * @return 队伍总数
     */
    Integer teamCounting();

    /**
     * 更新队伍简介
     * @param description 简介
     * @param teamId      队伍编号
     */
    void modifyDescription(String description, String teamId) throws Exception;

    /**
     * 更换队伍负责人
     * @param map 原负责人编号，新负责人编号，队伍编号
     */
    void changeCaptain(Map<String, Object> map) throws Exception;

    /**
     * 判断义警是否已经提交了此队伍的入队申请，且申请状态为待审核
     * @param teamId        队伍编号
     * @param vigilanteId   义警编号
     * @return              布尔值
     */
    boolean ifJoinRequest(String teamId, String vigilanteId);

}
