package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.Administrator;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.PageBean;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * 管理员service
 */
@Service
public interface AdministratorService {

    /**
     * 新添管理员信息
     * @param email          邮箱
     * @param password       密码
     * @param name           名字
     * @param idCard         身份证号码
     * @param policeNumber   警察编号
     */
    void register(String adminId, String email, String password, String name, String idCard, String policeNumber);

    /**
     * 根据查询邮箱查询
     * @param email 邮箱
     * @return      管理员信息
     */
    Administrator findByEmail(String email);

    /**
     * 根据身份证号查询
     * @param idCard   身份证号码
     * @return         管理员信息
     */
    Administrator findByIdCard(String idCard);

    /**
     * 获取授权码
     * @param policeNumber 警察编号
     * @return             授权码
     */
    String getCodeFromFile(String policeNumber);

    /**
     * 查询信息上报列表
     * @param pageNum           页码
     * @param pageSize          每一页的行数
     * @param reportId          上报编号
     * @param eventType         上报类型
     * @param reviewStatus      审核状态
     * @param startDate         开始日期
     * @param endDate           结束日期
     * @return                  信息上报列表
     */
    PageBean<IncidentReport> incidentReportList(Integer pageNum, Integer pageSize, Integer reportId, String eventType, String reviewStatus, LocalDate startDate, LocalDate endDate);

    /**
     * 信息上报审核
     * @param params 审核信息
     */
    void incidentReportReview(Map<String, Object> params) throws Exception;

    /**
     * 查看信息上报附件
     * @param reportId 信息上报编号
     * @return         附件
     */
    List<Map<String, Object>> incidentReportMedia(Integer reportId) throws Exception;

    /**
     * 删除已审核的信息上报
     * @param params 信息上报编号
     */
    void incidentReportDelete(Map<String, Object> params) throws Exception;

    /**
     * 管理员查看初始化信息
     * @return 初始化信息
     */
    Map<String, Object> initData();

    /**
     * 获取管理员个人信息
     * @param adminId 管理员编号
     * @return        管理员个人信息
     */
    Map<String, Object> personalInfo(String adminId);

    /**
     * 管理员查看消息通知列表
     * @param pageNum        页面
     * @param pageSize       每一页的行数
     * @param readStatus     阅读状态
     * @return               消息通知列表
     */
    PageBean<Map<String, Object>> notificationList(Integer pageNum, Integer pageSize, String readStatus);

    /**
     * 标记消息通知为已读
     * @param params 消息通知编号
     */
    void notificationRead(Map<String, Object> params);
}
