package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.PersonalRankMapper;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.service.PersonalRankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * 个人排行serviceImpl
 */
@Service
public class PersonalRankServiceImpl implements PersonalRankService {
    @Autowired
    private PersonalRankMapper personalRankMapper;

    /**
     * 查看个人排名月榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> monthVigilante(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = personalRankMapper.monthVigilante();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名季榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> quarterVigilante(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = personalRankMapper.quarterVigilante();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名年榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> yearVigilante(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = personalRankMapper.yearVigilante();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看个人排名总榜
     * @param pageNum    页码
     * @param pageSize   每一页的行数
     * @return           排名分页结果
     */
    @Override
    public PageBean<Map<String, Object>> totalVigilante(Integer pageNum, Integer pageSize) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> vrr = personalRankMapper.totalVigilante();

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)vrr;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 查看我的总服务时长
     * @param vigilanteId 义警编号
     * @return            总服务时长
     */
    @Override
    public double getPersonalTotalDuration(String vigilanteId) {
        return personalRankMapper.getPersonalTotalDuration(vigilanteId);
    }

    /**
     * 查看我的总排名
     * @param vigilanteId 义警编号
     * @return            个人服务时长总排名
     */
    @Override
    public Integer getMyTotalRank(String vigilanteId) {
        return personalRankMapper.getMyTotalRank(vigilanteId);
    }

    /**
     * 统计系统总服务时长
     * @return 总服务时长
     */
    @Override
    public Double durationCounting() {
        return personalRankMapper.durationCounting();
    }
}
