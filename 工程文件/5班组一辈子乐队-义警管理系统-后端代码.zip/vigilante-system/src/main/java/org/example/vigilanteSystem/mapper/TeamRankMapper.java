package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface TeamRankMapper {

    /**
     * 更新队伍服务时长
     * @param teamId           队伍编号
     * @param serviceTime      新增服务时长
     */
    void updateDuration(String teamId, double serviceTime);

    /**
     * 创建新的队伍
     * @param teamId           队伍编号
     * @param serviceDuration  服务时长
     */
    void addNewTeam(String teamId, double serviceDuration);

    /**
     * 查看队伍排名月榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> monthTeam();

    /**
     * 查看队伍排名季榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> quarterTeam();

    /**
     * 查看队伍排名年榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> yearTeam();

    /**
     * 查看队伍排名总榜
     * @return  排名分页结果
     */
    List<Map<String, Object>> totalTeam();
}
