package org.example.vigilanteSystem.utils;



import org.example.vigilanteSystem.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


import java.util.List;

/**
 * 签到提醒
 */
@Component
public class RemindSign {

    @Autowired
    private OnGoingTask onGoingTask;
    @Autowired
    private TaskService taskService;
    @Autowired
    private WebSocketServer webSocketServer;

    /**
     * 每分钟提醒签到打卡
     */
    @Scheduled(fixedRate = 30000) // 每1分钟进行一次提醒
    public void remindSign() {
        List<Integer> onGoingTasks = onGoingTask.getOnGoingTasks();
        if(!onGoingTasks.isEmpty()){
            //对于每一个正在进行的任务
            for(Integer taskId : onGoingTasks){
                //对于每一个参与了此任务的义警（未进行签到）
                List<String> vigilanteIds = taskService.findTaskMember(taskId);
                for (String vigilanteId : vigilanteIds) {
                    //向前端发送提醒
                    webSocketServer.sendToClient("vigilante"+vigilanteId,"3");
                }
            }
        }
    }


}
