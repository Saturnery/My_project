package org.example.vigilanteSystem.utils;

import org.example.vigilanteSystem.mapper.VisitorMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 生成游客编号
 */
@Component
public class VisitorIdUtil {
    @Autowired
    private VisitorMapper visitorMapper;

    /**
     * 生成游客编号
     */
    public String generateVisitorId() {
        String visitorId = visitorMapper.findMaxVisitorId();
        if (visitorId != null) {
            int temp = Integer.parseInt(visitorId);
            temp++;
            visitorId = String.format("%010d", temp);
        } else {
            visitorId = "0000000001";
        }
        return visitorId;
    }
}
