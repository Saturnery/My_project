package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.Team;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

/**
 * 队伍mapper
 */
@Mapper
public interface TeamMapper {

    /**
     * 查找所有队伍
     * @param teamId      队伍编号
     * @param teamLevel   队伍规模
     * @param teamName    队伍名称
     * @param startTime   开始日期
     * @param endTime     结束日期
     * @return            队伍列表
     */
    List<Team> listTeam(String teamId, String teamLevel, String teamName, String startTime, String endTime);



    /**
     * 查询当年的最大队伍编号
     * @param currentYear 当前年份
     * @return 当年的最大队伍编号
     */
    String findMaxNum(String currentYear);

    /**
     * 修改队伍头像
     * @param url      头像url
     * @param teamId   队伍编号
     */
    void modifyAvatar(String url, String teamId);

    /**
     * 更新入队申请表
     * @param teamId      队伍编号
     * @param vigilanteId 义警编号
     */
    void joinRequest(String teamId, String vigilanteId);

    /**
     * 根据队伍编号查找队伍
     * @param captainId 负责人编号
     * @return          队伍信息
     */
    Team findTeamByCaptainId(String captainId);

    /**
     * 查询入队申请列表（队伍负责人查看）
     * @param teamId           队伍编号
     * @param reviewResult     审核结果
     * @return                 入队申请列表
     */
    List<Map<String, Object>> joinRequestList(String teamId,String reviewResult);

    /**
     * 队伍人数加一
     * @param teamId          队伍编号
     */
    void addTeamSize(String teamId);

    /**
     * 队伍人数减一
     * @param teamId         队伍编号
     */
    void reduceTeamSize(String teamId);

    /**
     * 更新入队申请结果
     * @param requestId       申请编号
     * @param reviewResult    审核状态
     */
    void joinRequestReview(Integer requestId, String reviewResult);

    /**
     * 根据队伍编号查找队伍
     * @param teamId      队伍编号
     * @return            队伍信息
     */
    Team findByTeamId(String teamId);

    /**
     * 查找队伍的负责人编号
     * @param teamId       队伍编号
     * @return             队伍信息
     */
    String getCaptainIdByTeamId(String teamId);

    /**
     * 踢出队伍成员
     * @param vigilanteId 义警编号
     */
    void kickOut(String vigilanteId);

    /**
     * 增加队伍的服务时长
     * @param serviceTime   服务时长
     * @param teamId        队伍编号
     */
    void addDuration(double serviceTime, String teamId);

    /**
     * 查询队伍的所有成员编号
     * @param teamId    队伍编号
     * @return          队伍成员的义警编号队列
     */
    List<String> findMembers(String teamId);

    /**
     * 统计总队伍数
     * @return   队伍总数
     */
    Integer teamCounting();

    /**
     * 更新队伍简介
     * @param description    简介
     * @param teamId         队伍编号
     */
    void modifyDescription(String description, String teamId);

    /**
     * 更换队伍负责人
     * @param teamId         队伍编号
     * @param newCaptainId   新的负责人编号
     */
    void changeCaptain(String teamId, String newCaptainId);

    /**
     * 创建队伍
     * @param captainId          负责人编号
     * @param teamLevel          队伍规模
     * @param teamName           队伍名称
     * @param teamDescription    队伍描述
     * @param teamAvatarPath     队伍头像路径
     * @param serviceArea        服务区域
     * @param teamId             队伍编号
     * @param teamSize           队伍人数
     * @param serviceDuration    总服务时长
     */
    void establishTeam(String captainId, String teamLevel, String teamName, String teamDescription, String teamAvatarPath, String serviceArea, String teamId, Integer teamSize, double serviceDuration);

    /**
     * 判断义警是否可以申请入队
     * @param teamId        队伍编号
     * @param vigilanteId   义警编号
     * @return              布尔值
     */
    boolean ifJoinRequest(String teamId, String vigilanteId);

    /**
     * 判断所指派的队伍是否存在时间冲突
     * @param taskDate          任务日期
     * @param taskStartTime     任务开始时间
     * @param taskEndTime       任务结束时间
     * @param teamId            队伍编号
     * @return                  布尔值
     */
    boolean ifTimeOverlaps(LocalDate taskDate, LocalTime taskStartTime, LocalTime taskEndTime, String teamId);
}
