package org.example.vigilanteSystem.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.example.vigilanteSystem.pojo.IncidentReport;
import org.example.vigilanteSystem.pojo.Visitor;

import java.util.List;
import java.util.Map;

/**
 * 游客mapper
 */
@Mapper
public interface VisitorMapper {

    /**
     * 根据openid查询用户是否为新用户
     * @param openid  微信openid
     * @return        游客信息
     */
    Visitor findByOpenid(String openid);


    /**
     * 查询当前最大的游客编号
     * @return        当前最大的游客编号
     */
    String findMaxVisitorId();


    /**
     * 添加游客用户信息
     * @param visitor    游客类
     */
    void addVisitor(Visitor visitor);

    /**
     * 获取openid
     * @param visitorId  游客编号
     * @return           微信openid
     */
    String getOpenid(String visitorId);

    /**
     * 首次登录提交昵称和头像接口
     * @param visitorId  游客编号
     * @param nickName   昵称
     * @param avatarPath 头像url
     */
    void loginFirst(String visitorId, String nickName, String avatarPath);

    /**
     * 查看消息列表
     * @param readStatus 阅读状态
     * @param visitorId  游客编号
     * @return           消息列表
     */
    List<Map<String, Object>> message(String readStatus, String visitorId);

    /**
     * 删除消息通知
     * @param notificationId 消息通知编号
     */
    void deleteMessage(String notificationId);

    /**
     * 标记为已读
     * @param notificationId 消息通知编号
     */
    void readMessage(String notificationId);

    /**
     * 查询游客头像路径
     * @param visitorId 游客编号
     * @return          头像url
     */
    String getAvatarPath(String visitorId);

    /**
     * 查询游客昵称
     * @param visitorId 游客编号
     * @return          游客昵称
     */
    String getNickName(String visitorId);

    /**
     * 添加信息到上报表
     * @param incidentReport 信息上报类
     */
    void incidentReportVisitor(IncidentReport incidentReport);

    /**
     * 添加信息到附件表
     * @param reportId    信息上报编号
     * @param mediaIndex  索引号
     * @param mediaType   附件类型
     * @param storagePath 存储路径
     */
    void incidentMediaVisitor(Integer reportId, Integer mediaIndex, String mediaType, String storagePath);

    /**
     * 游客查看信息上报记录
     * @param visitorId     游客编号
     * @param reviewStatus  审核状态
     * @return              信息上报记录
     */
    List<IncidentReport> incidentReportRecordVisitor(String visitorId, String reviewStatus);

    /**
     * 游客查看某一信息上报记录的附件
     * @param reportId 信息上报编号
     * @return         附件存储路径
     */
    List<Map<String, Object>> incidentMediaRecordVisitor(Integer reportId);

    /**
     * 判断信息上报记录是否存在
     * @param reportId 信息上报编号
     * @return         布尔值
     */
    boolean findIncidentReportById(Integer reportId);

    /**
     * 判断信息上报附件是否存在
     * @param reportId 信息上报编号
     * @return         布尔值
     */
    boolean findIncidentReportMediaById(Integer reportId);

    /**
     * 获取游客未读消息数量
     * @param visitorId 游客编号
     * @return          未读消息数量
     */
    Integer messageCount(String visitorId);
}
