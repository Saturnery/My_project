package org.example.vigilanteSystem.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.example.vigilanteSystem.mapper.VigilanteNotificationMapper;
import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.service.VigilanteNotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

/**
 * 义警通知serviceImpl
 */
@Service
public class VigilanteNotificationServiceImpl implements VigilanteNotificationService {

    @Autowired
    private VigilanteNotificationMapper vigilanteNotificationMapper;

    /**
     * 新添义警消息提醒
     * @param vigilanteId      义警编号
     * @param notificationType 消息提醒类型
     * @param content          内容
     */
    @Override
    public void add(String vigilanteId, String notificationType, String content) {
        vigilanteNotificationMapper.add(vigilanteId, notificationType, content);
    }

    /**
     * 义警查看“我的消息”
     * @param pageNum        页码
     * @param pageSize       每一页的行数
     * @param readStatus     阅读状态
     * @param vigilanteId    义警编号
     * @return               “我的消息”列表
     */
    @Override
    public PageBean<Map<String, Object>> message(Integer pageNum, Integer pageSize, String readStatus, String vigilanteId) {
        //创建PageBean对象
        PageBean<Map<String, Object>> pb = new PageBean<>();
        //开启分页查询（pageHelper）
        PageHelper.startPage(pageNum, pageSize);
        //创建查询义警注册表的返回对象
        List<Map<String, Object>> v = vigilanteNotificationMapper.message(readStatus,vigilanteId);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (Map<String, Object> map : v) {
            LocalDateTime sendTime = (LocalDateTime) map.get("sendTime");
            String formattedSendTime = sendTime.format(formatter);
            map.put("sendTime", formattedSendTime);
        }

        //Page中提供了方法，可以获取PageHelper分页查询后得到的总记录条数和当前页数据
        Page<Map<String, Object>> p = (Page<Map<String, Object>>)v;

        //把数据填充到PageBean对象中
        pb.setTotal(p.getTotal());
        pb.setItems(p.getResult());
        return pb;
    }

    /**
     * 删除消息通知
     * @param notificationId   消息通知编号
     */
    @Override
    public void deleteMessage(Integer notificationId) {
        vigilanteNotificationMapper.deleteMessage(notificationId);
    }

    /**
     * 标记为已读
     * @param notificationId  消息通知编号
     */
    @Override
    public void readMessage(Integer notificationId) {
        vigilanteNotificationMapper.readMessage(notificationId);
    }

}
