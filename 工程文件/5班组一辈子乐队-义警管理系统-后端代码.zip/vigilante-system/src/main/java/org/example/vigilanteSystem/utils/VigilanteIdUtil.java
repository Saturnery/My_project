package org.example.vigilanteSystem.utils;

import org.example.vigilanteSystem.mapper.VigilanteMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;

/**
 * 生成义警编号
 */
@Component
public class VigilanteIdUtil {
    @Autowired
    private VigilanteMapper vigilanteMapper;

    /**
     * 生成义警编号
     */
    public String generateVigilanteId(){
        //获取当前年份
        Calendar calendar = Calendar.getInstance();
        String currentYear = String.valueOf(calendar.get(Calendar.YEAR));
        //获取当前年份的最大序号
        String maxVigilanteId = vigilanteMapper.findMaxNum(currentYear);
        if (maxVigilanteId != null) {
            int temp = Integer.parseInt(maxVigilanteId);
            temp++;
            maxVigilanteId = String.valueOf(temp);
        } else {
            maxVigilanteId = currentYear + "000001";
        }
        return maxVigilanteId;
    }
}
