package org.example.vigilanteSystem.utils;

import org.example.vigilanteSystem.mapper.AdministratorMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 生成管理员编号
 */
@Component
public class AdminIdUtil {

    @Autowired
    private AdministratorMapper administratorMapper;

    /**
     * 生成管理员编号
     */
    public String generateAdminId() {
        String adminId = administratorMapper.findMaxAdminId();
        if (adminId != null) {
            int temp = Integer.parseInt(adminId);
            temp++;
            adminId = String.valueOf(temp);
        } else {
            adminId = "1";
        }
        return adminId;
    }
}
