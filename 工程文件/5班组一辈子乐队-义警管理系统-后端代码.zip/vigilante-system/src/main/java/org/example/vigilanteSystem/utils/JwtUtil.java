package org.example.vigilanteSystem.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

import java.util.Date;
import java.util.Map;

/**
 * 登录令牌
 */
public class JwtUtil {

    private static final String ADMIN_KEY = "band";
    private static final String USER_KEY = "vvvv";

    /**
     * 接收业务数据,生成token并返回
     * @param claims 存储用户信息
     */
    public static String genToken(Map<String, Object> claims) {
        return JWT.create()
                .withClaim("claims", claims)
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 12))
                .sign(Algorithm.HMAC256(ADMIN_KEY));
    }

    /**
     * /接收业务数据,生成sessionKey并返回
     * @param claims  存储用户信息
     */
    public static String genSessionKey(Map<String, Object> claims) {
        return JWT.create()
                .withClaim("claims", claims)
                .withExpiresAt(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 12))
                .sign(Algorithm.HMAC256(USER_KEY));
    }

    /**
     * 接收token,验证token,并返回业务数据
     * @param token   登录token
     */
    public static Map<String, Object> parseToken(String token) {
        return JWT.require(Algorithm.HMAC256(ADMIN_KEY))
                .build()
                .verify(token)
                .getClaim("claims")
                .asMap();
    }

    /**
     * 接收sessionKey,验证sessionKey,并返回业务数据
     * @param sessionKey 密钥
     */
    public static Map<String, Object> parseSessionKey(String sessionKey) {
        return JWT.require(Algorithm.HMAC256(USER_KEY))
                .build()
                .verify(sessionKey)
                .getClaim("claims")
                .asMap();
    }

}
