package org.example.vigilanteSystem.service;

import org.example.vigilanteSystem.pojo.PageBean;
import org.example.vigilanteSystem.pojo.PointsDetails;
import org.springframework.stereotype.Service;

/**
 * 积分明细service
 */
@Service
public interface PointsDetailsService {

    /**
     * 积分明细列表
     * @param pageNum       页码
     * @param pageSize      每一页的行数
     * @param vigilanteId   义警编号
     * @return              积分明细列表
     */
    PageBean<PointsDetails> list(Integer pageNum,Integer pageSize,String vigilanteId);

    /**
     * 新添积分明细
     * @param pointsDetails    积分明细类
     */
    void addPointsDetails(PointsDetails pointsDetails);
}
